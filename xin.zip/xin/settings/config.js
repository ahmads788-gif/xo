module.exports = {
  bot_token: '8104624314:AAF27USCUEgJNoHefCAbk7idrtchQtQLj1U',
  owner_ids: ['7797743583'],
  channel: '@xinn_ch',
  username_owner: '@gzy_amoxy',
  domain: 'https://www.rumahotp.com/api',
  apikey: 'otp_mFpIUmvlEJHVtAZj',
  khafa_apikey: 'KhafaTopUp_bu13oi9qx78sdy28',
  fee_product: 300,
  fee_nokos: 300,
  fee_deposout: 500
};