const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const fsAsync = require('fs').promises;
const archiver = require('archiver');
const QRCode = require('qrcode');
const config = require('./settings/config.js');
const ReferralSystem = require('./library/referral.js');
const RoyaltySystem = require('./library/royalty.js');
const KhafaService = require('./api/x-apikeyv2.js');
const api = require('./api/x-apikey.js');
const withdrawApi = require('./api/x-apikeyv4.js');

const khafaService = new KhafaService();
const referralSystem = new ReferralSystem();
const royaltySystem = new RoyaltySystem();

const deposit_fee = config.fee_deposout;
const nokos_fee = config.fee_nokos;
const product_fee = config.fee_product;

const bot = new TelegramBot(config.bot_token, {
  polling: { 
    interval: 50,
    params: { 
      timeout: 10,
      allowed_updates: ['message', 'callback_query']
    }
  }
})

const x_apikey = config.apikey;
const x_domain = config.domain;
const owner_ids = config.owner_ids;
const channel = config.channel;
const usernamelu = config.username_owner;
const fee_settings = config.fee_settings;

const notifiedNewUsers = new Set();
const userLastMessage = new Map();
const userSelections = new Map();
const userDepositMessages = new Map();
const userPendingCommands = new Map();
const balanceCache = new Map();
const transactionCache = new Map();
const priceCache = new Map();
const lastNotificationTime = new Map();
const lastDepositRequestTime = new Map();
const sentNotifications = new Map();
const orderProcessing = new Map();
const depositProcessing = new Map();
const pendingProductData = new Map();
let isCheckingPrices = false;

const dataDir = path.join(__dirname, 'database');
const datafile = path.join(dataDir, 'users.json');
const transactionsFile = path.join(dataDir, 'transactions.json');
const balanceFile = path.join(dataDir, 'balances.json');
const settingsFile = path.join(dataDir, 'settings.json');
const dataProduct = path.join(dataDir, 'dataproduct.json');
const feeConfigFile = path.join(dataDir, './database/fee_config.json');

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

function loadDataProduct() {
    try {
        if (!fs.existsSync(dataProduct)) {
            const defaultData = {
                products: {},
                orders: {},
                payment_methods: ["saldo", "qris"],
                last_update: new Date().toISOString()
            };
            fs.writeFileSync(dataProduct, JSON.stringify(defaultData, null, 2));
            return defaultData;
        }
        const data = fs.readFileSync(dataProduct, 'utf8');
        return JSON.parse(data);
    } catch (e) {
        return {
            products: {},
            orders: {},
            payment_methods: ["saldo", "qris"],
            last_update: new Date().toISOString()
        };
    }
}

function saveDataProduct(data) {
    try {
        data.last_update = new Date().toISOString();
        fs.writeFileSync(dataProduct, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('Error saving product data:', error);
        return false;
    }
}

function generateProductId(name) {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 5);
    const namePart = name.substr(0, 3).toLowerCase().replace(/[^a-z0-9]/g, '');
    return `${namePart}_${timestamp}_${random}`;
}

function loadSettings() {
  try {
    if (!fs.existsSync(settingsFile)) {
      const defaultSettings = {
        maintenance: false,
        maintenance_reason: '',
        maintenance_time: '',
        payment_method: 'khafa'
      };
      saveSettings(defaultSettings);
      return defaultSettings;
    }
    return JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
  } catch (e) {
    return {
      maintenance: false,
      maintenance_reason: '',
      maintenance_time: '',
      payment_method: 'khafa'
    };
  }
}

function saveSettings(settings) {
  try {
    fs.writeFileSync(settingsFile, JSON.stringify(settings, null, 2));
    return true;
  } catch (error) {
    return false;
  }
}

function loadBalances() {
  try {
    if (!fs.existsSync(balanceFile)) {
      return {};
    }
    const data = fs.readFileSync(balanceFile, 'utf8');
    const parsed = JSON.parse(data);
    return parsed;
  } catch (e) {
    console.error('Error loading balances:', e);
    return {};
  }
}

function saveBalances(balances) {
  try {
    fs.writeFileSync(balanceFile, JSON.stringify(balances, null, 2));
    return true;
  } catch (error) {
    console.error('Error saving balances:', error);
    return false;
  }
}

function getUserBalance(userId) {
    const userIdStr = String(userId);
    
    const balances = loadBalances();
    const balance = parseInt(balances[userIdStr]) || 0;
    const numBalance = isNaN(balance) ? 0 : Number(balance);
    
    balanceCache.set(userIdStr, numBalance);
    return numBalance;
}

function getTransactionById(transactionType, depositId) {
    const transactions = loadTransactions();
    const typeTransactions = transactions[transactionType] || [];
    return typeTransactions.find(t => t.data.id === depositId);
}

function validateAmount(amount) {
    const numAmount = Number(amount);
    if (isNaN(numAmount) || !isFinite(numAmount)) {
        return { valid: false, error: 'Jumlah tidak valid' };
    }
    if (numAmount < 1000) {
        return { valid: false, error: 'Jumlah harus minimal 1,000' };
    }
    if (numAmount <= 0) {
        return { valid: false, error: 'Jumlah harus lebih dari 0' };
    }
    return { valid: true, amount: numAmount };
}

function validateUserId(userId) {
    const userIdStr = String(userId);
    if (!userIdStr || userIdStr.length < 5) {
        return { valid: false, error: 'User ID tidak valid' };
    }
    if (!/^\d+$/.test(userIdStr)) {
        return { valid: false, error: 'User ID harus angka' };
    }
    return { valid: true, userId: userIdStr };
}

function addUserBalance(userId, amount) {
    try {
        const userIdStr = String(userId);
        const numAmount = Number(amount);
        
        if (isNaN(numAmount) || numAmount <= 0) {
            return false;
        }
        
        const balances = loadBalances();
        const currentBalance = parseInt(balances[userIdStr]) || 0;
        const newBalance = currentBalance + numAmount;
        
        balances[userIdStr] = newBalance;
        balanceCache.set(userIdStr, newBalance);
        
        return saveBalances(balances);
    } catch (error) {
        return false;
    }
}

function deductUserBalance(userId, amount) {
    try {
        const validation = validateAmount(amount);
        if (!validation.valid) return false;
        
        const numAmount = validation.amount;
        
        const userIdValidation = validateUserId(userId);
        if (!userIdValidation.valid) return false;
        
        const userIdStr = userIdValidation.userId;
        
        const balances = loadBalances();
        const currentBalance = parseInt(balances[userIdStr]) || 0;
        const numCurrent = isNaN(currentBalance) ? 0 : Number(currentBalance);
        
        if (numCurrent < numAmount) {
            return false;
        }

        const newBalance = numCurrent - numAmount;
        
        balances[userIdStr] = newBalance;
        balanceCache.set(userIdStr, newBalance);
        
        return saveBalances(balances);
    } catch (error) {
        return false;
    }
}

setInterval(() => {
    const now = Date.now();
    const fiveMinutes = 5 * 60 * 1000; 
    
    for (const [key, timestamp] of sentNotifications.entries()) {
        if (now - timestamp > fiveMinutes) {
            sentNotifications.delete(key);
        }
    }

    for (const [key, timestamp] of orderProcessing.entries()) {
        if (now - timestamp > fiveMinutes) { 
            orderProcessing.delete(key);
        }
    }
}, 60 * 1000); 

function saveJSON(file, data) {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    return false;
  }
}

function calculateTotalWithFee(baseAmount, gatewayFee = 0) {
    const numAmount = Number(baseAmount) || 0;
    const numGatewayFee = Number(gatewayFee) || 0;
    const numAdditionalFee = Number(fee_settings) || 0;
    const totalFee = numGatewayFee + numAdditionalFee;
    const totalAmount = numAmount + totalFee;
    
    return {
        original: numAmount,
        gateway_fee: numGatewayFee,
        additional_fee: numAdditionalFee,
        total_fee: totalFee,
        total: totalAmount,
        user_receive: numAmount
    };
}

function isOrderProcessing(orderId) {
  return orderProcessing.has(orderId);
}

function setOrderProcessing(orderId, processing = true) {
  if (processing) {
    orderProcessing.set(orderId, Date.now());
  } else {
    orderProcessing.delete(orderId);
  }
}

function loadJSON(file) {
  try {
    if (!fs.existsSync(file)) {
      if (file === datafile) return { users: [], settings: { maintenance: false } };
      return {};
    }
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    return file === datafile ? { users: [], settings: { maintenance: false } } : {};
  }
}

function loadData() {
  return loadJSON(datafile);
}

function saveData(data) {
  return saveJSON(datafile, data);
}

function saveUser(userId) {
  const data = loadData();
  const userIdStr = String(userId);
  
  if (!data.users) data.users = [];
  
  const userExists = data.users.some(id => id === userIdStr);
  
  if (!userExists) {
    data.users.push(userIdStr);
    return saveData(data);
  }
  
  return true;
}

function loadTransactions() {
  const data = loadJSON(transactionsFile);
  return {
    nokos_orders: data.nokos_orders || [],
    rumahotp_deposits: data.rumahotp_deposits || [],
    khafa_deposits: data.khafa_deposits || []
  };
}

function addTransaction(type, data) {
  const transactions = loadTransactions();
  transactions[type] = transactions[type] || [];
 
  if (type === 'nokos_orders') {
    const now = Date.now();
    const fifteenMinutes = 15 * 60 * 1000;
    
    transactions[type] = transactions[type].filter(order => {
      const orderTime = new Date(order.timestamp).getTime();
      
      if ((order.status === 'pending' || order.status === 'active') && 
          (now - orderTime > fifteenMinutes)) {
        return false;
      }
      return true;
    });
  }
  
  const transaction = {
    id: data.id || Math.random().toString(36).substr(2, 9),
    userId: data.userId,
    data: data,
    timestamp: new Date().toISOString(),
    status: data.status || 'pending'
  };
  
  transactions[type].push(transaction);
  saveTransactions(transactions);
  return transaction.id;
}

function saveTransactions(transactions) {
  return saveJSON(transactionsFile, transactions);
}

function updateTransactionStatus(type, transactionId, status) {
  const transactions = loadTransactions();
  if (transactions[type]) {
    const transaction = transactions[type].find(t => t.id === transactionId);
    if (transaction) {
      transaction.status = status;
      transaction.data.status = status;
      saveTransactions(transactions);
      return true;
    }
  }
  return false;
}

function cleanExpiredDeposits() {
    try {
        const transactions = loadTransactions();
        const now = Date.now();
        const twentyMinutes = 20 * 60 * 1000;
        
        ['khafa_deposits', 'rumahotp_deposits'].forEach(type => {
            if (transactions[type]) {
                transactions[type] = transactions[type].filter(deposit => {
                    const depositTime = new Date(deposit.timestamp).getTime();
                    
                    return (deposit.status === 'success' || deposit.status === 'paid') || 
                           (now - depositTime < twentyMinutes && (deposit.status === 'pending' || deposit.status === 'waiting'));
                });
            }
        });
        
        saveTransactions(transactions);
    } catch (error) {
        console.error('Error cleaning deposits:', error);
    }
}

setInterval(cleanExpiredDeposits, 5 * 60 * 1000);

setInterval(() => {
  balanceCache.clear();
  transactionCache.clear();
}, 10 * 60 * 1000);

function formatCurrency(amount) {
  const numAmount = Number(amount);
  if (isNaN(numAmount) || !isFinite(numAmount)) {
    return 'Rp 0';
  }
  return 'Rp ' + new Intl.NumberFormat('id-ID', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(numAmount);
}

function getPaymentMethod() {
  const settings = loadSettings();
  return settings.payment_method || 'khafa';
}

function setPaymentMethod(method) {
  const settings = loadSettings();
  settings.payment_method = method;
  saveSettings(settings);
  return method;
}

async function sendNewMessage(chatId, message, options = {}) {
  try {
    const lastMsgId = userLastMessage.get(chatId);
    if (lastMsgId) {
      try {
        bot.deleteMessage(chatId, lastMsgId).catch(() => {});
      } catch (e) {
      }
    }
    
    const newMessage = await bot.sendMessage(chatId, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      disable_notification: true,
      ...options
    });
    
    userLastMessage.set(chatId, newMessage.message_id);
    return newMessage;
  } catch (error) {
    const newMessage = await bot.sendMessage(chatId, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      disable_notification: true,
      ...options
    });
    userLastMessage.set(chatId, newMessage.message_id);
    return newMessage;
  }
}

async function editMessage(chatId, messageId, callbackQueryId, message, options = {}) {
  try {
    if (callbackQueryId) {
      bot.answerCallbackQuery(callbackQueryId).catch(() => {});
    }
    
    await bot.editMessageText(message, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      ...options
    });
    return true;
  } catch (error) {
    try {
      await sendNewMessage(chatId, message, options);
      return false;
    } catch (e) {
      return false;
    }
  }
}

function checkAutoMaintenance() {
    const now = new Date();
    const hour = now.getUTCHours() + 7;
    const minute = now.getUTCMinutes();
    
    if (hour === 0 && minute === 0) { 
        const settings = loadSettings();
        if (!settings.maintenance) {
            setMaintenance(true, 'Maintenance otomatis harian (00:00-23:10 WIB)');
            for (const ownerId of owner_ids) {
                bot.sendMessage(ownerId, '🛠️ Maintenance otomatis telah diaktifkan (00:00-23:10 WIB)').catch(() => {});
            }
        }
    }
    
    if (hour === 23 && minute === 10) { 
        const settings = loadSettings();
        if (settings.maintenance) {
            setMaintenance(false);
            for (const ownerId of owner_ids) {
                bot.sendMessage(ownerId, '✅ Maintenance otomatis selesai (23:10 WIB)').catch(() => {});
            }
        }
    }
}

function isMaintenance() {
  const settings = loadSettings();
  return settings.maintenance === true;
}

function getMaintenanceInfo() {
  const settings = loadSettings();
  if (!settings.maintenance) {
    return { active: false, reason: '' };
  }
  return {
    active: true,
    reason: settings.maintenance_reason || 'Bot sedang dalam perbaikan',
    time: settings.maintenance_time || ''
  };
}

function setMaintenance(active, reason = '') {
  const settings = loadSettings();
  
  settings.maintenance = active;
  if (active) {
    settings.maintenance_reason = reason;
    settings.maintenance_time = new Date().toLocaleString('id-ID');
  } else {
    settings.maintenance_reason = '';
    settings.maintenance_time = '';
  }
  
  saveSettings(settings);
  return active;
}

async function checkChannelMembership(userId) {
    try {
        const chatMember = await bot.getChatMember(channel, userId);
        return ['member', 'administrator', 'creator'].includes(chatMember.status);
    } catch (error) {
        console.error('Error checking channel membership:', error);
        return false;
    }
}

async function checkMaintenance(msg) {
  const userId = msg.from.id.toString();
  const chatId = msg.chat.id;
  
  const maintenance = getMaintenanceInfo();
  
  if (maintenance.active && !owner_ids.includes(userId)) {
    await bot.sendMessage(chatId,
`<b>🛠️ BOT SEDANG MAINTENANCE</b>

<blockquote>⚙️ Status: <b>Tidak Tersedia</b>
📝 Alasan: ${maintenance.reason}</blockquote>

⚠️ Mohon tunggu hingga maintenance selesai.

<b>📞 Kontak Owner</b>
${usernamelu.replace('@','')}`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ 
              text: '🔄 Refresh Status', 
              callback_data: 'refresh_maintenance' 
            }]
          ]
        },
        disable_web_page_preview: true
      }
    );
    return false;
  }
  return true;
}

async function requireJoin(msg) {
  const userId = msg.from.id;
  const isMember = await checkChannelMembership(userId);

  if (!isMember) {
    const originalCommand = msg.text || "/start";
    userPendingCommands.set(userId, originalCommand);

    await sendNewMessage(msg.chat.id, 
`<b>🔐 VERIFIKASI KEANGGOTAAN</b>

<blockquote>👤 Nama: ${msg.from.first_name || 'User'}
🆔 ID: <code>${userId}</code>
📊 Status: <b>Belum Bergabung</b></blockquote>

<b>⚠️ AKSES DITOLAK</b>
Anda harus bergabung ke channel terlebih dahulu.

<b>🔰 PETUNJUK</b>
Klik tombol dibawah untuk bergabung`,
    {
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "📢 Join Channel", 
            url: `https://t.me/${channel.replace('@','')}` 
          }],
          [{ 
            text: "✅ Verifikasi", 
            callback_data: "check_join_again" 
          }]
        ]
      },
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });
    return false;
  }
  
  if (userPendingCommands.has(userId)) {
    userPendingCommands.delete(userId);
  }
  
  return true;
}

function withRequireJoin(handler) {
  return async (msg, match) => {
    const ok = await requireJoin(msg);
    if (!ok) return;
    return handler(msg, match);
  };
}

bot.on("callback_query", async (query) => {
  const userId = query.from.id.toString();
  const chatId = query.message.chat.id;

  if (query.data === "check_join_again") {
    await bot.answerCallbackQuery(query.id, {
      text: "🔍 Memeriksa status keanggotaan...",
      show_alert: false
    });

    const isMember = await checkChannelMembership(userId);

    if (isMember) {
      await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});

      await sendNewMessage(chatId, 
`<b>✅ VERIFIKASI BERHASIL</b>

<blockquote>📊 Status: <b>Terverifikasi</b>
🔓 Akses: <b>Diizinkan</b></blockquote>

<b>✨ SELAMAT DATANG</b>
Sekarang Anda dapat menggunakan semua fitur bot.`,
        { 
          parse_mode: 'HTML',
          disable_web_page_preview: true 
        }
      );

      const pendingCommand = userPendingCommands.get(parseInt(userId));
      if (pendingCommand) {
        const simulatedMsg = {
          ...query.message,
          text: pendingCommand,
          from: query.from,
          chat: { id: chatId }
        };

        setTimeout(async () => {
          if (pendingCommand === "/start") {
            await bot.emit("text", simulatedMsg);
          } else {
            await bot.emit("text", simulatedMsg);
          }
        }, 1000);

        userPendingCommands.delete(parseInt(userId));
      } else {
        setTimeout(async () => {
          await bot.emit("text", {
            ...query.message,
            text: "/start",
            from: query.from,
            chat: { id: chatId }
          });
        }, 1000);
      }

    } else {
      await editMessage(chatId, query.message.message_id, query.id,
`<b>❌ VERIFIKASI GAGAL</b>

<blockquote>📊 Status: <b>Belum Bergabung</b>
🔒 Akses: <b>Ditolak</b></blockquote>

<b>⚠️ TINDAKAN DIBUTUHKAN</b>
Silakan bergabung ke channel terlebih dahulu.

<b>🔰 PETUNJUK</b>
Klik tombol dibawah untuk bergabung`,
        {
          reply_markup: {
            inline_keyboard: [
              [{ 
                text: "📢 Join Channel", 
                url: `https://t.me/${channel.replace('@','')}` 
              }],
              [{ 
                text: "🔄 Coba Lagi", 
                callback_data: "check_join_again" 
              }]
            ]
          },
          parse_mode: 'HTML',
          disable_web_page_preview: true
        }
      );
    }
  }
  
  if (query.data === "refresh_maintenance") {
    await bot.answerCallbackQuery(query.id, {
      text: "🔄 Memeriksa status maintenance...",
      show_alert: false
    });

    const maintenance = getMaintenanceInfo();
    if (!maintenance.active) {
      await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});

      setTimeout(async () => {
        await bot.emit("text", {
          ...query.message,
          text: "/start",
          from: query.from,
          chat: { id: chatId }
        });
      }, 500);
    } else {
      await editMessage(chatId, query.message.message_id, query.id,
`<b>🛠️ BOT SEDANG MAINTENANCE</b>

<blockquote>⚙️ Status: <b>Tidak Tersedia</b>
📝 Alasan: ${maintenance.reason}</blockquote>

⚠️ Mohon tunggu hingga maintenance selesai.

<b>📞 Kontak Owner</b>
${usernamelu.replace('@','')}`,
        {
          reply_markup: {
            inline_keyboard: [
              [{ 
                text: '🔄 Refresh Status', 
                callback_data: 'refresh_maintenance' 
              }]
            ]
          },
          parse_mode: 'HTML',
          disable_web_page_preview: true
        }
      );
    }
  }
});

async function handleReferralBonus(userId, referrerId, chatId) {
    try {
        const referrerIdStr = String(referrerId);
        const userIdStr = String(userId);
        const data = loadData();
        const isReferrerValid = data.users && data.users.includes(referrerIdStr);
        
        if (!isReferrerValid) {
            return { 
                success: false, 
                error: 'Referrer tidak valid atau tidak terdaftar' 
            };
        }

        const referralResult = referralSystem.recordReferral(userIdStr, referrerIdStr);
        
        if (!referralResult) {
            return { 
                success: false, 
                error: 'Gagal menyimpan data referral' 
            };
        }

        const referrerSuccess = addUserBalance(referrerIdStr, referralSystem.REFERRER_BONUS);
        const userSuccess = addUserBalance(userIdStr, referralSystem.WELCOME_BONUS);
        
        if (referrerSuccess && userSuccess) {
            try {
                const referrerBalance = getUserBalance(referrerIdStr);
                const userBalance = getUserBalance(userIdStr);
                const referralStats = referralSystem.getReferralStats(referrerIdStr);

                await bot.sendMessage(referrerIdStr,
`👥 REFERRAL BERHASIL!

User baru bergabung via link Anda:
User ID: ${userIdStr}

<b>💰 BONUS ANDA</b>
${formatCurrency(referralSystem.REFERRER_BONUS)} (Referrer bonus)

<b>📊 SALDO ANDA</b>
Sekarang: ${formatCurrency(referrerBalance)}

<b>📈 STATISTIK REFERRAL</b>
Total referral: ${referralStats.totalReferrals} user
Total earned: ${formatCurrency(referralStats.totalEarned)}`,
                    { parse_mode: 'HTML' }
                ).catch(err => {
                });
 
                await bot.sendMessage(userIdStr,
`🎁 SELAMAT! BONUS REFERRAL

Anda bergabung via link referral dari user ${referrerIdStr}

<b>💰 BONUS ANDA</b>
${formatCurrency(referralSystem.WELCOME_BONUS)} (Welcome bonus)

<b>📊 SALDO AWAL</b>
Sekarang: ${formatCurrency(userBalance)}

<b>🔰 FITUR REFERRAL</b>
Anda juga bisa dapat saldo gratis dengan membagikan link referral Anda!`,
                    { parse_mode: 'HTML' }
                ).catch(err => {
                });
                
                try {
                    const referrerUser = await bot.getChat(referrerIdStr).catch(() => ({ 
                        first_name: 'Referrer' 
                    }));
                    
                    const newUser = await bot.getChat(userIdStr).catch(() => ({ 
                        first_name: 'New User' 
                    }));
                    
                    for (const ownerId of owner_ids) {
                        await bot.sendMessage(ownerId,
`<b>👥 REFERRAL SUKSES!</b>

<b>👤 REFERRER</b>
ID: ${referrerIdStr}
Nama: ${referrerUser.first_name || 'Referrer'}
Bonus: ${formatCurrency(referralSystem.REFERRER_BONUS)}

<b>👤 REFEREE</b>
ID: ${userIdStr}
Nama: ${newUser.first_name || 'New User'}
Bonus: ${formatCurrency(referralSystem.WELCOME_BONUS)}

<b>💰 TOTAL BONUS</b>
${formatCurrency(referralSystem.REFERRER_BONUS + referralSystem.WELCOME_BONUS)}`,
                            { parse_mode: 'HTML' }
                        ).catch(() => {});
                    }
                } catch (error) {
                }
                
                return {
                    success: true,
                    referrerBonus: referralSystem.REFERRER_BONUS,
                    welcomeBonus: referralSystem.WELCOME_BONUS,
                    referrerId: referrerIdStr,
                    userId: userIdStr
                };
                
            } catch (notifError) {
                return {
                    success: true,
                    referrerBonus: referralSystem.REFERRER_BONUS,
                    welcomeBonus: referralSystem.WELCOME_BONUS,
                    referrerId: referrerIdStr,
                    userId: userIdStr,
                    notificationError: true
                };
            }
        }
        
        return { success: false, error: 'Gagal menambahkan bonus saldo' };
        
    } catch (error) {
        console.error('Error handleReferralBonus:', error);
        return { success: false, error: error.message };
    }
}

bot.onText(/\/start/, withRequireJoin(async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const user = msg.from;
  const text = msg.text || '';
  
  if (!(await checkMaintenance(msg))) return;
  
  const referralCode = referralSystem.parseReferralCode(text);
  let isNewUser = false;
  
  const data = loadData();
  const isExistingUser = data.users && data.users.includes(String(userId));
  
  if (!isExistingUser) {
    saveUser(userId);
    isNewUser = true;
    
    if (referralCode && referralCode !== String(userId)) {
      
      const referralResult = await handleReferralBonus(userId, referralCode, chatId);
      
      if (referralResult.success) {
        
        if (!notifiedNewUsers.has(userId.toString())) {
            await sendDetailedNewUserNotification(user, getUserBalance(userId), chatId);
            notifiedNewUsers.add(userId.toString());
        }
        
        setTimeout(async () => {
          await showMainMenu(chatId, userId, user);
        }, 1000);
        
        return;
      } else {
      }
    }

    await sendNewMessage(chatId,
`🎊 SELAMAT DATANG!

<b>🔰 FITUR REFERRAL</b>
Dapatkan saldo gratis dengan:
1. Bagikan link referral Anda
2. Teman Anda join via link tersebut
3. Anda dapat ${formatCurrency(referralSystem.REFERRER_BONUS)}, teman dapat ${formatCurrency(referralSystem.WELCOME_BONUS)}

<b>💰 SALDO AWAL</b>
Anda: ${formatCurrency(getUserBalance(userId))}
Saldo gratis hanya via referral!`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '💰 Deposit Pertama', callback_data: 'deposit_main' }
            ],
            [
              { text: '👥 Dapatkan Saldo Gratis', callback_data: 'points_menu' }
            ]
          ]
        }
      }
    );
    
    if (!notifiedNewUsers.has(userId.toString())) {
      await sendDetailedNewUserNotification(user, getUserBalance(userId), chatId);
      notifiedNewUsers.add(userId.toString());
    }
    
    setTimeout(async () => {
      await showMainMenu(chatId, userId, user);
    }, 2000);
    
  } else {
    saveUser(userId);
    balanceCache.delete(userId.toString());
    await showMainMenu(chatId, userId, user);
  }
}));

bot.onText(/^\/broadcast$/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id.toString();
  const mainOwnerId = owner_ids[0];
  
  if (senderId !== mainOwnerId) {
    return await bot.sendMessage(chatId, 
`<b>❌ AKSES DITOLAK</b>

User ID: ${senderId}
Role: User Biasa

<b>⚠️ INFORMASI</b>
Hanya owner utama yang dapat menggunakan command ini.`,
      { 
        parse_mode: "HTML",
        disable_web_page_preview: true 
      }
    ).catch(() => {});
  }

  if (!msg.reply_to_message) {
    return await bot.sendMessage(chatId, 
`<b>📢 BROADCAST MESSAGE</b>

Reply pesan yang ingin di broadcast
Ketik command /broadcast

<b>📋 JENIS PESAN YANG DIDUKUNG</b>
📝 Text Message
🖼️ Photo with Caption
📎 Document with Caption
🎥 Video with Caption`,
      { 
        parse_mode: "HTML",
        disable_web_page_preview: true 
      }
    ).catch(() => {});
  }

  const data = loadData();
  const uniqueUsers = [...new Set(data.users || [])];
  const total = uniqueUsers.length;

  if (total === 0) {
    return await bot.sendMessage(chatId, 
`<b>❌ TIDAK ADA USER</b>

Total User: 0`,
      { 
        parse_mode: "HTML",
        disable_web_page_preview: true 
      }
    ).catch(() => {});
  }

  const processingMsg = await bot.sendMessage(chatId, 
`<b>⏳ MEMULAI BROADCAST</b>

Total User: ${total}
Status: ⏳ Menyiapkan...
Progress: 0%`,
    { 
      parse_mode: "HTML",
      disable_web_page_preview: true 
    }
  );

  const reply = msg.reply_to_message;
  let sukses = 0, gagal = 0;
  const broadcastHeader = `<b>📢 BROADCAST DARI ADMIN</b>\n\n`;

  for (let i = 0; i < uniqueUsers.length; i++) {
    const userId = uniqueUsers[i];
    try {
      if (reply.text) {
        const messageWithHeader = `${broadcastHeader}${reply.text}`;
        await bot.sendMessage(userId, messageWithHeader, { 
          parse_mode: 'HTML',
          disable_web_page_preview: true
        }).catch(() => {
          bot.sendMessage(userId, `${broadcastHeader}${reply.text}`).catch(() => {});
        });
      } else if (reply.photo) {
        const fileId = reply.photo[reply.photo.length - 1].file_id;
        const captionWithHeader = reply.caption ? `${broadcastHeader}${reply.caption}` : broadcastHeader;
        await bot.sendPhoto(userId, fileId, { 
          caption: captionWithHeader,
          parse_mode: 'HTML'
        }).catch(() => {});
      } else if (reply.document) {
        const captionWithHeader = reply.caption ? `${broadcastHeader}${reply.caption}` : broadcastHeader;
        await bot.sendDocument(userId, reply.document.file_id, { 
          caption: captionWithHeader,
          parse_mode: 'HTML'
        }).catch(() => {});
      } else if (reply.video) {
        const captionWithHeader = reply.caption ? `${broadcastHeader}${reply.caption}` : broadcastHeader;
        await bot.sendVideo(userId, reply.video.file_id, { 
          caption: captionWithHeader,
          parse_mode: 'HTML'
        }).catch(() => {});
      } else {
        await bot.sendMessage(userId, `${broadcastHeader}Jenis pesan ini belum bisa di broadcast.`, {
          parse_mode: 'HTML',
          disable_web_page_preview: true
        }).catch(() => {});
      }
      sukses++;
    } catch (err) {
      gagal++;
    }

    if (i % 10 === 0 || i === uniqueUsers.length - 1) {
      const progress = Math.round(((i + 1) / uniqueUsers.length) * 100);
      try {
        await bot.editMessageText(
`<b>⏳ SEDANG MEMBROADCAST</b>

Total User: ${total}
Status: 📤 Mengirim...
Progress: ${progress}%

<b>📈 INFORMASI SAAT INI</b>
✅ Sukses: ${sukses}
❌ Gagal: ${gagal}
⏳ Sisa: ${total - (i + 1)} user`,
          {
            chat_id: chatId,
            message_id: processingMsg.message_id,
            parse_mode: "HTML",
            disable_web_page_preview: true
          }
        );
      } catch {}
    }

    await new Promise(r => setTimeout(r, 200));
  }

  const successRate = Math.round((sukses / total) * 100);
  const successEmoji = successRate >= 80 ? '✅' : successRate >= 50 ? '⚠️' : '❌';
  
  try {
    await bot.editMessageText(
`<b>✅ BROADCAST SELESAI</b>

Total User: ${total}
✅ Sukses: ${sukses}
❌ Gagal: ${gagal}

<b>📊 STATISTIK DETAIL</b>
📈 Success Rate: ${successEmoji} ${successRate}%
👤 Owner: ${msg.from.first_name || 'Admin'}
🕐 Waktu: ${new Date().toLocaleString('id-ID')}`,
      {
        chat_id: chatId,
        message_id: processingMsg.message_id,
        parse_mode: "HTML",
        disable_web_page_preview: true
      }
    );
  } catch {
    await bot.sendMessage(chatId,
`<b>✅ BROADCAST SELESAI</b>

Total User: ${total}
✅ Sukses: ${sukses}
❌ Gagal: ${gagal}

<b>📊 STATISTIK DETAIL</b>
📈 Success Rate: ${successEmoji} ${successRate}%
👤 Owner: ${msg.from.first_name || 'Admin'}
🕐 Waktu: ${new Date().toLocaleString('id-ID')}`,
      { 
        parse_mode: "HTML",
        disable_web_page_preview: true 
      }
    ).catch(() => {});
  }
});

bot.onText(/^\/withdraw(?:\s+(.+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        await sendNewMessage(chatId,
`<b>❌ AKSES DITOLAK</b>

User ID: <code>${userId}</code>
Role: User Biasa

<b>⚠️ INFORMASI</b>
Hanya owner yang dapat menggunakan command ini.`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }
    
    const args = match[1];
    if (!args) {
        await sendNewMessage(chatId,
`<b>📋 MENU WITHDRAW</b>

Format: <code>/withdraw nomor,nominal</code>
Contoh: <code>/withdraw 08123456789,50000</code>

<b>📋 ATURAN</b>
• Minimal withdraw: Rp 1.000
• Metode: DANA

<b>🔰 CONTOH</b>
<code>/withdraw 08123456789,100000</code>`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }
    
    const parts = args.split(',');
    if (parts.length !== 2) {
        await sendNewMessage(chatId,
`<b>❌ FORMAT SALAH</b>

Format: <code>/withdraw nomor,nominal</code>
Contoh: <code>/withdraw 08123456789,50000</code>

<b>🔰 PENJELASAN</b>
1. Nomor: Nomor DANA tujuan (contoh: 08123456789)
2. Nominal: Jumlah yang akan di withdraw (contoh: 50000)`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }
    
    const targetNumber = parts[0].trim();
    const nominalRaw = parts[1].trim();
    const nominal = parseInt(nominalRaw.replace(/\./g, ''));
    
    if (!targetNumber.match(/^08[0-9]{8,}$/)) {
        await sendNewMessage(chatId,
`<b>❌ NOMOR TIDAK VALID</b>

Nomor: ${targetNumber}
Format: 08xxxxxxxx (minimal 10 digit)

<b>⚠️ CONTOH YANG BENAR</b>
• 08123456789 (11 digit)
• 085712345678 (12 digit)`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }
    
    if (isNaN(nominal) || nominal < 1000) {
        await sendNewMessage(chatId,
`<b>❌ NOMINAL TIDAK VALID</b>

Nominal: ${nominalRaw}
Minimal: Rp 1.000`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }
    
    if (nominal % 1000 !== 0) {
        await sendNewMessage(chatId,
`<b>❌ NOMINAL TIDAK VALID</b>

Nominal: Rp ${nominal.toLocaleString('id-ID')}
Error: Nominal harus kelipatan 1.000

<b>⚠️ CONTOH YANG BENAR</b>
• 10000
• 25000
• 50000`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }
    
    const confirmMessage = await sendNewMessage(chatId,
`<b>✅ KONFIRMASI WITHDRAW</b>

━━━━━━━━━━━━━━━━━━━

<b>📱 PENERIMA</b>
Nomor: <code>${targetNumber}</code>

<b>💰 JUMLAH</b>
Nominal: <b>Rp ${nominal.toLocaleString('id-ID')}</b>

<b>📋 INFORMASI</b>
• Minimal: Rp 1.000
• Metode: DANA
• Saldo akan dicek otomatis

━━━━━━━━━━━━━━━━━━━

<b>⚠️ KONFIRMASI</b>
Apakah Anda yakin ingin melanjutkan?`,
        { 
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { 
                            text: '✅ Ya, Lanjutkan', 
                            callback_data: `confirm_withdraw_${targetNumber}_${nominal}` 
                        }
                    ],
                    [
                        { 
                            text: '❌ Batalkan', 
                            callback_data: 'main_menu' 
                        }
                    ]
                ]
            }
        }
    );
});

async function processWithdraw(chatId, userId, targetNumber, nominal, messageId, callbackQueryId) {
    try {
        await editMessage(chatId, messageId, callbackQueryId,
`<b>⏳ MEMULAI PROSES WITHDRAW...</b>

Nomor: ${targetNumber}
Nominal: Rp ${nominal.toLocaleString('id-ID')}
Status: ⏳ Mengecek saldo...`,
            { parse_mode: 'HTML' }
        );
        
        const saldoResult = await withdrawApi.getRumahOTPSaldo();
        
        if (!saldoResult.success) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MENGECEK SALDO</b>

Error: Tidak dapat terhubung ke server RumahOTP

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
                { parse_mode: 'HTML' }
            );
            return;
        }
        
        const saldo = saldoResult.balance;
        const formattedSaldo = saldoResult.formatted;
        
        if (saldo < nominal) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ SALDO TIDAK CUKUP</b>

Saldo RumahOTP: ${formattedSaldo}
Dibutuhkan: Rp ${nominal.toLocaleString('id-ID')}
Kekurangan: Rp ${(nominal - saldo).toLocaleString('id-ID')}

<b>⚠️ TINDAKAN</b>
Topup saldo RumahOTP terlebih dahulu.`,
                { parse_mode: 'HTML' }
            );
            return;
        }
        
        await editMessage(chatId, messageId, callbackQueryId,
`<b>🔍 MENCARI PRODUK DANA...</b>

Nomor: ${targetNumber}
Nominal: Rp ${nominal.toLocaleString('id-ID')}
Saldo Tersedia: ${formattedSaldo}
Status: ⏳ Mencari produk...`,
            { parse_mode: 'HTML' }
        );
        
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        const productResult = await withdrawApi.getDanaProduct(nominal);
        
        if (!productResult.success) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ PRODUK TIDAK TERSEDIA</b>

Error: ${productResult.message || 'Tidak ada produk DANA yang sesuai'}

<b>⚠️ TINDAKAN</b>
Coba nominal yang berbeda (minimal 10.000).`,
                { parse_mode: 'HTML' }
            );
            return;
        }
        
        const product = productResult.data;
        const actualAmount = product.price;
        
        await editMessage(chatId, messageId, callbackQueryId,
`<b>🚀 MEMBUAT TRANSAKSI...</b>

Nomor: ${targetNumber}
Produk: DANA ${product.denom || product.name}
Harga: Rp ${actualAmount.toLocaleString('id-ID')}
Kode: ${product.code}
Status: ⏳ Membuat transaksi...`,
            { parse_mode: 'HTML' }
        );
        
        const txResult = await withdrawApi.createTransaction(targetNumber, product.code);
        
        if (!txResult.success) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MEMBUAT TRANSAKSI</b>

Error: ${txResult.message || 'Transaksi gagal dibuat'}

<b>⚠️ TINDAKAN</b>
Silakan coba lagi.`,
                { parse_mode: 'HTML' }
            );
            return;
        }
        
        const transaction = txResult.data;
        
        await editMessage(chatId, messageId, callbackQueryId,
`<b>📡 MEMERIKSA STATUS...</b>

ID Transaksi: ${transaction.id}
Nomor: ${targetNumber}
Nominal: Rp ${actualAmount.toLocaleString('id-ID')}
Status: ⏳ Menunggu konfirmasi...`,
            { parse_mode: 'HTML' }
        );
        
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        const statusResult = await withdrawApi.checkTransaction(transaction.id);
        
        let statusText = 'PROSES';
        if (statusResult.success) {
            statusText = statusResult.data?.status || 'PROSES';
        }
        
        const now = new Date();
        const timeStr = now.toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        
        const remainingBalance = saldo - actualAmount;
        
        await editMessage(chatId, messageId, callbackQueryId,
`<b>✅ WITHDRAW BERHASIL DIPROSES</b>

━━━━━━━━━━━━━━━━━━━

<b>📱 INFORMASI PENERIMA</b>
Nomor: <code>${targetNumber}</code>
Metode: DANA

<b>💰 INFORMASI TRANSAKSI</b>
Nominal: <b>Rp ${actualAmount.toLocaleString('id-ID')}</b>
Status: <b>${statusText}</b>
ID Transaksi: <code>${transaction.id}</code>
Waktu: ${timeStr}

<b>💳 INFORMASI SALDO</b>
Saldo Sebelum: ${formattedSaldo}
Saldo Sesudah: Rp ${remainingBalance.toLocaleString('id-ID')}
Pengurangan: Rp ${actualAmount.toLocaleString('id-ID')}

━━━━━━━━━━━━━━━━━━━

<b>⚠️ CATATAN</b>
• Transaksi akan diproses oleh sistem
• Biasanya memakan waktu 1-5 menit
• Jika gagal, saldo akan dikembalikan otomatis`,
            { parse_mode: 'HTML' }
        );
        
    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ TERJADI KESALAHAN</b>

Error: ${error.message || 'Internal server error'}

<b>⚠️ TINDAKAN</b>
Silakan hubungi developer.`,
            { parse_mode: 'HTML' }
        );
    }
}

bot.onText(/^\/setpay$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  if (!owner_ids.includes(userId)) {
    return bot.sendMessage(chatId, 
`<b>❌ AKSES DITOLAK</b>

User ID: <code>${userId}</code>
Role: User Biasa

<b>⚠️ INFORMASI</b>
Hanya owner yang dapat mengganti metode pembayaran.`,
      { 
        parse_mode: 'HTML',
        disable_web_page_preview: true 
      }
    );
  }
  
  const currentMethod = getPaymentMethod();
  const isRumahOTP = currentMethod === 'rumahotp';
  const isKhafa = currentMethod === 'khafa';
  const message = `<b>⚙️ SETTING METODE PEMBAYARAN</b>

🏦 Rumah OTP: ${isRumahOTP ? '✅ Aktif' : '❌ Nonaktif'}
💳 Khafa: ${isKhafa ? '✅ Aktif' : '❌ Nonaktif'}

<b>📋 PILIH METODE</b>
Klik tombol untuk mengganti metode:`;
  
  await bot.sendMessage(chatId, message, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { 
            text: isRumahOTP ? '✅ RUMAH OTP' : '🏦 RUMAH OTP', 
            callback_data: 'setpay_rumahotp' 
          },
          { 
            text: isKhafa ? '✅ KHAFA' : '💳 KHAFA', 
            callback_data: 'setpay_khafa' 
          }
        ]
      ]
    },
    disable_web_page_preview: true
  });
});

bot.onText(/^\/backup$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        await bot.sendMessage(chatId,
`<b>❌ AKSES DITOLAK</b>

User ID: <code>${userId}</code>
Role: User Biasa

<b>⚠️ INFORMASI</b>
Hanya owner yang dapat membuat backup.`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }
    
    try {
        const now = new Date();
        const dateStr = now.toISOString().split('T')[0];
        const timeStr = now.getHours().toString().padStart(2, '0') + '-' + 
                       now.getMinutes().toString().padStart(2, '0') + '-' +
                       now.getSeconds().toString().padStart(2, '0');
        
        const backupFileName = `manual_backup_${dateStr}_${timeStr}.zip`;
        const processingMsg = await bot.sendMessage(chatId,
`<b>📦 MEMBUAT BACKUP MANUAL</b>

Status: ⏳ Menyiapkan data...
Nama File: ${backupFileName}
Owner: ${userId}`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        
        const archive = archiver('zip', { zlib: { level: 9 } });
        const chunks = [];
        
        archive.on('data', (chunk) => chunks.push(chunk));
        archive.on('error', (err) => {
            throw err;
        });
        
        const backupFiles = [
            { name: 'balances.json', file: balanceFile },
            { name: 'users.json', file: datafile },
            { name: 'transactions.json', file: transactionsFile },
            { name: 'settings.json', file: settingsFile }
        ];
        
        let fileCount = 0;
        for (const file of backupFiles) {
            if (fs.existsSync(file.file)) {
                const fileBuffer = fs.readFileSync(file.file);
                archive.append(fileBuffer, { name: file.name });
                fileCount++;
            }
        }
        
        await archive.finalize();
        const zipBuffer = Buffer.concat(chunks);
        const fileSizeKB = (zipBuffer.length / 1024).toFixed(2);
        
        await bot.deleteMessage(chatId, processingMsg.message_id);

        await bot.sendDocument(chatId, zipBuffer, {
            caption: `<b>✅ BACKUP MANUAL BERHASIL</b>

Nama File: ${backupFileName}
Jumlah File: ${fileCount}
Size ZIP: ${fileSizeKB} KB
Owner: ${userId}`,
            parse_mode: 'HTML',
            filename: backupFileName
        });
        
    } catch (error) {
        await bot.sendMessage(chatId,
`<b>❌ GAGAL MEMBUAT BACKUP</b>

Error: ${error.message || 'Unknown error'}`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
    }
});

bot.onText(/^\/maintenance/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  if (!owner_ids.includes(userId)) {
    return bot.sendMessage(chatId, 
`<b>❌ AKSES DITOLAK</b>

User ID: <code>${userId}</code>
Role: User Biasa

<b>⚠️ INFORMASI</b>
Hanya owner yang dapat menggunakan command ini.`,
      { 
        parse_mode: 'HTML',
        disable_web_page_preview: true 
      }
    );
  }
  
  const text = msg.text || '';
  const args = text.trim().split(/\s+/);
  
  if (args.length === 1) {
    const maintenance = getMaintenanceInfo();
    const statusEmoji = maintenance.active ? '⛔' : '✅';
    const statusText = maintenance.active ? 'ON (Aktif)' : 'OFF (Nonaktif)';
    
    return bot.sendMessage(chatId,
`<b>🛠️ STATUS MAINTENANCE</b>

Status: ${statusEmoji} ${statusText}
${maintenance.reason ? `Alasan: ${maintenance.reason}` : ''}

<b>📋 FORMAT COMMAND</b>
/maintenance on (reply pesan untuk alasan)
/maintenance off`,
      { 
        parse_mode: 'HTML',
        disable_web_page_preview: true 
      }
    );
  }
  
  const command = args[1].toLowerCase();
  
  if (command === 'off') {
    setMaintenance(false);
    return bot.sendMessage(chatId,
`<b>✅ MAINTENANCE MODE DIMATIKAN</b>

Status: ✅ Nonaktif`,
      { 
        parse_mode: 'HTML',
        disable_web_page_preview: true 
      }
    );
  }
  
  if (command === 'on') {
    if (!msg.reply_to_message) {
      return bot.sendMessage(chatId,
`<b>⚠️ PERLU ALASAN MAINTENANCE</b>

Ketik alasan maintenance
Reply pesan tersebut
Kirim /maintenance on`,
        { 
          parse_mode: 'HTML',
          disable_web_page_preview: true 
        }
      );
    }
    
    const reason = msg.reply_to_message.text || 'Bot sedang dalam perbaikan';
    setMaintenance(true, reason);
    
    return bot.sendMessage(chatId,
`<b>⛔ MAINTENANCE MODE DIAKTIFKAN</b>

Status: ⛔ Aktif
Alasan: ${reason}`,
      { 
        parse_mode: 'HTML',
        disable_web_page_preview: true 
      }
    );
  }
  
  bot.sendMessage(chatId,
`<b>❌ FORMAT SALAH</b>

/maintenance on
/maintenance off`,
    { 
      parse_mode: 'HTML',
      disable_web_page_preview: true 
    }
  );
});

bot.onText(/^\/addsaldo(\s|$)/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        await bot.sendMessage(chatId,
            `Akses ditolak.

Command ini hanya untuk Admin
Silakan hubungi Admin untuk bantuan`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    await addBalanceAdmin(chatId, userId, msg.text);
});

bot.onText(/^\/delsaldo(\s|$)/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        await bot.sendMessage(chatId,
            `Akses ditolak.
Command ini hanya untuk Admin`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    const parts = msg.text.split(' ');
    if (parts.length < 3) {
        await bot.sendMessage(chatId,
`<b>❌ FORMAT SALAH</b>

Format: /delsaldo [user_id] [jumlah]
Contoh: /delsaldo 727281 50000`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    const targetUserId = parts[1];
    const amount = parseInt(parts[2]);
    
    if (isNaN(amount) || amount <= 0) {
        await bot.sendMessage(chatId,
`<b>❌ JUMLAH TIDAK VALID</b>

Jumlah harus angka positif`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    const currentBalance = getUserBalance(targetUserId);
    if (currentBalance < amount) {
        await bot.sendMessage(chatId,
`<b>❌ SALDO TIDAK CUKUP</b>

Saldo user: ${formatCurrency(currentBalance)}
Jumlah yang akan dikurangi: ${formatCurrency(amount)}`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    const success = deductUserBalance(targetUserId, amount);
    if (!success) {
        await bot.sendMessage(chatId,
`<b>❌ GAGAL MENGURANGI SALDO</b>

Terjadi kesalahan sistem`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    const newBalance = getUserBalance(targetUserId);
    
    await bot.sendMessage(chatId,
`<b>✅ SALDO BERHASIL DIKURANGI</b>

User ID: ${targetUserId}
➖ Dikurangi: ${formatCurrency(amount)}
💰 Saldo Lama: ${formatCurrency(currentBalance)}
💰 Saldo Baru: ${formatCurrency(newBalance)}
👤 Admin: ${userId}`,
        { parse_mode: 'HTML' }
    );
});

bot.onText(/^\/listsaldo$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        await bot.sendMessage(chatId,
            `Akses ditolak.
Command ini hanya untuk Admin`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    const balances = loadBalances();
    const transactions = loadTransactions();
    
    const allUsers = Object.entries(balances)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 50);
    
    if (allUsers.length === 0) {
        await bot.sendMessage(chatId,
            `<b>📋 DAFTAR SALDO</b>
Belum ada user dengan saldo`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    let message = `<b>📋 DAFTAR SALDO (TOP 50)</b>\n\n`;
    
    for (let i = 0; i < allUsers.length; i++) {
        const [userId, balance] = allUsers[i];
        
        try {
            const user = await bot.getChat(userId);
            const username = user.username ? `@${user.username}` : 'No username';
            
            const userOrders = transactions.nokos_orders?.filter(order => 
                String(order.userId) === String(userId)
            ) || [];
            
            const userDeposits = [
                ...(transactions.rumahotp_deposits?.filter(deposit => 
                    String(deposit.userId) === String(userId) && 
                    (deposit.status === 'success' || deposit.status === 'paid')
                ) || []),
                ...(transactions.khafa_deposits?.filter(deposit => 
                    String(deposit.userId) === String(userId) && 
                    (deposit.status === 'success' || deposit.status === 'paid')
                ) || [])
            ];
            
            message += `${i + 1}. ${username} (${userId})\n`;
            message += `   ${formatCurrency(balance)} / ${userOrders.length}x order / ${userDeposits.length}x deposit\n\n`;
            
        } catch {
            const userOrders = transactions.nokos_orders?.filter(order => 
                String(order.userId) === String(userId)
            ) || [];
            
            const userDeposits = [
                ...(transactions.rumahotp_deposits?.filter(deposit => 
                    String(deposit.userId) === String(userId) && 
                    (deposit.status === 'success' || deposit.status === 'paid')
                ) || []),
                ...(transactions.khafa_deposits?.filter(deposit => 
                    String(deposit.userId) === String(userId) && 
                    (deposit.status === 'success' || deposit.status === 'paid')
                ) || [])
            ];
            
            message += `${i + 1}. User ${userId}\n`;
            message += `   ${formatCurrency(balance)} / ${userOrders.length}x order / ${userDeposits.length}x deposit\n\n`;
        }
        
        if (i >= 49) break;
    }
    
    const totalBalance = Object.values(balances).reduce((sum, b) => sum + (Number(b) || 0), 0);
    message += `<b>📊 TOTAL: ${formatCurrency(totalBalance)}</b>`;
    
    await bot.sendMessage(chatId, message, { 
        parse_mode: 'HTML',
        disable_web_page_preview: true 
    });
});

bot.onText(/^\/stats$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        await bot.sendMessage(chatId,
            "<b>❌ AKSES DITOLAK</b>\n\nCommand ini hanya untuk Admin",
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    try {
        const data = loadData();
        const balances = loadBalances();
        const transactions = loadTransactions();
        
        const fetchRumahOTPBalance = async () => {
            try {
                const response = await axios.get(`${config.domain}/v1/user/balance`, {
                    headers: {
                        'x-apikey': config.apikey,
                        'Accept': 'application/json'
                    },
                    timeout: 10000
                });
                
                if (response.data && response.data.success) {
                    return Number(response.data.data?.balance || response.data.data?.saldo || 0);
                }
                return 0;
            } catch (error) {
                console.error('Gagal mengambil saldo Rumah OTP:', error.message);
                return -1; 
            }
        };

        const fetchKhafaBalance = async () => {
            try {
                const response = await axios.get('https://khafatopup.my.id/h2h/profile', {
                    headers: {
                        'X-APIKEY': config.khafa_apikey,
                        'Content-Type': 'application/json'
                    },
                    timeout: 10000
                });

                if (response.data && response.data.success) {
                    return Number(response.data.user?.saldo || response.data.data?.saldo || 0);
                }
                return 0;
            } catch (error) {
                console.error('Gagal mengambil saldo Khafa:', error.message);
                return -1;
            }
        };

        const balancePromises = [
            fetchRumahOTPBalance(),
            fetchKhafaBalance()
        ];
        
        const timeoutPromise = (promise, ms) => {
            return Promise.race([
                promise,
                new Promise((_, reject) => 
                    setTimeout(() => reject(new Error('Timeout')), ms)
                )
            ]);
        };
        
        let rumahOTPBalance = -1;
        let khafaBalance = -1;
        
        try {
            const [rumahOTPResult, khafaResult] = await Promise.allSettled([
                timeoutPromise(balancePromises[0], 8000),
                timeoutPromise(balancePromises[1], 8000)
            ]);
            
            rumahOTPBalance = rumahOTPResult.status === 'fulfilled' ? rumahOTPResult.value : -1;
            khafaBalance = khafaResult.status === 'fulfilled' ? khafaResult.value : -1;
            
        } catch (error) {
            console.error('Error fetching balances:', error);
        }
        
        const totalUsers = data.users?.length || 0;
        const totalOrders = transactions.nokos_orders?.length || 0;
        const rumahOTPDeposits = transactions.rumahotp_deposits || [];
        const khafaDeposits = transactions.khafa_deposits || [];      
        const successfulRumahOTPDeposits = rumahOTPDeposits.filter(deposit => 
            deposit.status === 'success' || deposit.status === 'paid'
        ).length;
        
        const successfulKhafaDeposits = khafaDeposits.filter(deposit => 
            deposit.status === 'success' || deposit.status === 'paid'
        ).length;
        
        const totalSuccessfulDeposits = successfulRumahOTPDeposits + successfulKhafaDeposits;
        
        const calculateTotalDepositAmount = (deposits) => {
            return deposits.reduce((sum, deposit) => {
                if (deposit.status === 'success' || deposit.status === 'paid') {
                    const amount = Number(deposit.data?.amount) || 
                                   Number(deposit.data?.nominal) || 
                                   Number(deposit.data?.total) || 
                                   0;
                    return sum + amount;
                }
                return sum;
            }, 0);
        };
        
        const rumahOTPTotalDeposit = calculateTotalDepositAmount(rumahOTPDeposits);
        const khafaTotalDeposit = calculateTotalDepositAmount(khafaDeposits);
        const totalDepositAmount = rumahOTPTotalDeposit + khafaTotalDeposit;
        const totalOrderAmount = (transactions.nokos_orders || []).reduce((sum, order) => {
            if (order.status === 'completed' || order.status === 'success' || 
                order.data?.otp_received === true || 
                (order.data?.otp_code && order.data?.otp_code !== '-' && order.data?.otp_code !== '')) {
                return sum + (Number(order.data?.total || order.data?.price || 0));
            }
            return sum;
        }, 0);
        
        const totalBalance = Object.values(balances).reduce((sum, balance) => sum + (Number(balance) || 0), 0);
        
        const formatBalanceDisplay = (balance, gatewayName) => {
            if (balance === -1) return `❌ ${gatewayName}: Gagal fetch`;
            return `${formatCurrency(balance)}`;
        };
        
        const formatDepositCount = (count) => {
            return count > 0 ? `${count}x` : '-';
        };

        let totalGatewayBalance = 0;
        let gatewayCount = 0;
        
        if (rumahOTPBalance >= 0) {
            totalGatewayBalance += rumahOTPBalance;
            gatewayCount++;
        }
        if (khafaBalance >= 0) {
            totalGatewayBalance += khafaBalance;
            gatewayCount++;
        }
        
        const message = `<b>📊 STATISTIK BOT</b>

📅 ${new Date().toLocaleDateString('id-ID')}
🕐 ${new Date().toLocaleTimeString('id-ID')}

<b>📈 OVERVIEW SISTEM</b>
• Total User: ${totalUsers.toLocaleString('id-ID')}
• Total Order: ${totalOrders.toLocaleString('id-ID')}
• Deposit Sukses: ${totalSuccessfulDeposits.toLocaleString('id-ID')}
• Saldo User: ${formatCurrency(totalBalance)}

<b>🌐 SALDO GATEWAY (SALDO ASLI)</b>
${rumahOTPBalance >= 0 ? `• Rumah OTP: ${formatCurrency(rumahOTPBalance)}` : '• Rumah OTP: ❌ Gagal fetch'}
${khafaBalance >= 0 ? `• Khafa: ${formatCurrency(khafaBalance)}` : '• Khafa: ❌ Gagal fetch'}
${gatewayCount > 0 ? `• Total Gateway: ${formatCurrency(totalGatewayBalance)} (${gatewayCount}/2 berhasil)` : '• Total Gateway: ❌ Semua gateway gagal'}

<b>💵 STATISTIK KEUANGAN</b>
• Total Deposit: ${formatCurrency(totalDepositAmount)}
• Total Order: ${formatCurrency(totalOrderAmount)}
• Profit: ${formatCurrency(totalDepositAmount - totalOrderAmount)}

<b>📊 DEPOSIT PER GATEWAY</b>
• Rumah OTP: ${formatDepositCount(successfulRumahOTPDeposits)} (${formatCurrency(rumahOTPTotalDeposit)})
• Khafa: ${formatDepositCount(successfulKhafaDeposits)} (${formatCurrency(khafaTotalDeposit)})

<b>⚙️ STATUS SISTEM</b>
• Maintenance: ${isMaintenance() ? '⛔ Aktif' : '✅ Normal'}
• Payment Method: ${getPaymentMethod().toUpperCase()}
• Last Update: ${new Date().toLocaleString('id-ID')}`;

        await bot.sendMessage(chatId, message, { 
            parse_mode: 'HTML',
            disable_web_page_preview: true 
        });
        
    } catch (error) {
        console.error('Error in /stats command:', error);
        await bot.sendMessage(chatId,
            `<b>❌ GAGAL MENGAMBIL STATISTIK</b>\n\nError: ${error.message || 'Unknown error'}`,
            { parse_mode: 'HTML' }
        );
    }
});

bot.onText(/^\/addproduct(?:\s+(.+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id.toString();
    
    const mainOwnerId = owner_ids[0];
    if (senderId !== mainOwnerId) {
        return await sendNewMessage(chatId, 
            "<b>❌ AKSES DITOLAK</b>\n\nHanya owner utama yang dapat menggunakan command ini.",
            { parse_mode: "HTML" }
        );
    }

    if (!msg.reply_to_message) {
        return await sendNewMessage(chatId,
            `<b>❌ FORMAT SALAH</b>

<b>📝 Format yang benar:</b>
1. Reply file dengan command /addproduct
2. Format: <code>/addproduct nama|harga|stock|deskripsi|code</code>

<b>💡 Contoh:</b>
<code>/addproduct KyzzBotz|2000|999|Script Telegram Bot Premium|kyzz1</code>

<b>⚠️ Note:</b> Reply file yang ingin diupload`,
            { parse_mode: "HTML" }
        );
    }

    const hasDocument = msg.reply_to_message.document;
    const hasPhoto = msg.reply_to_message.photo;
    const hasText = msg.reply_to_message.text;

    if (!hasDocument && !hasPhoto && !hasText) {
        return await sendNewMessage(chatId,
            "<b>❌ FILE TIDAK DIDUKUNG</b>\n\nHanya support: Document, Photo, Text file",
            { parse_mode: "HTML" }
        );
    }

    const paramsText = match[1];
    
    if (!paramsText) {
        return await sendNewMessage(chatId,
            `<b>❌ PARAMETER TIDAK LENGKAP</b>

<b>📝 Format:</b>
<code>/addproduct nama|harga|stock|deskripsi|code</code>

<b>🔢 Parameter yang dibutuhkan:</b>
1. Nama produk
2. Harga (angka)
3. Stock (angka)  
4. Deskripsi
5. Kode pembelian

<b>💡 Contoh:</b>
<code>/addproduct KyzzBotz|2000|999|Script Telegram Bot Premium|kyzz1</code>`,
            { parse_mode: "HTML" }
        );
    }

    const params = paramsText.split('|');
    if (params.length !== 5) {
        return await sendNewMessage(chatId,
            `<b>❌ PARAMETER TIDAK LENGKAP</b>

<b>📝 Format:</b>
<code>/addproduct nama|harga|stock|deskripsi|code</code>

<b>🔢 Parameter yang dibutuhkan:</b>
1. Nama produk
2. Harga (angka)
3. Stock (angka)  
4. Deskripsi
5. Kode pembelian

<b>💡 Contoh:</b>
<code>/addproduct KyzzBotz|2000|999|Script Telegram Bot Premium|kyzz1</code>`,
            { parse_mode: "HTML" }
        );
    }

    const [name, priceStr, stockStr, description, code] = params;
    const price = parseInt(priceStr.replace(/\./g, ''));
    const stock = parseInt(stockStr);

    if (isNaN(price) || price < 2000) {
        return await sendNewMessage(chatId,
            "<b>❌ HARGA TIDAK VALID</b>\n\nHarga minimal Rp 1,000",
            { parse_mode: "HTML" }
        );
    }

    if (isNaN(stock) || stock < 0) {
        return await sendNewMessage(chatId,
            "<b>❌ STOCK TIDAK VALID</b>",
            { parse_mode: "HTML" }
        );
    }

    try {
        let fileData = {
            fileId: '',
            fileName: '',
            fileType: '',
            textContent: ''
        };

        if (msg.reply_to_message.document) {
            const document = msg.reply_to_message.document;
            fileData.fileId = document.file_id;
            fileData.fileName = document.file_name;
            fileData.fileType = 'document';
        } else if (msg.reply_to_message.photo) {
            const photo = msg.reply_to_message.photo[msg.reply_to_message.photo.length - 1];
            fileData.fileId = photo.file_id;
            fileData.fileName = 'photo.jpg';
            fileData.fileType = 'photo';
        } else if (msg.reply_to_message.text) {
            fileData.fileId = 'text';
            fileData.fileName = 'text.txt';
            fileData.fileType = 'text';
            fileData.textContent = msg.reply_to_message.text;
        }

        const productDB = loadDataProduct();
        
        const existingProduct = Object.values(productDB.products).find(p => p.buyCode.toLowerCase() === code.toLowerCase());
        if (existingProduct) {
            return await sendNewMessage(chatId,
                `<b>❌ KODE SUDAH DIGUNAKAN</b>\n\nKode <code>${code}</code> sudah digunakan oleh produk lain.`,
                { parse_mode: "HTML" }
            );
        }

        const productId = generateProductId(name);
        
        productDB.products[productId] = {
            id: productId,
            name: name,
            price: price,
            stock: stock,
            buyCode: code,
            desc: description,
            fileData: fileData,
            type: 'digital',
            createdAt: new Date().toISOString(),
            status: stock > 0 ? 'active' : 'out_of_stock'
        };

        const saved = saveDataProduct(productDB);

        if (!saved) {
            throw new Error('Gagal menyimpan produk');
        }

        await sendNewMessage(chatId,
            `<b>✅ PRODUK BERHASIL DITAMBAHKAN!</b>

<b>📦 Nama:</b> ${name}
<b>💰 Harga:</b> ${formatCurrency(price)}
<b>📊 Stock:</b> ${stock}
<b>🏷️ Kode:</b> <code>${code}</code>
<b>📝 Deskripsi:</b> ${description}
<b>📁 File:</b> ${fileData.fileName} (${fileData.fileType})

<b>🎯 User bisa beli dengan:</b>
<code>/buy ${code}</code> atau tombol di menu produk`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "🛒 LIHAT PRODUK", callback_data: "menu_products" }]
                    ]
                }
            }
        );

    } catch (error) {
        console.error('Error adding product:', error);
        await sendNewMessage(chatId,
            `<b>❌ GAGAL MENAMBAH PRODUK</b>\n\nError: ${error.message}`,
            { parse_mode: "HTML" }
        );
    }
});

async function showProductsMenu(chatId, userId, messageId, callbackQueryId) {
    const productDB = loadDataProduct();
    const products = Object.values(productDB.products || {});
    
    if (products.length === 0) {
        return await editMessage(chatId, messageId, callbackQueryId,
            `<b>📦 DAFTAR PRODUK</b>

❌ Belum ada produk tersedia

Admin sedang mempersiapkan produk terbaik!`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "🔙 Menu Utama", callback_data: "main_menu" }]
                    ]
                }
            }
        );
    }

    let message = `<b>🛍️ DAFTAR PRODUK SCRIPT</b>

━━━━━━━━━━━━━━━━━━━

<b>PILIH PRODUK YANG DIINGINKAN</b>
━━━━━━━━━━━━━━━━━━━\n`;

    products.forEach((product, index) => {
        const stockStatus = product.stock > 0 ? `✅ TERSEDIA` : `❌ HABIS`;
        const stockCount = product.stock > 0 ? product.stock : 0;
        
        message += `<b>[ ${index + 1} ] ${product.name}</b>\n`;
        message += `╰┈➤ ${formatCurrency(product.price)}\n`;
        message += `━━━━━━━━━━━━━━━━━━━\n`;
        message += `<b>Deskripsi:</b> ${product.desc}\n`;
        message += `<b>Kode:</b> <code>${product.buyCode}</code>\n`;
        message += `<b>Stok:</b> ${stockStatus} (${stockCount})\n\n`;
    });

    message += `━━━━━━━━━━━━━━━━━━━\n`;
    message += `<b>📋 CARA PEMBELIAN:</b>\n`;
    message += `1. Klik tombol BELI di bawah\n`;
    message += `2. Pilih metode pembayaran\n`;
    message += `3. File akan dikirim otomatis\n`;

    const keyboard = [];
    
    products.forEach((product, index) => {
        if (product.status === 'active' && product.stock > 0) {
            keyboard.push([
                { 
                    text: `🛒 Beli ${product.name}`,
                    callback_data: `buy_${product.buyCode}`
                }
            ]);
        } else {
            keyboard.push([
                { 
                    text: `❌ ${product.name} - Habis`,
                    callback_data: "no_action"
                }
            ]);
        }
    });

    keyboard.push([
        { text: "💰 Deposit", callback_data: "deposit_main" },
        { text: "🔙 Menu Utama", callback_data: "main_menu" }
    ]);

    await editMessage(chatId, messageId, callbackQueryId, message, {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "HTML"
    });
}

async function showProductPaymentOptions(chatId, userId, productCode, messageId, callbackQueryId) {
    const productDB = loadDataProduct();
    
    let productFound = null;
    
    for (const product of Object.values(productDB.products)) {
        if (product.buyCode.toLowerCase() === productCode.toLowerCase()) {
            productFound = product;
            break;
        }
    }

    if (!productFound) {
        return await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ PRODUK TIDAK DITEMUKAN</b>

Kode produk <code>${productCode}</code> tidak ditemukan.`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "🛒 Produk Lain", callback_data: "menu_products" }]
                    ]
                }
            }
        );
    }

    if (productFound.stock <= 0) {
        return await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ STOK HABIS</b>

Produk <b>${productFound.name}</b> sedang tidak tersedia.`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "🛒 Produk Lain", callback_data: "menu_products" }]
                    ]
                }
            }
        );
    }

    userSelections.set(userId, {
        step: 'product_payment',
        productCode: productFound.buyCode,
        productId: productFound.id,
        productName: productFound.name,
        productPrice: productFound.price
    });

    const userBalance = getUserBalance(userId);
    const canUseBalance = userBalance >= productFound.price;

    const message = `<b>🛒 KONFIRMASI PEMBELIAN</b>

━━━━━━━━━━━━━━━━━━━

<b>Produk:</b> ${productFound.name}
<b>Harga:</b> ${formatCurrency(productFound.price)}
<b>Kode:</b> <code>${productFound.buyCode}</code>
<b>Deskripsi:</b> ${productFound.desc}

━━━━━━━━━━━━━━━━━━━

<b>💳 METODE PEMBAYARAN</b>
• Saldo Bot (${canUseBalance ? '✅ Cukup' : '❌ Kurang'})
• QRIS (Pembayaran instan)

<b>💰 SALDO ANDA</b>
${formatCurrency(userBalance)}
${canUseBalance ? '✅ Cukup untuk membeli dengan saldo' : '❌ Tidak cukup, gunakan QRIS'}

━━━━━━━━━━━━━━━━━━━

<b>📋 KONFIRMASI</b>
Pilih metode pembayaran untuk melanjutkan:`;

    const keyboard = [
        [
            { 
                text: canUseBalance ? "💳 Bayar Saldo" : "❌ Saldo Tidak Cukup", 
                callback_data: canUseBalance ? `pay_product_${productFound.buyCode}_saldo` : "no_action"
            }
        ],
        [
            { 
                text: "📱 Bayar QRIS", 
                callback_data: `pay_product_${productFound.buyCode}_qris`
            }
        ],
        [
            { text: "🔙 Kembali", callback_data: "menu_products" },
            { text: "🏠 Menu Utama", callback_data: "main_menu" }
        ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "HTML"
    });
}

async function showProductOrderConfirmation(chatId, userId, productCode, paymentMethod, messageId, callbackQueryId) {
    const productDB = loadDataProduct();
    
    let productFound = null;
    
    for (const product of Object.values(productDB.products)) {
        if (product.buyCode.toLowerCase() === productCode.toLowerCase()) {
            productFound = product;
            break;
        }
    }

    if (!productFound) {
        return await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ PRODUK TIDAK DITEMUKAN</b>`,
            { parse_mode: "HTML" }
        );
    }

    if (productFound.stock <= 0) {
        return await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ STOK HABIS</b>`,
            { parse_mode: "HTML" }
        );
    }

    const userBalance = getUserBalance(userId);
    const paymentMethodName = paymentMethod === 'saldo' ? 'Saldo Bot' : 'QRIS';
    
    const message = `<b>✅ KONFIRMASI PEMESANAN</b>

━━━━━━━━━━━━━━━━━━━

<b>Produk:</b> ${productFound.name}
<b>Harga:</b> ${formatCurrency(productFound.price)}
<b>Kode:</b> <code>${productFound.buyCode}</code>
<b>Metode:</b> ${paymentMethodName}

━━━━━━━━━━━━━━━━━━━

<b>💰 INFORMASI SALDO</b>
Saldo Anda: ${formatCurrency(userBalance)}
${paymentMethod === 'saldo' ? 
    `Sisa saldo: ${formatCurrency(userBalance - productFound.price)}` : 
    `Total bayar: ${formatCurrency(productFound.price)}`}

━━━━━━━━━━━━━━━━━━━

<b>⚠️ PERHATIAN</b>
• Pastikan data sudah benar
• Pembelian tidak dapat dibatalkan
• File akan dikirim otomatis setelah pembayaran

━━━━━━━━━━━━━━━━━━━

<b>Apakah Anda yakin ingin membeli produk ini?</b>`;

    const keyboard = [
        [
            { 
                text: "✅ Ya, Lanjutkan Pembayaran", 
                callback_data: `confirm_product_${productFound.buyCode}_${paymentMethod}`
            }
        ],
        [
            { 
                text: "❌ Batalkan", 
                callback_data: `pay_product_${productFound.buyCode}_${paymentMethod}`
            }
        ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "HTML"
    });
}

async function processProductPayment(chatId, userId, productCode, paymentMethod, messageId, callbackQueryId) {
    const productDB = loadDataProduct();

    let productFound = null;
    let productId = null;

    for (const [id, product] of Object.entries(productDB.products)) {
        if (product.buyCode.toLowerCase() === productCode.toLowerCase()) {
            productFound = product;
            productId = id;
            break;
        }
    }

    if (!productFound || productFound.stock <= 0) {
        return await editMessage(
            chatId,
            messageId,
            callbackQueryId,
            `<b>❌ PRODUK TIDAK TERSEDIA</b>`,
            { parse_mode: "HTML" }
        );
    }

    if (paymentMethod === 'saldo') {
        const productPrice = Number(productFound.price);
        const additionalFee = Number(product_fee) || 0;
        const totalPrice = productPrice + additionalFee;
        const userBalance = Number(getUserBalance(userId));

        if (isNaN(productPrice) || isNaN(totalPrice)) {
            return await editMessage(
                chatId,
                messageId,
                callbackQueryId,
                `<b>❌ ERROR HARGA</b>\n\nSilakan ulangi transaksi.`,
                { parse_mode: "HTML" }
            );
        }

        if (userBalance < totalPrice) {
            return await editMessage(
                chatId,
                messageId,
                callbackQueryId,
`<b>❌ SALDO TIDAK CUKUP</b>

Saldo Anda  : ${formatCurrency(userBalance)}
Harga Produk: ${formatCurrency(productPrice)}
Admin Fee   : ${formatCurrency(additionalFee)}
Total Bayar : ${formatCurrency(totalPrice)}
Kekurangan  : ${formatCurrency(totalPrice - userBalance)}

━━━━━━━━━━━━━━━━━━━

<b>📋 TINDAKAN</b>
Silakan deposit terlebih dahulu.`,
                {
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "💰 Deposit", callback_data: "deposit_main" }],
                            [{ text: "🔙 Kembali", callback_data: `pay_product_${productCode}_qris` }]
                        ]
                    }
                }
            );
        }

        const message = `<b>✅ KONFIRMASI PEMBAYARAN SALDO</b>

━━━━━━━━━━━━━━━━━━━

<b>Produk:</b> ${productFound.name}
<b>Harga:</b> ${formatCurrency(productPrice)}
<b>Admin Fee:</b> ${formatCurrency(additionalFee)}
<b>Total Bayar:</b> ${formatCurrency(totalPrice)}
<b>Kode:</b> <code>${productFound.buyCode}</code>

━━━━━━━━━━━━━━━━━━━

<b>💰 INFORMASI SALDO</b>
Saldo Sekarang : ${formatCurrency(userBalance)}
Setelah Bayar  : ${formatCurrency(userBalance - totalPrice)}

━━━━━━━━━━━━━━━━━━━

<b>⚠️ PERHATIAN</b>
• Pembelian tidak dapat dibatalkan
• File dikirim otomatis

<b>Apakah Anda yakin ingin melanjutkan?</b>`;

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "✅ Ya, Bayar Sekarang", callback_data: `confirm_saldo_${productFound.buyCode}` }],
                    [{ text: "❌ Batalkan", callback_data: `pay_product_${productFound.buyCode}_saldo` }]
                ]
            }
        });

        return;
    }

    if (paymentMethod === 'qris') {
        const reffId = `PROD_${productFound.buyCode}_${userId}_${Date.now()}`;

        userSelections.set(userId, {
            step: 'product_qris_payment',
            productCode: productFound.buyCode,
            productId,
            productName: productFound.name,
            productPrice: productFound.price,
            reffId
        });

        await editMessage(
            chatId,
            messageId,
            callbackQueryId,
            `<b>🔄 Membuat pembayaran QRIS...</b>`,
            { parse_mode: "HTML" }
        );

        try {
            const productPrice = Number(productFound.price);
            const additionalFee = Number(product_fee) || 0;
            const gatewayFee = 71; 
            const totalFee = additionalFee + gatewayFee;
            const totalToGateway = productPrice + totalFee;

            if (isNaN(totalToGateway)) {
                throw new Error('Total pembayaran tidak valid');
            }

            const depositResult = await khafaService.createDeposit(
                reffId,
                totalToGateway
            );

            if (!depositResult || !depositResult.success) {
                throw new Error(depositResult?.message || 'Gagal membuat pembayaran');
            }

            const depositData = depositResult.data;
            const khafaDepositId = depositData.id;

            productDB.orders[khafaDepositId] = {
                id: khafaDepositId,
                reff_id: reffId,
                user_id: userId,
                product_id: productId,
                product_name: productFound.name,
                product_price: productPrice,
                additional_fee: additionalFee,
                gateway_fee: gatewayFee,
                total_fee: totalFee,
                total_price: totalToGateway,
                khafa_nominal: depositData.nominal || totalToGateway,
                khafa_fee: gatewayFee,
                khafa_get_balance: depositData.get_balance || productPrice,
                payment_method: 'qris',
                status: 'pending',
                created_at: new Date().toISOString(),
                delivered: false,
                qris_data: {
                    qr_string: depositData.qr_string,
                    qr_image: depositData.qr_image
                }
            };

            saveDataProduct(productDB);

            const message = `<b>💰 PEMBAYARAN PRODUK VIA QRIS</b>

━━━━━━━━━━━━━━━━━━━

<b>Produk:</b> ${productFound.name}
<b>Harga:</b> ${formatCurrency(productPrice)}
<b>Fee Gateway:</b> ${formatCurrency(gatewayFee)}
<b>Admin Fee:</b> ${formatCurrency(additionalFee)}
<b>Total Bayar:</b> ${formatCurrency(totalToGateway)}
<b>ID Order:</b> <code>${khafaDepositId}</code>

━━━━━━━━━━━━━━━━━━━

<b>📋 CARA BAYAR</b>
1. Scan QR di bawah
2. Bayar sesuai nominal
3. File dikirim otomatis

<b>⏰ Batas waktu: 20 menit</b>`;

            const keyboard = {
                inline_keyboard: [
                    [{ text: "🔍 Cek Status", callback_data: `check_product_status_${khafaDepositId}` }],
                    [{ text: "❌ Batalkan", callback_data: `cancel_product_${khafaDepositId}` }],
                    [{ text: "🔙 Kembali", callback_data: "menu_products" }]
                ]
            };

            if (depositData.qr_string) {
                const qrBuffer = await QRCode.toBuffer(depositData.qr_string, {
                    errorCorrectionLevel: 'H',
                    margin: 1,
                    width: 300
                });

                await bot.sendPhoto(chatId, qrBuffer, {
                    caption: message,
                    parse_mode: 'HTML',
                    reply_markup: keyboard
                });

                await bot.deleteMessage(chatId, messageId);
            } else {
                await editMessage(chatId, messageId, callbackQueryId, message, {
                    parse_mode: 'HTML',
                    reply_markup: keyboard
                });
            }

            setTimeout(() => {
                checkProductPaymentStatus(chatId, khafaDepositId, productId, userId);
            }, 5000);

            autoBackupAll();

        } catch (error) {
            await editMessage(
                chatId,
                messageId,
                callbackQueryId,
`<b>❌ GAGAL MEMBUAT PEMBAYARAN</b>

Error: ${error.message}`,
                {
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "🔄 Coba Lagi", callback_data: `pay_product_${productCode}_qris` }],
                            [{ text: "🔙 Kembali", callback_data: "menu_products" }]
                        ]
                    }
                }
            );
        }

        return;
    }
}

async function sendProductFileToUser(chatId, userId, product, orderId) {
    try {
        const fileData = product.fileData;
        
        const successMessage = `<b>✅ PEMBAYARAN BERHASIL!</b>

━━━━━━━━━━━━━━━━━━━

<b>📦 Produk:</b> ${product.name}
<b>💰 Harga:</b> ${formatCurrency(product.price)}
<b>🏷️ Kode:</b> <code>${product.buyCode}</code>
<b>🆔 Order ID:</b> <code>${orderId}</code>

━━━━━━━━━━━━━━━━━━━

<b>🎉 Selamat menikmati produk Anda!</b>`;

        if (fileData.fileType === 'document') {
            await bot.sendDocument(chatId, fileData.fileId, {
                caption: successMessage,
                parse_mode: 'HTML'
            });
        } else if (fileData.fileType === 'photo') {
            await bot.sendPhoto(chatId, fileData.fileId, {
                caption: successMessage,
                parse_mode: 'HTML'
            });
        } else if (fileData.fileType === 'text') {
            await sendNewMessage(chatId,
                `${successMessage}\n\n<b>📝 Konten:</b>\n<code>${fileData.textContent}</code>`,
                { parse_mode: 'HTML' }
            );
        }

        await sendNewMessage(chatId,
            `<b>🙏 Terima kasih telah berbelanja!</b>

━━━━━━━━━━━━━━━━━━━

Gunakan tombol di bawah untuk belanja lagi.`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "🛒 Belanja Lagi", callback_data: "menu_products" },
                            { text: "🏠 Menu Utama", callback_data: "main_menu" }
                        ]
                    ]
                }
            }
        );

    } catch (fileError) {
        console.error('Error sending file:', fileError);
        await sendNewMessage(chatId,
            `<b>❌ GAGAL MENGIRIM FILE</b>

━━━━━━━━━━━━━━━━━━━

Silakan hubungi admin dengan Order ID:
<code>${orderId}</code>`,
            { parse_mode: 'HTML' }
        );
    }
}

async function checkProductPaymentStatus(chatId, khafaDepositId, productId, userId) {
    try {
        const statusResult = await khafaService.checkDepositStatus(khafaDepositId);
        
        if (!statusResult) {
            setTimeout(() => {
                checkProductPaymentStatus(chatId, khafaDepositId, productId, userId);
            }, 30000);
            return;
        }

        if (!statusResult.success) {
            const isServerError = statusResult.message?.includes('500') || statusResult.message?.includes('status code 500');
            
            if (isServerError) {
                setTimeout(() => {
                    checkProductPaymentStatus(chatId, khafaDepositId, productId, userId);
                }, 60000);
            } else {
                setTimeout(() => {
                    checkProductPaymentStatus(chatId, khafaDepositId, productId, userId);
                }, 30000);
            }
            return;
        }

        const productDB = loadDataProduct();
        
        let product = productDB.products[productId];
        
        if (!product) {
            const userSelection = userSelections.get(userId);
            if (userSelection && userSelection.productCode) {
                for (const [key, prod] of Object.entries(productDB.products)) {
                    if (prod.buyCode === userSelection.productCode) {
                        product = prod;
                        productId = key;
                        break;
                    }
                }
            }
        }

        if (!product) {
            await sendNewMessage(chatId,
                `<b>❌ PRODUK TIDAK DITEMUKAN</b>

━━━━━━━━━━━━━━━━━━━

Silakan hubungi admin dengan Order ID:
<code>${khafaDepositId}</code>`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        const statusData = statusResult.data;
        
        if (statusData.status === 'success' || statusData.status === 'paid') {
            product.stock -= 1;
            product.status = product.stock > 0 ? 'active' : 'out_of_stock';
            productDB.products[productId] = product;
    
            if (productDB.orders[khafaDepositId]) {
                productDB.orders[khafaDepositId].status = 'completed';
                productDB.orders[khafaDepositId].updated_at = new Date().toISOString();
                productDB.orders[khafaDepositId].delivered = true;
                productDB.orders[khafaDepositId].khafa_status = statusData.status;
            }
            
            saveDataProduct(productDB);
      
            userSelections.delete(userId);
           
            await sendProductFileToUser(chatId, userId, product, khafaDepositId);
            
        } else if (statusData.status === 'pending') {
            setTimeout(() => {
                checkProductPaymentStatus(chatId, khafaDepositId, productId, userId);
            }, 30000);
            
        } else if (statusData.status === 'expired' || statusData.status === 'failed' || statusData.status === 'cancel') {
            userSelections.delete(userId);
            
            if (productDB.orders[khafaDepositId]) {
                productDB.orders[khafaDepositId].status = statusData.status;
                productDB.orders[khafaDepositId].khafa_status = statusData.status;
                saveDataProduct(productDB);
            }
            
            const statusText = statusData.status === 'expired' ? 'KADALUARSA' : 
                             statusData.status === 'failed' ? 'GAGAL' : 
                             statusData.status === 'cancel' ? 'DIBATALKAN' : statusData.status;
            
            await sendNewMessage(chatId,
                `<b>❌ PEMBAYARAN ${statusText}</b>

━━━━━━━━━━━━━━━━━━━

Order ID: <code>${khafaDepositId}</code>

━━━━━━━━━━━━━━━━━━━

Silakan coba lagi.`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: "🔄 Coba Lagi", callback_data: "menu_products" }
                            ]
                        ]
                    }
                }
            );
        }
    } catch (error) {
        console.error('Error checking payment status:', error);
        
        setTimeout(() => {
            checkProductPaymentStatus(chatId, khafaDepositId, productId, userId);
        }, 60000);
    }
}

async function handleCancelProductPayment(chatId, khafaDepositId, userId, messageId, callbackQueryId) {
    try {
        try {
            await bot.deleteMessage(chatId, messageId);
        } catch (error) {}
        
        const processingMsg = await sendNewMessage(chatId,
            "<b>🔄 Membatalkan pembayaran...</b>",
            { parse_mode: "HTML" }
        );
        
        const cancelResult = await khafaService.cancelDeposit(khafaDepositId);
        
        try {
            await bot.deleteMessage(chatId, processingMsg.message_id);
        } catch (e) {}
        
        if (cancelResult && cancelResult.success) {
            userSelections.delete(userId);
            
            const productDB = loadDataProduct();
            if (productDB.orders[khafaDepositId]) {
                productDB.orders[khafaDepositId].status = 'cancelled';
                saveDataProduct(productDB);
            }

            await sendNewMessage(chatId,
                `<b>✅ PEMBAYARAN DIBATALKAN</b>

━━━━━━━━━━━━━━━━━━━

<b>🆔 Order ID:</b> <code>${khafaDepositId}</code>

━━━━━━━━━━━━━━━━━━━

Transaksi deposit telah dibatalkan.`,
                {
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: "🛒 Belanja Lagi", callback_data: "menu_products" },
                                { text: "🏠 Menu Utama", callback_data: "main_menu" }
                            ]
                        ]
                    }
                }
            );
        } else {
            const errorMessage = cancelResult?.message || 'Terjadi kesalahan internal saat membatalkan deposit.';
            const isServerError = errorMessage.includes('500') || errorMessage.includes('status code 500');
            
            if (isServerError) {
                await sendNewMessage(chatId,
                    `<b>⚠️ PERHATIAN</b>

━━━━━━━━━━━━━━━━━━━

Gagal terhubung ke server pembayaran.

<b>🆔 Order ID:</b> <code>${khafaDepositId}</code>

━━━━━━━━━━━━━━━━━━━

<b>📋 TINDAKAN</b>
1. Deposit akan otomatis expired dalam 20 menit
2. Silakan buat order baru nanti
3. Hubungi CS jika saldo terpotong

━━━━━━━━━━━━━━━━━━━

<b>⏰ STATUS</b>
Pembayaran akan kadaluarsa otomatis.`,
                    { 
                        parse_mode: "HTML",
                        reply_markup: {
                            inline_keyboard: [
                                [
                                    { text: "🛒 Belanja Lagi", callback_data: "menu_products" }
                                ],
                                [
                                    { text: "💬 CS", url: `https://t.me/${usernamelu.replace('@','')}` }
                                ]
                            ]
                        }
                    }
                );
            } else {
                await sendNewMessage(chatId,
                    `<b>❌ GAGAL MEMBATALKAN</b>

━━━━━━━━━━━━━━━━━━━

${errorMessage}`,
                    { 
                        parse_mode: "HTML",
                        reply_markup: {
                            inline_keyboard: [
                                [
                                    { text: "🔄 Coba Lagi", callback_data: `cancel_product_${khafaDepositId}` }
                                ]
                            ]
                        }
                    }
                );
            }
        }
    } catch (error) {
        await sendNewMessage(chatId,
            `<b>❌ ERROR SISTEM</b>

━━━━━━━━━━━━━━━━━━━

${error.message || 'Terjadi kesalahan sistem'}

━━━━━━━━━━━━━━━━━━━

<b>🆔 Order ID:</b> <code>${khafaDepositId}</code>

━━━━━━━━━━━━━━━━━━━

Silakan hubungi CS untuk bantuan.`,
            { 
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "💬 CS", url: `https://t.me/${usernamelu.replace('@','')}` }
                        ]
                    ]
                }
            }
        );
    }
}

async function showMainMenu(chatId, userId, user, messageId = null) {
  try {
    userSelections.delete(userId);
    balanceCache.delete(userId.toString());

    const userBalance = getUserBalance(userId);
    const pointsData = royaltySystem.getUserPoints(userId);   
    const botInfo = await bot.getMe();
    const referralStats = referralSystem.getReferralStats(userId);
    const referralLink = referralSystem.getReferralLink(userId, botInfo.username);   
    const data = loadData();
    const transactions = loadTransactions();
    const totalUsers = data.users?.length || 0;
    const allOrders = transactions.nokos_orders || [];
    const successfulOrders = allOrders.filter(o => {
    const status = o.status || o.data?.status;
    const otpReceived = o.data?.otp_received === true;
    const otpCode = o.data?.otp_code;
      
      return (
        status === 'success' || 
        status === 'completed' ||
        otpReceived ||
        (otpCode && otpCode !== '-' && otpCode !== '') ||
        (o.data?.otp_received === true)
      );
    });

    const allDeposits = [
      ...(transactions.rumahotp_deposits || []),
      ...(transactions.khafa_deposits || [])
    ];
    
    const successfulDeposits = allDeposits.filter(deposit => {
      const status = deposit.status || deposit.data?.status;
      return (
        status === 'success' || 
        status === 'paid' ||
        deposit.data?.status === 'success' ||
        deposit.data?.status === 'paid'
      );
    });
    
    const totalDeposits = successfulDeposits.length;
    const totalOrders = successfulOrders.length;
    const username = user.username ? `@${user.username}` : 'tidak ada';
    const firstName = user.first_name || 'User';
    const botUsername = botInfo.username; 
    const botFirstName = botInfo.first_name; 
    const statsCacheKey = 'global_stats';
    const statsCache = {
      orders: totalOrders,
      deposits: totalDeposits,
      users: totalUsers,
      timestamp: Date.now()
    };
    
    const CACHE_TTL = 5 * 60 * 1000;     
    const message = `
Halo <a href="tg://user?id=${user.id}">${firstName}</a> 👋
<a href="https://t.me/${botUsername}">${botFirstName}</a> siap membantumu order nokos dan berbagai produk digital lainnya!

🛍️ <b>KyzzOfficial || Auto Order Nokos</b>

👤<b>PROFIL ANDA</b>
Nama: ${firstName}
ID: <code>${userId}</code>
Username: ${username}
Saldo: ${formatCurrency(userBalance)}
Points: ${pointsData.points}
Referral: ${referralStats.totalReferrals} users (${formatCurrency(referralStats.totalEarned)})

📊 <b>STATISTIK BOT</b>
Total User: ${totalUsers}
Order Sukses: ${totalDeposits}x

🎁 <b>BONUS REFERRAL</b>
Referrer: ${formatCurrency(referralSystem.REFERRER_BONUS)} / user (Anda)
Referred: ${formatCurrency(referralSystem.WELCOME_BONUS)} bonus (Teman)

Please select the button below:`;

    const keyboard = [
    [
        { text: "🛒 Beli Nokos", callback_data: "nokos_menu" },
        { text: "💰 Topup", callback_data: "deposit_main" }
    ],
    [
        { text: "🛍️ Beli Script", callback_data: "menu_products" },
        { text: "👥 Points & Referral", callback_data: "points_menu" }
    ],
    [
        { text: "📋 Riwayat Order", callback_data: "order_history" },
        { text: "📊 Riwayat Deposit", callback_data: "deposit_history" }
    ],
    [
        { text: "💬 CS", url: `https://t.me/${usernamelu.replace('@','')}` }
    ]
   ];

    if (owner_ids.includes(userId.toString())) {
      keyboard.push([
        { text: '💎 Owner Menu', callback_data: 'owner_menu' }
      ]);
    }

    const options = {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML',
      disable_web_page_preview: true
    };

    if (messageId) {
      await editMessage(chatId, messageId, null, message, options);
    } else {
      await sendNewMessage(chatId, message, options);
    }
    
  } catch (error) {
    console.error('Error in showMainMenu:', error);
  }
}

async function showPointsMenu(chatId, userId, messageId) {
  try {
    const userBalance = getUserBalance(userId);
    const pointsData = royaltySystem.getUserPoints(userId);
    const referralStats = referralSystem.getReferralStats(userId);
    const botInfo = await bot.getMe();
    const referralLink = referralSystem.getReferralLink(userId, botInfo.username);
    const message = `<b>👥 POINTS & REFERRAL</b>

💰 <b>SALDO & POINTS</b>
Saldo: ${formatCurrency(userBalance)}
Points: ${pointsData.points}
Tukar: ${formatCurrency(pointsData.redeemableCash)}

👥 <b>REFERRAL SYSTEM</b>
Total referral: ${referralStats.totalReferrals} users
Total earned: ${formatCurrency(referralStats.totalEarned)}

🎁 <b>BONUS REFERRAL</b>
• Anda (Referrer): ${formatCurrency(referralSystem.REFERRER_BONUS)} per user
• Teman (Referred): ${formatCurrency(referralSystem.WELCOME_BONUS)} bonus

<b>📱 CARA MENGGUNAKAN</b>
1. Bagikan link diatas ke teman
2. Teman klik link dan start bot
3. Anda dapat ${formatCurrency(referralSystem.REFERRER_BONUS)}, teman dapat ${formatCurrency(referralSystem.WELCOME_BONUS)}`;

    const keyboard = [
      [
        { text: '💰 Tukar Points', callback_data: 'redeem_points' }
      ],
      [
        { text: '📱 Bagikan Link', url: `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent('Join bot ini untuk dapat saldo gratis!')}` }
      ],
      [
        { text: '🔙 Kembali', callback_data: 'main_menu' }
      ]
    ];

    const options = {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML',
      disable_web_page_preview: true
    };

    if (messageId) {
      await editMessage(chatId, messageId, null, message, options);
    } else {
      await sendNewMessage(chatId, message, options);
    }
    
  } catch (error) {
    console.error('Error in showPointsMenu:', error);
  }
}

async function showOwnerMenu(chatId, userId, messageId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      return;
    }

    const message = `
<b>💎 OWNER MENU</b>

👤 <b>USER INFO</b>
ID: <code>${userId}</code>
Role: <b>Owner</b>

📋 <b>COMMAND LIST</b>
/broadcast - Kirim pesan ke semua user
/stats - Lihat statistik bot
/setpay - Atur metode pembayaran
/maintenance - Maintenance mode
/addsaldo - Tambah saldo user
/delsaldo - Hapus saldo user
/listsaldo - Menampilkan saldo user
/backup - Backup database
/addproduct - Menambahkan produk
/withdraw - Tarik saldo rumah otp

⚠️ <b>PETUNJUK</b>
Ketik command di chat untuk menjalankan`;

    const keyboard = [
      [{ text: '🔙 Kembali', callback_data: 'main_menu' }]
    ];

    const options = {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML'
    };

    if (messageId) {
      await editMessage(chatId, messageId, null, message, options);
    } else {
      await sendNewMessage(chatId, message, options);
    }
    
  } catch (error) {
    console.error('Error in showOwnerMenu:', error);
  }
}

async function redeemUserPoints(chatId, userId, messageId, callbackQueryId) {
    try {
        const pointsData = royaltySystem.getUserPoints(userId);
        
        if (pointsData.points < pointsData.neededPoints) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ POINTS TIDAK CUKUP</b>

Points: ${pointsData.points}
Minimal: ${pointsData.neededPoints} points`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '💰 Deposit', callback_data: 'deposit_main' },
                                { text: '🔙 Kembali', callback_data: 'points_menu' }
                            ]
                        ]
                    }
                }
            );
            return;
        }

        const redeemResult = royaltySystem.redeemPoints(userId);
        
        if (redeemResult.success) {
            const cashValue = Number(redeemResult.cashValue) || 0;
            if (cashValue > 0) {
                const success = addUserBalance(userId, cashValue);
                
                if (!success) {
                    await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MENAMBAH SALDO</b>`,
                        {
                            parse_mode: 'HTML',
                            reply_markup: {
                                inline_keyboard: [
                                    [
                                        { text: '🔙 Kembali', callback_data: 'points_menu' }
                                    ]
                                ]
                            }
                        }
                    );
                    return;
                }
            }
            
            await editMessage(chatId, messageId, callbackQueryId,
`<b>✅ PENUKARAN BERHASIL</b>

Points: ${redeemResult.pointsRedeemed}
Nilai: ${formatCurrency(redeemResult.cashValue)}
Saldo +: ${formatCurrency(redeemResult.cashValue)}

<b>💰 SALDO SEKARANG</b>
${formatCurrency(getUserBalance(userId))}`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '🔄 Tukar Lagi', callback_data: 'redeem_points' },
                                { text: '🔙 Menu', callback_data: 'points_menu' }
                            ]
                        ]
                    }
                }
            );
        } else {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MENUKAR</b>

${redeemResult.error}`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '🔙 Kembali', callback_data: 'points_menu' }
                            ]
                        ]
                    }
                }
            );
        }
    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ TERJADI KESALAHAN</b>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🔙 Kembali', callback_data: 'points_menu' }
                        ]
                    ]
                }
            }
        );
    }
}

async function showServerList(chatId, userId, numberId, countryName, messageId, callbackQueryId) {
    try {
        let userSelection = userSelections.get(userId);
        
        if (!userSelection || !userSelection.serviceId) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ SESI TIDAK LENGKAP</b>

Status: Data Tidak Lengkap
Error: Data layanan tidak ditemukan

<b>⚠️ TINDAKAN</b>
Silakan pilih layanan dari awal.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '🔙 Mulai Dari Awal', 
                                callback_data: 'nokos_menu' 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }
        
        await editMessage(chatId, messageId, callbackQueryId,
            '<b>⏳ MEMUAT DATA SERVER...</b>',
            { parse_mode: 'HTML' }
        );
        
        const countriesData = await api.getCountries(userSelection.serviceId);
        if (!countriesData || !countriesData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MEMUAT DATA</b>

Status: Gagal Terhubung
Error: Tidak dapat mengambil data server

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '🔄 Coba Lagi', 
                                callback_data: `nokos_service_${userSelection.serviceId}` 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }
        
        const countries = countriesData.data || [];
        const selectedCountry = countries.find(c => c.number_id == numberId);
        
        if (!selectedCountry || !selectedCountry.pricelist || selectedCountry.pricelist.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ SERVER TIDAK TERSEDIA</b>

Negara: ${countryName}
Status: Tidak Ada Server

<b>⚠️ INFORMASI</b>
Tidak ada server tersedia untuk negara ini.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '📍 Pilih Negara Lain', 
                                callback_data: `nokos_service_${userSelection.serviceId}` 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }
        
        let servers = selectedCountry.pricelist;
        servers.sort((a, b) => a.price - b.price);

        userSelection.step = 'nokos_server';
        userSelection.numberId = numberId;
        userSelection.countryName = countryName;
        userSelection.countryData = selectedCountry;
        userSelections.set(userId, userSelection);
        
        const countryCode = getCountryCode(selectedCountry.iso_code);
        const countryEmoji = countryCode || '🌍';
        
        const message = `<b>${countryEmoji} PILIH SERVER - ${countryName.toUpperCase()}</b>

Layanan: ${userSelection.serviceName}
Negara: ${countryEmoji} ${countryName}
Stok: ${selectedCountry.stock_total} nomor
Server: ${servers.length} tersedia

<b>📋 DAFTAR SERVER TERSEDIA</b>
Pilih server untuk melanjutkan:`;

        const keyboard = [];
        const buttonsPerRow = 3;
        const maxButtons = 15;
        const serversToShow = servers.slice(0, maxButtons);
        
        for (let i = 0; i < serversToShow.length; i += buttonsPerRow) {
            const row = [];
            for (let j = 0; j < buttonsPerRow; j++) {
                if (serversToShow[i + j]) {
                    const server = serversToShow[i + j];
                    const serverNumber = i + j + 1;
                    const buttonText = `🖥️ S${serverNumber}`;
                    const callbackData = `nokos_server_${server.provider_id}_${server.price}_${server.rate}_${server.stock}`;
                    
                    row.push({ 
                        text: buttonText, 
                        callback_data: callbackData
                    });
                }
            }
            if (row.length > 0) {
                keyboard.push(row);
            }
        }
        
        keyboard.push([
            { 
                text: '🔙 Kembali', 
                callback_data: `nokos_service_${userSelection.serviceId}` 
            },
            { 
                text: '🏠 Menu', 
                callback_data: 'main_menu' 
            }
        ]);
        
        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML',
            disable_web_page_preview: true
        });
        
    } catch (error) {
        console.error('Error in showServerList:', error);
        await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ TERJADI KESALAHAN</b>

Status: Error Sistem
Error: Terjadi kesalahan teknis

<b>⚠️ TINDAKAN</b>
Silakan coba lagi atau hubungi CS.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ 
                            text: '🔄 Coba Lagi', 
                            callback_data: `nokos_service_${userSelections.get(userId)?.serviceId || 'nokos_menu'}` 
                        }],
                        [{ 
                            text: '💬 CS', 
                            url: `https://t.me/${usernamelu.replace('@','')}` 
                        }]
                    ]
                },
                disable_web_page_preview: true
            }
        );
    }
}

async function showServerListEnhanced(chatId, userId, numberId, countryName, messageId, callbackQueryId, startIndex = 0) {
    try {
        let userSelection = userSelections.get(userId);
        
        if (!userSelection || !userSelection.serviceId) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ SESI TIDAK LENGKAP</b>

Status: Data Tidak Lengkap

<b>⚠️ TINDAKAN</b>
Silakan pilih layanan dari awal.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '🔙 Mulai Dari Awal', 
                                callback_data: 'nokos_menu' 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }
        
        await editMessage(chatId, messageId, callbackQueryId,
            '<b>⏳ MEMUAT DATA SERVER...</b>',
            { parse_mode: 'HTML' }
        );
        
        const countriesData = await api.getCountries(userSelection.serviceId);
        if (!countriesData || !countriesData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MEMUAT DATA</b>

Status: Gagal Terhubung

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '🔄 Coba Lagi', 
                                callback_data: `nokos_service_${userSelection.serviceId}` 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }
        
        const countries = countriesData.data || [];
        const selectedCountry = countries.find(c => c.number_id == numberId);
        
        if (!selectedCountry || !selectedCountry.pricelist || selectedCountry.pricelist.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ SERVER TIDAK TERSEDIA</b>

Negara: ${countryName}
Status: Tidak Ada Server

<b>⚠️ INFORMASI</b>
Tidak ada server tersedia untuk negara ini.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '📍 Pilih Negara Lain', 
                                callback_data: `nokos_service_${userSelection.serviceId}` 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }
        
        let servers = selectedCountry.pricelist;
        servers.sort((a, b) => a.price - b.price);

        userSelection.step = 'nokos_server';
        userSelection.numberId = numberId;
        userSelection.countryName = countryName;
        userSelection.countryData = selectedCountry;
        userSelections.set(userId, userSelection);
        
        const flagEmoji = getFlagEmoji(selectedCountry.iso_code) || '🌍';
        const serversPerPage = 9;
        const currentPage = Math.floor(startIndex / serversPerPage) + 1;
        const totalPages = Math.ceil(servers.length / serversPerPage);
        const displayStart = (currentPage - 1) * serversPerPage;
        const displayEnd = displayStart + serversPerPage;
        const displayServers = servers.slice(displayStart, displayEnd);
        
        const message = `<b>${flagEmoji} DAFTAR SERVER - ${countryName.toUpperCase()}</b>

Layanan: ${userSelection.serviceName}
Negara: ${flagEmoji} ${countryName}
Stok: ${selectedCountry.stock_total} nomor
Total Server: ${servers.length} server
Halaman: ${currentPage}/${totalPages}

<b>📋 PILIHAN SERVER</b>
Klik tombol untuk memilih server:`;

        const rowsPerGrid = 3;
        for (let row = 0; row < rowsPerGrid; row++) {
            const rowStart = row * rowsPerGrid;
            const rowServers = displayServers.slice(rowStart, rowStart + rowsPerGrid);
            
            if (rowServers.length === 0) break;

            message += `<b>`;
            rowServers.forEach((server, colIndex) => {
                const serverNumber = displayStart + rowStart + colIndex + 1;
                message += `S${serverNumber}  `;
            });
            message += `</b>\n`;
            
            rowServers.forEach((server, colIndex) => {
                message += `💰 ${formatCurrency(server.price)}  `;
            });
            message += `\n`;

            rowServers.forEach((server, colIndex) => {
                const rateEmoji = server.rate >= 90 ? '✅' : server.rate >= 70 ? '⚠️' : '❌';
                message += `${rateEmoji} ${server.rate}%  `;
            });
            message += `\n\n`;
        }
        
        const keyboard = [];
        
        for (let row = 0; row < rowsPerGrid; row++) {
            const rowStart = row * rowsPerGrid;
            const rowServers = displayServers.slice(rowStart, rowStart + rowsPerGrid);
            
            if (rowServers.length === 0) break;
            
            const buttonRow = [];
            rowServers.forEach((server, colIndex) => {
                const serverNumber = displayStart + rowStart + colIndex + 1;
                const buttonText = `🖥️ S${serverNumber}`;
                const callbackData = `nokos_server_${server.provider_id}_${server.price}_${server.rate}_${server.stock}`;
                
                buttonRow.push({ 
                    text: buttonText, 
                    callback_data: callbackData 
                });
            });
            
            if (buttonRow.length > 0) {
                keyboard.push(buttonRow);
            }
        }
        
        const navButtons = [];
        
        if (currentPage > 1) {
            navButtons.push({ 
                text: '◀️ Sebelumnya', 
                callback_data: `server_prev_${numberId}_${encodeURIComponent(countryName)}_${displayStart - serversPerPage}` 
            });
        } else {
            navButtons.push({ 
                text: '◀️ Sebelumnya', 
                callback_data: 'no_action' 
            });
        }
        
        navButtons.push({ 
            text: `📄 ${currentPage}/${totalPages}`, 
            callback_data: 'no_action' 
        });
        
        if (currentPage < totalPages) {
            navButtons.push({ 
                text: 'Selanjutnya ▶️', 
                callback_data: `server_next_${numberId}_${encodeURIComponent(countryName)}_${displayStart + serversPerPage}` 
            });
        } else {
            navButtons.push({ 
                text: 'Selanjutnya ▶️', 
                callback_data: 'no_action' 
            });
        }
        
        keyboard.push(navButtons);
        
        keyboard.push([
            { 
                text: '🔙 Kembali', 
                callback_data: `nokos_service_${userSelection.serviceId}` 
            },
            { 
                text: '🏠 Menu', 
                callback_data: 'main_menu' 
            }
        ]);
        
        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML',
            disable_web_page_preview: true
        });
        
    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ TERJADI KESALAHAN</b>

Status: Error Sistem

<b>⚠️ TINDAKAN</b>
Silakan coba lagi atau hubungi CS.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ 
                            text: '🔄 Coba Lagi', 
                            callback_data: `nokos_service_${userSelections.get(userId)?.serviceId || 'nokos_menu'}` 
                        }]
                    ]
                },
                disable_web_page_preview: true
            }
        );
    }
}

function getCountryCode(isoCode) {
    const countryCodes = {
        'id': '+62',
        'ph': '+63',
        'us': '+1',
        'gb': '+44',
        'sg': '+65',
        'my': '+60',
        'th': '+66',
        'vn': '+84'
    };
    
    return countryCodes[isoCode?.toLowerCase()] || `+${isoCode?.toUpperCase() || '62'}`;
}

function getFlagEmoji(countryCode) {
    if (!countryCode || typeof countryCode !== 'string') return '🌐';
    const codePoints = countryCode
        .toUpperCase()
        .split('')
        .map(char => 127397 + char.charCodeAt());
    return String.fromCodePoint(...codePoints);
}

async function showOperatorMenu(chatId, userId, numberId, price, countryName, messageId, callbackQueryId) {
    try {
        const userSelection = userSelections.get(userId);
        if (!userSelection) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ SESI TIDAK DITEMUKAN</b>

Status: Sesi Kadaluarsa

<b>⚠️ TINDAKAN</b>
Silakan mulai kembali dari menu utama.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '🏠 Menu', 
                                callback_data: 'main_menu' 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }
        
        userSelection.step = 'nokos_operator';
        userSelection.numberId = numberId;
        userSelection.price = price;
        userSelection.countryName = countryName;
        userSelections.set(userId, userSelection);

        await editMessage(chatId, messageId, callbackQueryId,
            '<b>⏳ MENCARI OPERATOR...</b>',
            { parse_mode: 'HTML' }
        );

        const countriesData = await api.getCountries(userSelection.serviceId);
        
        if (!countriesData || !countriesData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MENDAPATKAN DATA</b>

Status: Gagal Terhubung

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '🔄 Coba Lagi', 
                                callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }

        const countries = countriesData.data || [];
        const selectedCountry = countries.find(c => c.number_id == numberId);
        
        if (!selectedCountry) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ DATA NEGARA TIDAK DITEMUKAN</b>

Negara: ${countryName}
Status: Tidak Ditemukan

<b>⚠️ INFORMASI</b>
Data negara tidak ditemukan di sistem.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '🔙 Kembali', 
                                callback_data: `nokos_service_${userSelection.serviceId}` 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }

        if (!selectedCountry.pricelist || selectedCountry.pricelist.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ OPERATOR TIDAK TERSEDIA</b>

Negara: ${countryName}
Status: Tidak Ada Operator

<b>⚠️ INFORMASI</b>
Tidak ada operator tersedia untuk negara ini.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '📍 Pilih Negara Lain', 
                                callback_data: `nokos_service_${userSelection.serviceId}` 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }

        const providerId = userSelection.providerId || selectedCountry.pricelist[0].provider_id;
        userSelection.providerId = providerId;
        userSelections.set(userId, userSelection);

        const operatorsData = await api.getOperators(selectedCountry.name, providerId);
        
        if (!operatorsData || !operatorsData.success) {
            const errorMsg = operatorsData?.message || 'Gagal terhubung ke server operator';
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MENDAPATKAN OPERATOR</b>

Status: Gagal Terhubung
Error: ${errorMsg}

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '🔙 Kembali', 
                                callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }

        const operators = operatorsData.data || [];
        
        if (operators.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ BELUM ADA OPERATOR</b>

Negara: ${countryName}
Status: Tidak Ada Operator

<b>⚠️ INFORMASI</b>
Belum ada operator yang tersedia untuk negara ini.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '📍 Pilih Negara Lain', 
                                callback_data: `nokos_service_${userSelection.serviceId}` 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }

        const flagEmoji = getFlagEmoji(selectedCountry.iso_code) || '🌍';
        const formattedPrice = formatCurrency(price);
        
        const message = `<b>📡 PILIH OPERATOR - ${countryName.toUpperCase()}</b>

Layanan: ${userSelection.serviceName}
Negara: ${flagEmoji} ${countryName}
Harga: ${formattedPrice}
Operator: ${operators.length} tersedia

<b>📋 DAFTAR OPERATOR</b>
Pilih operator untuk melanjutkan:`;

        const keyboard = [];

        for (let i = 0; i < operators.length; i += 2) {
            const row = [];
            
            if (operators[i]) {
                const op = operators[i];
                const buttonText = op.name ? `${op.name.substring(0, 12)}` : `Operator ${i+1}`;
                row.push({ 
                    text: `📱 ${buttonText}`, 
                    callback_data: `nokos_operator_${op.id}_${providerId}_${price}` 
                });
            }
            
            if (operators[i + 1]) {
                const op = operators[i + 1];
                const buttonText = op.name ? `${op.name.substring(0, 12)}` : `Operator ${i+2}`;
                row.push({ 
                    text: `📱 ${buttonText}`, 
                    callback_data: `nokos_operator_${op.id}_${providerId}_${price}` 
                });
            }
            
            if (row.length > 0) {
                keyboard.push(row);
            }
        }

        keyboard.push([
            { 
                text: '🔙 Kembali', 
                callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` 
            },
            { 
                text: '🏠 Menu', 
                callback_data: 'main_menu' 
            }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML',
            disable_web_page_preview: true
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ TERJADI KESALAHAN</b>

Status: Error Sistem

<b>⚠️ TINDAKAN</b>
Silakan coba lagi atau hubungi CS.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ 
                            text: '🔄 Coba Lagi', 
                            callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` 
                        }]
                    ]
                },
                disable_web_page_preview: true
            }
        );
    }
}

async function showNokosMenu(chatId, userId, messageId, callbackQueryId) {
  try {
    const servicesData = await getServicesCached();
    
    if (!servicesData || !servicesData.success) {
      await editMessage(chatId, messageId, callbackQueryId, 
`<b>❌ GAGAL MENDAPATKAN LAYANAN</b>

Status: Gagal Terhubung

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
        { 
          parse_mode: 'HTML',
          disable_web_page_preview: true 
        }
      );
      return;
    }

    const services = servicesData.data;
    const popularServiceNames = new Set(['whatsapp', 'telegram', 'instagram', 'facebook', 'gojek', 'ovo', 'dana']);
    const popularServices = [];
    const otherServices = [];
    
    for (const service of services) {
      if (popularServiceNames.has(service.service_name.toLowerCase())) {
        popularServices.push(service);
      } else {
        otherServices.push(service);
      }
    }

    const message = `<b>📱 MENU LAYANAN NOKOS</b>

Total Layanan: ${services.length}
Layanan Populer: ${popularServices.length}

<b>📋 LAYANAN POPULER</b>
Pilih layanan untuk order nomor OTP:`;

    const keyboard = [];
    
    for (let i = 0; i < Math.min(popularServices.length, 6); i += 2) {
      const row = [];
      
      if (popularServices[i]) {
        const serviceName = popularServices[i].service_name;
        const buttonText = serviceName.substring(0, 12);
        row.push({ 
          text: `📱 ${buttonText}`, 
          callback_data: `nokos_service_${popularServices[i].service_code}` 
        });
      }
      
      if (popularServices[i + 1]) {
        const serviceName = popularServices[i + 1].service_name;
        const buttonText = serviceName.substring(0, 12);
        row.push({ 
          text: `📱 ${buttonText}`, 
          callback_data: `nokos_service_${popularServices[i + 1].service_code}` 
        });
      }
      
      if (row.length > 0) {
        keyboard.push(row);
      }
    }

    if (otherServices.length > 0) {
      keyboard.push([
        { 
          text: '📋 Semua Layanan', 
          callback_data: 'nokos_other_services' 
        }
      ]);
    }

    keyboard.push([
      { 
        text: '🏠 Menu', 
        callback_data: 'main_menu' 
      },
      { 
        text: '🔄 Refresh', 
        callback_data: 'nokos_menu' 
      }
    ]);

    await editMessage(chatId, messageId, callbackQueryId, message, {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });

  } catch (error) {
    await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MEMUAT MENU</b>

Status: Error Sistem

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ 
              text: '🔄 Coba Lagi', 
              callback_data: 'nokos_menu' 
            }]
          ]
        },
        disable_web_page_preview: true
      }
    );
  }
}

async function cancelOrder(chatId, userId, orderId, messageId, callbackQueryId) {
  try {
    await editMessage(chatId, messageId, callbackQueryId,
      '<b>⏳ MEMBATALKAN ORDER...</b>',
      { parse_mode: 'HTML' }
    );

    const transactions = loadTransactions();
    const order = transactions.nokos_orders?.find(o => o.id === orderId || o.data?.orderId === orderId);
    
    if (!order) {
      await editMessage(chatId, messageId, callbackQueryId,
        '<b>❌ ORDER TIDAK DITEMUKAN</b>',
        { parse_mode: 'HTML' }
      );
      return;
    }

    const orderTime = new Date(order.timestamp).getTime();
    const currentTime = Date.now();
    const threeMinutes = 3 * 60 * 1000; 
    
    if (currentTime - orderTime < threeMinutes) {
      const remainingSeconds = Math.ceil((threeMinutes - (currentTime - orderTime)) / 1000);
      const remainingMinutes = Math.floor(remainingSeconds / 60);
      const remainingSecs = remainingSeconds % 60;
      
      await editMessage(chatId, messageId, callbackQueryId,
`<b>⏳ TUNGGU ${remainingMinutes}:${remainingSecs.toString().padStart(2, '0')}</b>

<blockquote>ID Order: <code>${orderId}</code>
Waktu Dibuat: ${new Date(orderTime).toLocaleTimeString('id-ID')}
Status: ⏳ <b>Masih dalam proses</b></blockquote>

<b>⚠️ INFORMASI</b>
├─ Sistem menunggu OTP
├─ Tunggu minimal 3 menit
├─ Akan otomatis dicek sistem
└─ Jika OTP tidak masuk, refund otomatis

<b>🔄 CEK OTOMATIS</b>
└─ Sistem cek setiap 10 detik`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { 
                  text: `🔄 Cek OTP (${remainingMinutes}m)`, 
                  callback_data: `nokos_check_${orderId}` 
                }
              ],
              [
                { 
                  text: '🏠 Menu', 
                  callback_data: 'main_menu' 
                }
              ]
            ]
          },
          disable_web_page_preview: true
        }
      );
      return;
    }

    const statusResult = await api.getOrderStatus(orderId);
    
    let otpReceived = false;
    if (statusResult && statusResult.success && statusResult.data) {
      const orderData = statusResult.data;
      otpReceived = orderData.otp_code && orderData.otp_code !== '-' && orderData.otp_code !== '';
    }

    const dbOtpReceived = order?.data?.otp_received === true;
    
    if (otpReceived || dbOtpReceived) {
        updateTransactionStatus('nokos_orders', orderId, 'completed');

        if (statusResult && statusResult.success && statusResult.data && statusResult.data.otp_code) {
            const orderIndex = transactions.nokos_orders.findIndex(o => o.id === orderId || o.data?.orderId === orderId);
            if (orderIndex !== -1) {
                transactions.nokos_orders[orderIndex].data.otp_code = statusResult.data.otp_code;
                transactions.nokos_orders[orderIndex].data.otp_received = true;
                saveTransactions(transactions);
            }
        }
        
        await editMessage(chatId, messageId, callbackQueryId,
`<b>✅ OTP DITERIMA - ORDER SELESAI</b>

<blockquote>ID Order: <code>${orderId}</code>
Nomor: <b>${order.data?.phoneNumber || '-'}</b>
Kode OTP: <code>${statusResult?.data?.otp_code || order.data?.otp_code || '-'}</code>
Status: ✅ <b>OTP Sudah Diterima</b></blockquote>

<b>⚠️ INFORMASI</b>
├─ Saldo: ❌ <b>Tidak Dapat Dikembalikan</b>
└─ Order sudah selesai`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { 
                                text: '🛒 Order Baru', 
                                callback_data: 'nokos_menu' 
                            },
                            { 
                                text: '🏠 Menu', 
                                callback_data: 'main_menu' 
                            }
                        ]
                    ]
                },
                disable_web_page_preview: true
            }
        );
        return;
    }
    
    const orderStatus = statusResult?.data?.status || 'active';
    
    if (orderStatus === 'completed') {
        updateTransactionStatus('nokos_orders', orderId, 'completed');
        
        await editMessage(chatId, messageId, callbackQueryId,
`<b>✅ ORDER SUDAH SELESAI</b>

<blockquote>ID Order: <code>${orderId}</code>
Status: ✅ <b>Selesai di sistem</b></blockquote>

<b>⚠️ INFORMASI</b>
└─ Order sudah selesai di sistem provider.`,
        { 
          parse_mode: 'HTML',
          disable_web_page_preview: true 
        }
      );
      return;
    }

    const alreadyRefunded = order?.data?.refunded === true;
    
    if (alreadyRefunded) {
      await editMessage(chatId, messageId, callbackQueryId,
`<b>💰 REFUND SUDAH DIBERIKAN</b>

<blockquote>ID Order: <code>${orderId}</code>
Status: ✅ <b>Sudah Direfund</b>
Jumlah: <b>${formatCurrency(order.data?.total || order.data?.price || 0)}</b></blockquote>`,
        { 
            parse_mode: 'HTML',
            disable_web_page_preview: true 
        }
      );
      return;
    }

    const cancelResult = await api.setOrderStatus(orderId, 'cancel');

    updateTransactionStatus('nokos_orders', orderId, 'cancelled');

    let refundMessage = '';
    
    const orderPrice = order.data?.price || 0;
    const orderFee = order.data?.fee || 0;
    const orderTotal = order.data?.total || (Number(orderPrice) + Number(orderFee));
    const refundAmount = Number(orderTotal);
    
    if (!isNaN(refundAmount) && refundAmount > 0 && !otpReceived && !dbOtpReceived) {
      if (!order.data?.refunded) {
        const success = addUserBalance(userId, refundAmount);
        
        if (success) {
        
          if (transactions.nokos_orders) {
            const orderIndex = transactions.nokos_orders.findIndex(o => o.id === orderId || o.data?.orderId === orderId);
            if (orderIndex !== -1) {
              transactions.nokos_orders[orderIndex].data.refunded = true;
              saveTransactions(transactions);
            }
          }
          
          const newBalance = getUserBalance(userId);
          refundMessage = `
<b>💰 REFUND BERHASIL</b>
├─ Harga: ${formatCurrency(orderPrice)}
├─ Fee: ${formatCurrency(orderFee)}
├─ Total dikembalikan: <b>${formatCurrency(refundAmount)}</b>
└─ Saldo Sekarang: <b>${formatCurrency(newBalance)}</b>`;
        }
      }
    }

    await editMessage(chatId, messageId, callbackQueryId,
`<b>✅ ORDER DIBATALKAN</b>

<blockquote>ID Order: <code>${orderId}</code>
Nomor: <b>${order.data?.phoneNumber || '-'}</b>
Status: ❌ <b>Dibatalkan</b></blockquote>
${refundMessage}

<b>⚠️ ALASAN PEMBATALAN</b>
└─ OTP tidak diterima dalam waktu yang ditentukan`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { 
                text: '🛒 Order Baru', 
                callback_data: 'nokos_menu' 
              },
              { 
                text: '🏠 Menu', 
                callback_data: 'main_menu' 
              }
            ]
          ]
        },
        disable_web_page_preview: true
      }
    );
  } catch (error) {
    await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MEMBATALKAN ORDER</b>

<blockquote>Status: ❌ <b>Error Sistem</b>
Error: ${error.message || 'Tidak dapat terhubung ke server'}</blockquote>

<b>⚠️ TINDAKAN DIBUTUHKAN</b>
└─ Silakan coba lagi dalam 1 menit.`,
      { 
        parse_mode: 'HTML',
        disable_web_page_preview: true 
      }
    );
  }
}

async function autoCancelOrder(chatId, userId, orderId, totalPrice) {
  try {
    const statusResult = await api.getOrderStatus(orderId);
    
    let otpReceived = false;
    if (statusResult && statusResult.success && statusResult.data) {
      const orderData = statusResult.data;
      otpReceived = orderData.otp_code && orderData.otp_code !== '-' && orderData.otp_code !== '';
    }
    
    const transactions = loadTransactions();
    const order = transactions.nokos_orders?.find(o => 
        o.id === orderId || o.data?.orderId === orderId
    );
    const dbOtpReceived = order?.data?.otp_received === true;
    
    if (otpReceived || dbOtpReceived) {
        updateTransactionStatus('nokos_orders', orderId, 'completed');
  
        if (statusResult && statusResult.success && statusResult.data && statusResult.data.otp_code) {
            const orderIndex = transactions.nokos_orders.findIndex(o => o.id === orderId || o.data?.orderId === orderId);
            if (orderIndex !== -1) {
                transactions.nokos_orders[orderIndex].data.otp_code = statusResult.data.otp_code;
                transactions.nokos_orders[orderIndex].data.otp_received = true;
                saveTransactions(transactions);
            }
        }
        
        await sendNewMessage(chatId,
`<b>✅ ORDER SELESAI</b>

<blockquote>ID Order: <code>${orderId}</code>
Status: ✅ <b>OTP Telah Diterima</b></blockquote>

<b>⚠️ INFORMASI</b>
├─ Saldo: <b>Sudah terpakai</b>
└─ Order selesai dengan sukses`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    const cancelResult = await api.setOrderStatus(orderId, 'cancel');
    
    if (cancelResult && cancelResult.success) {
      updateTransactionStatus('nokos_orders', orderId, 'expired');
      
      if (!order?.data?.refunded) {
        addUserBalance(userId, totalPrice);
        
        if (transactions.nokos_orders) {
            const orderIndex = transactions.nokos_orders.findIndex(o => o.id === orderId || o.data?.orderId === orderId);
            if (orderIndex !== -1) {
                transactions.nokos_orders[orderIndex].data.refunded = true;
                saveTransactions(transactions);
            }
        }
      }
      
      await sendNewMessage(chatId,
`<b>⏰ ORDER EXPIRED</b>

<blockquote>ID Order: <code>${orderId}</code>
Status: ⏰ <b>Expired</b></blockquote>

<b>⚠️ ALASAN</b>
└─ OTP tidak diterima dalam waktu yang ditentukan

<b>✅ REFUND DIBERIKAN</b>
└─ Saldo <b>${formatCurrency(totalPrice)}</b> telah dikembalikan`,
        { parse_mode: 'HTML' }
      );
    }
  } catch (error) {}
}

bot.on('message', async (msg) => {

    if (!msg || !msg.from) return;
    
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const text = msg.text || ''; 
    
    if (msg.from.is_bot || text.startsWith('/')) return;
    
    const userSelection = userSelections.get(userId);
   
    if (userSelection && userSelection.step === 'custom_deposit_waiting_amount') {
        const cleanText = text.replace(/[^\d]/g, '');
        const amount = parseInt(cleanText);
        
        if (isNaN(amount) || amount < 2000) {
            await sendNewMessage(chatId,
`<b>❌ JUMLAH TIDAK VALID</b>

Minimal: Rp 2.000
Anda: ${text || 'Tidak ada input'}

<b>⚠️ FORMAT YANG BENAR</b>
Angka saja (contoh: 25000)

<b>🔰 SILAKAN COBA LAGI</b>
Masukkan jumlah yang valid:`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { 
                                    text: '🔙 Kembali ke Menu Deposit', 
                                    callback_data: 'deposit_main' 
                                }
                            ]
                        ]
                    }
                }
            );
            userSelections.delete(userId); 
            return;
        }
        
        if (amount > 5000000) {
            await sendNewMessage(chatId,
`<b>❌ JUMLAH TERLALU BESAR</b>

Maksimal: Rp 5.000.000
Anda: Rp ${amount.toLocaleString('id-ID')}

<b>🔰 SILAKAN COBA LAGI</b>
Masukkan jumlah yang valid:`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { 
                                    text: '🔙 Kembali ke Menu Deposit', 
                                    callback_data: 'deposit_main' 
                                }
                            ]
                        ]
                    }
                }
            );
            userSelections.delete(userId); 
            return;
        }
        
        userSelections.delete(userId); 
        
        try {
            await bot.deleteMessage(chatId, msg.message_id);
        } catch (error) {}

        const processingMsg = await sendNewMessage(chatId,
`<b>⏳ MEMPROSES DEPOSIT CUSTOM</b>

Jumlah: Rp ${amount.toLocaleString('id-ID')}
Status: Membuat QR Code...`,
            { parse_mode: 'HTML' }
        );

        await handleDeposit(chatId, userId, amount); 
        
        try {
            await bot.deleteMessage(chatId, processingMsg.message_id);
        } catch (error) {}
        
        return;
    }
    
    if (userSelection && userSelection.step === 'rumahotp_deposit_amount') {
        const cleanText = text.replace(/[^\d]/g, '');
        const amount = parseInt(cleanText);
        
        if (isNaN(amount) || amount < 2000) {
            await sendNewMessage(chatId,
`<b>❌ JUMLAH TIDAK VALID</b>

Minimal: Rp 2.000
Anda: ${text}

<b>⚠️ FORMAT YANG BENAR</b>
Angka saja (contoh: 25000)`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { 
                                    text: '🔙 Kembali ke Menu Deposit', 
                                    callback_data: 'deposit_main' 
                                }
                            ]
                        ]
                    }
                }
            );
            userSelections.delete(userId);
            return;
        }
        
        if (amount > 5000000) {
            await sendNewMessage(chatId,
`<b>❌ JUMLAH TERLALU BESAR</b>

Maksimal: Rp 5.000.000
Anda: Rp ${amount.toLocaleString('id-ID')}`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { 
                                    text: '🔙 Kembali ke Menu Deposit', 
                                    callback_data: 'deposit_main' 
                                }
                            ]
                        ]
                    }
                }
            );
            userSelections.delete(userId);
            return;
        }
        
        userSelections.delete(userId);
        await handleDeposit(chatId, userId, amount);
        return;
    }
});

async function showDepositMenu(chatId, userId, messageId, callbackQueryId) {
    const userBalance = getUserBalance(userId);
    const paymentMethod = getPaymentMethod();
    
    const message = `<b>💰 MENU TOPUP SALDO</b>

User ID: <code>${userId}</code>
Saldo Saat Ini: ${formatCurrency(userBalance)}

<b>📋 INFORMASI TOPUP</b>
Metode: QRIS
Minimal: Rp 2.000
Maksimal: Rp 5.000.000

<b>💰 PILIH NOMINAL</b>
Pilih nominal untuk topup saldo:`;

    userSelections.delete(userId); 
    
    await editMessage(chatId, messageId, callbackQueryId, message, {
        reply_markup: { 
            inline_keyboard: [
                [
                    { 
                        text: '💰 2K', 
                        callback_data: 'deposit_amount_2000' 
                    },
                    { 
                        text: '💰 5K', 
                        callback_data: 'deposit_amount_5000' 
                    },
                    { 
                        text: '💰 10K', 
                        callback_data: 'deposit_amount_10000' 
                    }
                ],
                [
                    { 
                        text: '💰 20K', 
                        callback_data: 'deposit_amount_20000' 
                    },
                    { 
                        text: '💰 50K', 
                        callback_data: 'deposit_amount_50000' 
                    },
                    { 
                        text: '💰 100K', 
                        callback_data: 'deposit_amount_100000' 
                    }
                ],
                [
                    { 
                        text: '💰 200K', 
                        callback_data: 'deposit_amount_200000' 
                    },
                    { 
                        text: '💰 500K', 
                        callback_data: 'deposit_amount_500000' 
                    },
                    { 
                        text: '💰 1 JT', 
                        callback_data: 'deposit_amount_1000000' 
                    }
                ],
                [
                    { 
                        text: '🔢 Custom', 
                        callback_data: 'deposit_custom' 
                    }
                ],
                [
                    { 
                        text: '🔙 Kembali', 
                        callback_data: 'main_menu' 
                    }
                ]
            ] 
        },
        parse_mode: 'HTML',
        disable_web_page_preview: true
    });
}

async function showOtherServices(chatId, userId, messageId, callbackQueryId) {
    try {
        const servicesData = await getServicesCached();
        
        if (!servicesData || !servicesData.success) {
            await editMessage(chatId, messageId, callbackQueryId, 
`<b>❌ GAGAL MENDAPATKAN LAYANAN</b>

Status: Gagal Terhubung

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
                { 
                    parse_mode: 'HTML',
                    disable_web_page_preview: true 
                }
            );
            return;
        }

        const services = servicesData.data;

        const popularServiceNames = [
            'whatsapp', 'telegram', 'instagram', 'facebook', 
            'gojek', 'gopay', 'ovo', 'dana', 'tiktok', 'twitter'
        ];
        
        const otherServices = [];
        for (const service of services) {
            const serviceNameLower = service.service_name.toLowerCase();
            let isPopular = false;
            
            for (const popularName of popularServiceNames) {
                if (serviceNameLower.includes(popularName)) {
                    isPopular = true;
                    break;
                }
            }
            
            if (!isPopular) {
                otherServices.push(service);
            }
        }
        
        const displayServices = otherServices.slice(0, 20);

        if (displayServices.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId, 
`<b>📋 LAYANAN LAINNYA</b>

Status: Tidak Ada Layanan

<b>⚠️ INFORMASI</b>
Tidak ada layanan lainnya tersedia.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '🔙 Kembali', 
                                callback_data: 'nokos_menu' 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }

        const message = `<b>📋 LAYANAN LAINNYA</b>

Total Layanan: ${displayServices.length}

<b>📱 DAFTAR LAYANAN</b>
Pilih layanan untuk order nomor OTP:`;
        
        const keyboard = [];
        
        for (let i = 0; i < displayServices.length; i += 2) {
            const row = [];
            
            if (displayServices[i]) {
                const serviceName = displayServices[i].service_name;
                const buttonText = serviceName.substring(0, 12);
                row.push({ 
                    text: `📱 ${buttonText}`, 
                    callback_data: `nokos_service_${displayServices[i].service_code}` 
                });
            }
            
            if (displayServices[i + 1]) {
                const serviceName = displayServices[i + 1].service_name;
                const buttonText = serviceName.substring(0, 12);
                row.push({ 
                    text: `📱 ${buttonText}`, 
                    callback_data: `nokos_service_${displayServices[i + 1].service_code}` 
                });
            }
            
            if (row.length > 0) {
                keyboard.push(row);
            }
        }

        keyboard.push([
            { 
                text: '🔙 Kembali', 
                callback_data: 'nokos_menu' 
            },
            { 
                text: '🏠 Menu', 
                callback_data: 'main_menu' 
            }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML',
            disable_web_page_preview: true
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId, 
`<b>❌ GAGAL MEMUAT LAYANAN</b>

Status: Error Sistem

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ 
                            text: '🔄 Coba Lagi', 
                            callback_data: 'nokos_menu' 
                        }]
                    ]
                },
                disable_web_page_preview: true
            }
        );
    }
}

async function showCountryMenu(chatId, userId, serviceId, serviceName, messageId, callbackQueryId, page = 0) {
    try {
        const itemsPerPage = 6; 
        userSelections.set(userId, {
            step: 'nokos_country',
            serviceId: serviceId,
            serviceName: serviceName
        });

        await editMessage(chatId, messageId, callbackQueryId,
            '<b>⏳ MEMUAT DAFTAR NEGARA...</b>',
            { parse_mode: 'HTML' }
        );

        const countriesData = await api.getCountries(serviceId);
        
        if (!countriesData || !countriesData.success) {
            await editMessage(chatId, messageId, callbackQueryId, 
`<b>❌ GAGAL MENDAPATKAN NEGARA</b>

Status: Gagal Terhubung

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '🔙 Kembali', 
                                callback_data: `nokos_service_${serviceId}` 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }

        const allCountries = countriesData.data || [];
        
        if (allCountries.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId, 
`<b>❌ NEGARA TIDAK TERSEDIA</b>

Layanan: ${serviceName}
Status: Tidak Ada Negara

<b>⚠️ INFORMASI</b>
Tidak ada negara tersedia untuk layanan ini.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '📱 Pilih Lain', 
                                callback_data: 'nokos_menu' 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }
 
        const indonesiaCountries = [];
        const otherCountries = [];
        
        for (const country of allCountries) {
            const countryNameLower = country.name.toLowerCase();
            if (countryNameLower.includes('indonesia') || countryNameLower.includes('indo')) {
                indonesiaCountries.push(country);
            } else {
                otherCountries.push(country);
            }
        }
        
        otherCountries.sort((a, b) => {
            return a.name.localeCompare(b.name);
        });
        
        const sortedCountries = [...indonesiaCountries, ...otherCountries];

        const totalPages = Math.ceil(sortedCountries.length / itemsPerPage);
        if (page < 0) page = 0;
        if (page >= totalPages) page = totalPages - 1;

        const startIndex = page * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const currentCountries = sortedCountries.slice(startIndex, endIndex);

        const message = `<b>🌍 PILIH NEGARA - ${serviceName.toUpperCase()}</b>

Layanan: ${serviceName}
Total Negara: ${sortedCountries.length}
Halaman: ${page + 1}/${totalPages}

<b>📋 DAFTAR NEGARA</b>
Pilih negara untuk melanjutkan:`;
        
        const keyboard = [];
       
        for (let i = 0; i < currentCountries.length; i += 2) {
            const row = [];
            
            if (currentCountries[i]) {
                const country = currentCountries[i];
                const countryFlag = getFlagEmoji(country.iso_code) || '📍';
                let countryText = country.name;
                if (countryText.length > 10) {
                    countryText = countryText.substring(0, 10);
                }
                
                row.push({ 
                    text: `${countryFlag} ${countryText}`, 
                    callback_data: `nokos_server_list_${country.number_id}_${encodeURIComponent(country.name)}` 
                });
            }
            
            if (currentCountries[i + 1]) {
                const country = currentCountries[i + 1];
                const countryFlag = getFlagEmoji(country.iso_code) || '📍';
                let countryText = country.name;
                if (countryText.length > 10) {
                    countryText = countryText.substring(0, 10);
                }
                
                row.push({ 
                    text: `${countryFlag} ${countryText}`, 
                    callback_data: `nokos_server_list_${country.number_id}_${encodeURIComponent(country.name)}` 
                });
            }
            
            if (row.length > 0) {
                keyboard.push(row);
            }
        }

        const navButtons = [];
        
        if (totalPages > 1) {
            if (page > 0) {
                navButtons.push({ 
                    text: '◀️ Sebelumnya', 
                    callback_data: `nokos_country_page_${serviceId}_${page - 1}` 
                });
            }

            if (page < totalPages - 1) {
                navButtons.push({ 
                    text: 'Selanjutnya ▶️', 
                    callback_data: `nokos_country_page_${serviceId}_${page + 1}` 
                });
            }
            
            if (navButtons.length > 0) {
                keyboard.push(navButtons);
            }
        }

        keyboard.push([
            { 
                text: '🔙 Kembali', 
                callback_data: `nokos_service_${serviceId}` 
            },
            { 
                text: '🏠 Menu', 
                callback_data: 'main_menu' 
            }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML',
            disable_web_page_preview: true
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ TERJADI KESALAHAN</b>

Status: Error Sistem

<b>⚠️ TINDAKAN</b>
Silakan coba lagi atau hubungi CS.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ 
                            text: '🔄 Coba Lagi', 
                            callback_data: `nokos_service_${serviceId}` 
                        }],
                        [{ 
                            text: '🏠 Menu', 
                            callback_data: 'main_menu' 
                        }]
                    ]
                },
                disable_web_page_preview: true
            }
        );
    }
}

async function showOrderConfirmation(chatId, userId, operatorId, providerId, price, messageId, callbackQueryId) {
    try {
        const userSelection = userSelections.get(userId);
        if (!userSelection) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ SESI TIDAK DITEMUKAN</b>

Status: Sesi Kadaluarsa

<b>⚠️ TINDAKAN</b>
Silakan mulai kembali dari menu utama.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: '🏠 Menu', 
                                callback_data: 'main_menu' 
                            }]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }

        const numPrice = Number(price);
        const totalPrice = numPrice;
        const userBalance = getUserBalance(userId);
        const canOrder = userBalance >= totalPrice;
        const formattedPrice = formatCurrency(numPrice);
        const formattedTotal = formatCurrency(totalPrice);
        const formattedBalance = formatCurrency(userBalance);
        
        if (!userSelection.serviceName) {
            userSelection.serviceName = 'Layanan Nokos';
        }
        if (!userSelection.countryName) {
            userSelection.countryName = 'Negara';
        }

        const message = `<b>✅ KONFIRMASI ORDER</b>

Layanan: ${userSelection.serviceName}
Negara: ${userSelection.countryName}
Harga: ${formattedPrice}
Total: ${formattedTotal}

<a href="https://telegra.ph/PENYEBAB-KODE-OTP-SUSAH--TIDAK-MASUK-12-18">Syarat & Ketentuan</a>

<b>💰 INFORMASI SALDO</b>
Saldo Anda: ${formattedBalance}
Status: ${canOrder ? '✅ Cukup' : '❌ Kurang'}
${canOrder ? '✅ Siap diproses' : '❌ Tidak dapat diproses'}

<b>⚠️ KONFIRMASI</b>
${canOrder ? 
    'Klik BELI SEKARANG untuk melanjutkan.' : 
    'Saldo tidak cukup. Deposit terlebih dahulu.'}`;

        userSelection.operatorId = operatorId;
        userSelection.providerId = providerId;
        userSelection.price = price;
        userSelections.set(userId, userSelection);

        const keyboard = [
            [
                { 
                    text: canOrder ? '✅ Beli Sekarang' : '💰 Deposit', 
                    callback_data: canOrder ? 
                        `nokos_confirm_${userSelection.numberId}_${providerId}_${operatorId}_${price}` : 
                        'deposit_main' 
                }
            ],
            [
                { 
                    text: '🔙 Kembali', 
                    callback_data: `nokos_server_list_${userSelection.numberId}_${encodeURIComponent(userSelection.countryName)}` 
                },
                { 
                    text: '🏠 Menu', 
                    callback_data: 'main_menu' 
                }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML',
            disable_web_page_preview: true
        });

    } catch (error) {
        console.error('Error in showOrderConfirmation:', error);
        await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MENAMPILKAN KONFIRMASI</b>

Status: Error Sistem
Error: ${error.message || 'Unknown error'}

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ 
                            text: '🔙 Kembali', 
                            callback_data: 'nokos_menu' 
                        }]
                    ]
                },
                disable_web_page_preview: true
            }
        );
    }
}

async function processNokosOrder(chatId, userId, numberId, providerId, operatorId, price, messageId, callbackQueryId) {
    let totalPrice = 0;

    try {
        const orderKey = `${userId}_${Date.now()}`;

        if (isOrderProcessing(orderKey)) {
            await editMessage(
                chatId,
                messageId,
                callbackQueryId,
                '<b>⏳ ORDER SEDANG DIPROSES</b>\n\nMohon tunggu...',
                { parse_mode: 'HTML' }
            );
            return;
        }

        setOrderProcessing(orderKey, true);

        const gatewayFee = 0;
        const additionalFee = Number(nokos_fee) || 0;
        const priceNumber = Number(price);

        if (isNaN(priceNumber)) {
            await editMessage(
                chatId,
                messageId,
                callbackQueryId,
                `<b>❌ HARGA TIDAK VALID</b>\n\nSilakan ulangi order.`,
                { parse_mode: 'HTML' }
            );
            setOrderProcessing(orderKey, false);
            return;
        }

        const totalFee = gatewayFee + additionalFee;
        totalPrice = priceNumber + totalFee;

        const userBalance = Number(getUserBalance(userId));

        if (userBalance < totalPrice) {
            await editMessage(
                chatId,
                messageId,
                callbackQueryId,
`<b>❌ SALDO TIDAK CUKUP</b>

Saldo Anda : ${formatCurrency(userBalance)}
Harga      : ${formatCurrency(priceNumber)}
Admin Fee  : ${formatCurrency(additionalFee)}
Total Bayar: ${formatCurrency(totalPrice)}

<b>⚠️ TINDAKAN</b>
Silakan deposit terlebih dahulu.`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '💰 Deposit', callback_data: 'deposit_main' }]
                        ]
                    }
                }
            );
            setOrderProcessing(orderKey, false);
            return;
        }

        const deducted = deductUserBalance(userId, totalPrice);
        if (!deducted) {
            await editMessage(
                chatId,
                messageId,
                callbackQueryId,
                `<b>❌ GAGAL MEMOTONG SALDO</b>\n\nSilakan hubungi admin.`,
                { parse_mode: 'HTML' }
            );
            setOrderProcessing(orderKey, false);
            return;
        }

        const orderResult = await api.createOrder(
            numberId,
            providerId,
            operatorId
        );

        if (!orderResult || !orderResult.success) {
            const errorMsg =
                orderResult?.error?.message ||
                orderResult?.message ||
                orderResult?.data?.message ||
                'Error dari API';

            addUserBalance(userId, totalPrice);

            await editMessage(
                chatId,
                messageId,
                callbackQueryId,
`<b>❌ GAGAL MEMBUAT ORDER</b>

Error: ${errorMsg}

<b>✅ SALDO DIKEMBALIKAN</b>
${formatCurrency(totalPrice)}`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                {
                                    text: '🔄 Coba Lagi',
                                    callback_data: `nokos_confirm_${numberId}_${providerId}_${operatorId}_${price}`
                                }
                            ],
                            [{ text: '🏠 Menu', callback_data: 'main_menu' }]
                        ]
                    }
                }
            );
            setOrderProcessing(orderKey, false);
            return;
        }

        const orderData = orderResult.data;
        const expiresInMinutes = Number(orderData.expires_in_minute) || 15;
        const expiresAt = Date.now() + expiresInMinutes * 60 * 1000;

        addTransaction('nokos_orders', {
            userId,
            orderId: orderData.order_id,
            phoneNumber: orderData.phone_number,
            service: orderData.service,
            country: orderData.country,
            operator: orderData.operator,
            price: priceNumber,
            gateway_fee: gatewayFee,
            additional_fee: additionalFee,
            fee: totalFee,
            total: totalPrice,
            status: 'active',
            expiresAt,
            expiresInMinutes,
            otp_received: false,
            otp_code: null,
            refunded: false,
            raw_data: orderResult,
            timestamp: new Date().toISOString()
        });

        const message = `<b>✅ ORDER BERHASIL</b>

ID Order : ${orderData.order_id}
Nomor   : ${orderData.phone_number}
Layanan : ${orderData.service}
Negara  : ${orderData.country}
Operator: ${orderData.operator}

Harga     : ${formatCurrency(priceNumber)}
Admin Fee : ${formatCurrency(additionalFee)}
Total Bayar: ${formatCurrency(totalPrice)}

Expired: ${expiresInMinutes} menit

<b>📌 INSTRUKSI</b>
• Gunakan nomor untuk registrasi
• Tunggu SMS OTP
• Klik tombol CEK OTP`;

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        {
                            text: '🔐 Cek OTP',
                            callback_data: `nokos_check_${orderData.order_id}`
                        },
                        {
                            text: '❌ Batalkan',
                            callback_data: `nokos_cancel_${orderData.order_id}`
                        }
                    ],
                    [
                        { text: '🛒 Order Baru', callback_data: 'nokos_menu' },
                        { text: '🏠 Menu', callback_data: 'main_menu' }
                    ]
                ]
            }
        });

        try {
            const user = await bot.getChat(userId);
            await notifyOrderSuccess(user, orderData, totalPrice, false);
        } catch (notifError) {
        }

        setTimeout(() => {
            monitorOTP(
                chatId,
                userId,
                orderData.order_id,
                totalPrice,
                expiresInMinutes
            );
        }, 5000);

        autoBackupAll();
        setOrderProcessing(orderKey, false);

    } catch (error) {
        try {
            if (totalPrice > 0) {
                addUserBalance(userId, totalPrice);
            }
        } catch {}

        await editMessage(
            chatId,
            messageId,
            callbackQueryId,
`<b>❌ ERROR SISTEM</b>

${error.message || 'Silakan coba lagi'}`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🏠 Menu', callback_data: 'main_menu' }]
                    ]
                }
            }
        );

        setOrderProcessing(`${userId}`, false);
    }
}

async function monitorOTP(chatId, userId, orderId, totalPrice, expiresInMinutes = 15) {
    const maxRetries = Math.floor(expiresInMinutes * 6); 
    let retryCount = 0;
    let errorCount = 0;
    const maxErrors = 3;
    
    const monitorInterval = setInterval(async () => {
        retryCount++;

        if (retryCount >= maxRetries) {
            clearInterval(monitorInterval);
            await autoCancelOrder(chatId, userId, orderId, totalPrice);
            return;
        }

        try {
            const statusResult = await api.getOrderStatus(orderId);
            
            if (!statusResult || !statusResult.success) {
                errorCount++;
                if (errorCount >= maxErrors) {
                    clearInterval(monitorInterval);
                    await sendNewMessage(chatId,
`<b>❌ ORDER ERROR</b>

ID Order: ${orderId}
Status: ❌ Gagal Memeriksa

<b>⚠️ TINDAKAN</b>
Silakan hubungi admin untuk bantuan.`,
                        { parse_mode: 'HTML' }
                    );
                }
                return;
            }

            const orderData = statusResult.data;
            
            if (!orderData) {
                return;
            }

            if (orderData.otp_code && orderData.otp_code !== '-') {
                clearInterval(monitorInterval);

                updateTransactionStatus('nokos_orders', orderId, 'completed');
                
                const transactions = loadTransactions();
                const orderIndex = transactions.nokos_orders?.findIndex(o => 
                    o.id === orderId || o.data?.orderId === orderId
                );
                
                if (orderIndex !== -1) {
                    transactions.nokos_orders[orderIndex].data.otp_received = true;
                    transactions.nokos_orders[orderIndex].data.otp_code = orderData.otp_code;
                    transactions.nokos_orders[orderIndex].data.status = 'completed';
                    transactions.nokos_orders[orderIndex].data.refunded = false;
                    saveTransactions(transactions);
                }

                await sendNewMessage(chatId,
`<b>✅ OTP DITERIMA!</b>

ID Order: ${orderId}
Nomor: ${orderData.phone_number}
Kode OTP: <b>${orderData.otp_code}</b>
Total: ${formatCurrency(totalPrice)}

<b>⚠️ PERHATIAN</b>
Simpan kode OTP dengan aman!`,
                    { parse_mode: 'HTML' }
                );
     
                try {
                    const user = await bot.getChat(userId).catch(() => ({ 
                        id: userId, 
                        first_name: 'User' 
                    }));
                    await notifyOrderSuccess(user, orderData, totalPrice, true);
                } catch (error) {}
                
            } else if (orderData.status === 'completed' || orderData.status === 'canceled' || orderData.status === 'expired') {
                clearInterval(monitorInterval);
                
                updateTransactionStatus('nokos_orders', orderId, orderData.status);
                
                const transactions = loadTransactions();
                const order = transactions.nokos_orders?.find(o => 
                    o.id === orderId || o.data?.orderId === orderId
                );
                
                const otpReceived = order?.data?.otp_received === true;
               
                if ((orderData.status === 'canceled' || orderData.status === 'expired') && !otpReceived) {
                    
                    if (!order?.data?.refunded) {
                        addUserBalance(userId, totalPrice);
               
                        if (transactions.nokos_orders) {
                            const orderIndex = transactions.nokos_orders.findIndex(o => 
                                o.id === orderId || o.data?.orderId === orderId
                            );
                            if (orderIndex !== -1) {
                                transactions.nokos_orders[orderIndex].data.refunded = true;
                                transactions.nokos_orders[orderIndex].data.status = orderData.status;
                                saveTransactions(transactions);
                            }
                        }
                        
                        await sendNewMessage(chatId,
`<b>${orderData.status === 'canceled' ? '❌ ORDER DIBATALKAN' : '⏰ ORDER EXPIRED'}</b>

ID Order: ${orderId}
Status: ${orderData.status === 'canceled' ? '❌ Dibatalkan' : '⏳ Expired'}

<b>✅ SALDO DIKEMBALIKAN</b>
Saldo ${formatCurrency(totalPrice)} telah dikembalikan.`,
                            { parse_mode: 'HTML' }
                        );
                    }
                } else if (orderData.status === 'completed') {
                    if (transactions.nokos_orders) {
                        const orderIndex = transactions.nokos_orders.findIndex(o => 
                            o.id === orderId || o.data?.orderId === orderId
                        );
                        if (orderIndex !== -1) {
                            transactions.nokos_orders[orderIndex].data.otp_received = true;
                            transactions.nokos_orders[orderIndex].data.status = 'completed';
                            saveTransactions(transactions);
                        }
                    }
                }
            }
            
            errorCount = 0;
            
        } catch {
            errorCount++;
            if (errorCount >= maxErrors) {
                clearInterval(monitorInterval);
            }
        }
    }, 10000); 
}

async function checkOTP(chatId, orderId, messageId, callbackQueryId) {
    try {
        await editMessage(chatId, messageId, callbackQueryId,
            '<b>⏳ MENGECEK OTP...</b>',
            { parse_mode: 'HTML' }
        );

        const transactions = loadTransactions();
        const order = transactions.nokos_orders?.find(o => 
            o.id === orderId || o.data?.orderId === orderId
        );
    
        if (order) {
            const orderTime = new Date(order.timestamp).getTime();
            const currentTime = Date.now();
            const threeMinutes = 3 * 60 * 1000;
    
            if (currentTime - orderTime < threeMinutes) {
                const remainingSeconds = Math.ceil((threeMinutes - (currentTime - orderTime)) / 1000);
                const remainingMinutes = Math.floor(remainingSeconds / 60);
                const remainingSecs = remainingSeconds % 60;
                
                await editMessage(chatId, messageId, callbackQueryId,
`<b>⏳ TUNGGU ${remainingMinutes}:${remainingSecs.toString().padStart(2, '0')}</b>

ID Order: ${orderId}
Nomor: ${order.data?.phoneNumber || '-'}
Waktu Order: ${new Date(orderTime).toLocaleTimeString('id-ID')}
Status: ⏳ Menunggu OTP

<b>⚠️ SISTEM OTOMATIS</b>
Sistem cek setiap 10 detik
OTP akan muncul otomatis
Jika tidak ada OTP, refund otomatis
${remainingMinutes}m ${remainingSecs}s lagi bisa cek manual

<b>📋 TINDAKAN</b>
Pilih aksi untuk order ini:`,
                    { 
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [
                                    { 
                                        text: `🔄 Cek Lagi (${remainingMinutes}m)`, 
                                        callback_data: `nokos_check_${orderId}` 
                                    }
                                ],
                                [
                                    { 
                                        text: '🏠 Menu', 
                                        callback_data: 'main_menu' 
                                    }
                                ]
                            ]
                        },
                        disable_web_page_preview: true
                    }
                );
                return;
            }
        }

        const statusResult = await api.getOrderStatus(orderId);
        
        if (!statusResult || !statusResult.success) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MENGECEK OTP</b>

ID Order: ${orderId}
Status: ❌ Gagal Terhubung

<b>⚠️ TINDAKAN</b>
Silakan coba lagi nanti.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { 
                                    text: '🔄 Coba Lagi', 
                                    callback_data: `nokos_check_${orderId}` 
                                },
                                { 
                                    text: '🏠 Menu', 
                                    callback_data: 'main_menu' 
                                }
                            ]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }

        const orderData = statusResult.data;
        
        if (orderData.otp_code && orderData.otp_code !== '-') {
            const orderIndex = transactions.nokos_orders?.findIndex(o => 
                o.id === orderId || o.data?.orderId === orderId
            );
            
            if (orderIndex !== -1) {
                transactions.nokos_orders[orderIndex].data.otp_received = true;
                transactions.nokos_orders[orderIndex].data.otp_code = orderData.otp_code;
                transactions.nokos_orders[orderIndex].data.status = 'completed';
                transactions.nokos_orders[orderIndex].data.refunded = false; 
                saveTransactions(transactions);
            }
            
            await editMessage(chatId, messageId, callbackQueryId,
`<b>✅ OTP DITEMUKAN!</b>

ID Order: ${orderId}
Nomor: ${orderData.phone_number}
Kode OTP: <b>${orderData.otp_code}</b>

<b>📊 STATUS ORDER</b>
✅ Order Selesai
💰 Saldo: Sudah terpakai
❌ Tidak dapat dibatalkan

<b>⚠️ PERHATIAN</b>
Simpan kode OTP dengan aman!`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { 
                                    text: '🛒 Order Baru', 
                                    callback_data: 'nokos_menu' 
                                },
                                { 
                                    text: '🏠 Menu', 
                                    callback_data: 'main_menu' 
                                }
                            ]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );

            try {
                const userId = order.userId;
                const user = await bot.getChat(userId).catch(() => ({ 
                    id: userId, 
                    first_name: 'User' 
                }));
                const price = order.data?.price || 0;
                await notifyOrderSuccess(user, orderData, price, true);
            } catch (error) {}
            
        } else {
            const statusEmoji = orderData.status === 'active' ? '⏳' : 
                              orderData.status === 'completed' ? '✅' : 
                              orderData.status === 'canceled' ? '❌' : 
                              orderData.status === 'expired' ? '⏰' : '❓';
            
            const canCancel = order ? (Date.now() - new Date(order.timestamp).getTime() >= 3 * 60 * 1000) : true;
            
            await editMessage(chatId, messageId, callbackQueryId,
`<b>⏳ MENUNGGU OTP</b>

ID Order: ${orderId}
Nomor: ${orderData.phone_number}
Status: ${statusEmoji} ${orderData.status || 'Active'}

<b>⚠️ INFORMASI</b>
OTP: Belum diterima
Silakan coba lagi nanti

<b>📋 TINDAKAN</b>
Pilih aksi untuk order ini:`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { 
                                    text: '🔄 Cek Lagi', 
                                    callback_data: `nokos_check_${orderId}` 
                                },
                                canCancel ? { 
                                    text: '❌ Batalkan', 
                                    callback_data: `nokos_cancel_${orderId}` 
                                } : { 
                                    text: '⏳ Tunggu 3m',
                                    callback_data: 'no_action'
                                }
                            ],
                            [
                                { 
                                    text: '🏠 Menu', 
                                    callback_data: 'main_menu' 
                                }
                            ]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
        }
    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MENGECEK OTP</b>

ID Order: ${orderId}
Status: ❌ Error Sistem

<b>⚠️ TINDAKAN</b>
Silakan hubungi CS untuk bantuan.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { 
                                text: '🔄 Coba Lagi', 
                                callback_data: `nokos_check_${orderId}` 
                            },
                            { 
                                text: '💬 CS', 
                                url: `https://t.me/${usernamelu.replace('@','')}` 
                            }
                        ],
                        [
                            { 
                                text: '🏠 Menu', 
                                callback_data: 'main_menu' 
                            }
                        ]
                    ]
                },
                disable_web_page_preview: true
            }
        );
    }
}

async function handleDeposit(chatId, userId, amount) {
    const depositKey = `${userId}_deposit`;

    try {
        if (depositProcessing.has(depositKey)) {
            await sendNewMessage(chatId,
`<b>⏳ DEPOSIT SEDANG DIPROSES</b>
Mohon tunggu...`,
                { parse_mode: 'HTML' }
            );
            return;
        }
        depositProcessing.set(depositKey, Date.now());

        const lastReq = lastDepositRequestTime.get(userId) || 0;
        const now = Date.now();
        if (now - lastReq < 5000) {
            depositProcessing.delete(depositKey);
            return sendNewMessage(chatId,
`<b>⏳ TERLALU CEPAT</b>
Coba lagi sebentar.`,
                { parse_mode: 'HTML' }
            );
        }
        lastDepositRequestTime.set(userId, now);

        const amountValidation = validateAmount(amount);
        if (!amountValidation.valid) {
            depositProcessing.delete(depositKey);
            return sendNewMessage(chatId,
`<b>❌ JUMLAH TIDAK VALID</b>
${amountValidation.error}`,
                { parse_mode: 'HTML' }
            );
        }

        const depositAmount = amountValidation.amount;
        if (depositAmount < 2000 || depositAmount > 5000000) {
            depositProcessing.delete(depositKey);
            return sendNewMessage(chatId,
`<b>❌ JUMLAH DI LUAR BATAS</b>
Minimal Rp2.000 – Maksimal Rp5.000.000`,
                { parse_mode: 'HTML' }
            );
        }

        const adminFee = Number(deposit_fee) || 0;
        const requestedTotal = depositAmount + adminFee;

        const loading = await sendNewMessage(
            chatId,
            `<b>⏳ MEMBUAT QR DEPOSIT...</b>`,
            { parse_mode: 'HTML' }
        );

        const paymentMethod = getPaymentMethod();
        const isKhafa = paymentMethod === 'khafa';
        let depositResult;

        if (isKhafa) {
            depositResult = await khafaService.createDeposit(
                userId.toString(),
                requestedTotal
            );
        } else {
            depositResult = await api.createRumahOTPDeposit(
                requestedTotal
            );
        }

        if (!depositResult?.success) {
            depositProcessing.delete(depositKey);
            return editMessage(chatId, loading.message_id, null,
`<b>❌ GAGAL MEMBUAT DEPOSIT</b>
${depositResult?.message || 'Gateway error'}`,
                { parse_mode: 'HTML' }
            );
        }

        const depositData = depositResult.data;
        const depositId = depositData.id || depositData.no_inv;

        const totalToPay = Number(
            depositData.total ||
            depositData.totalAmount ||
            depositData.amount ||
            depositData.pay_amount ||
            requestedTotal
        );

        const realFee = totalToPay - depositAmount;
        
        await notifyOwnerDepositCreated(depositData, userId, depositAmount, 
            realFee - adminFee, totalToPay, depositAmount, paymentMethod);

        const transactionType = isKhafa ? 'khafa_deposits' : 'rumahotp_deposits';

        addTransaction(transactionType, {
            userId,
            id: depositId,
            amount: depositAmount,
            saldo_didapat: depositAmount,
            admin_fee: adminFee,
            gateway_fee: realFee - adminFee,
            total_fee: realFee,
            total_bayar: totalToPay,
            method: 'QRIS',
            status: 'pending',
            payment_method: paymentMethod,
            raw_data: depositResult,
            timestamp: new Date().toISOString(),
            calculation: {
                deposit: depositAmount,
                admin_fee: adminFee,
                total_fee: realFee,
                total_pay: totalToPay,
                received: depositAmount
            }
        });

        const message = `<b>💰 DEPOSIT DIPROSES</b>

ID Deposit: ${depositId}
Nominal: ${formatCurrency(depositAmount)}
Fee Admin: ${formatCurrency(adminFee)}
Total Bayar: <b>${formatCurrency(totalToPay)}</b>
Saldo Masuk: ${formatCurrency(depositAmount)}
Metode: QRIS
Status: ⏳ Menunggu Pembayaran

<b>⚠️ CATATAN</b>
• Total bayar mengikuti QR
• Sudah termasuk biaya QRIS
• Bayar harus sesuai QR

<b>⏰ Berlaku 20 menit</b>`;

        await bot.deleteMessage(chatId, loading.message_id).catch(() => {});

        const qrBuffer = await QRCode.toBuffer(depositData.qr_string, {
            width: 300,
            margin: 1
        });

        const sent = await bot.sendPhoto(chatId, qrBuffer, {
            caption: message,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔍 Cek Status', callback_data: `deposit_status_${depositId}` }],
                    [{ text: '❌ Batalkan', callback_data: `deposit_cancel_${depositId}` }],
                    [
                        { text: '💰 Deposit Lagi', callback_data: 'deposit_main' },
                        { text: '🏠 Menu', callback_data: 'main_menu' }
                    ]
                ]
            }
        });

        userDepositMessages.set(`${userId}_${depositId}`, {
            messageId: sent.message_id,
            createdAt: Date.now(),
            paymentMethod
        });

        setTimeout(() => {
            checkDepositStatus(chatId, depositId, userId, sent.message_id);
        }, 5000);

        autoBackupAll();
        depositProcessing.delete(depositKey);

    } catch (err) {
        depositProcessing.delete(depositKey);
        await sendNewMessage(chatId,
`<b>❌ ERROR SISTEM</b>
${err.message || 'Unknown error'}`,
            { parse_mode: 'HTML' }
        );
    }
}

async function checkDepositStatus(chatId, depositId, userId, messageId = null, retryCount = 0) {
    const maxRetries = 180;
    const transactions = loadTransactions();
    
    let depositData = null;
    let transactionType = null;
    
    const depositTypes = ['khafa_deposits', 'rumahotp_deposits'];
    for (const type of depositTypes) {
        if (transactions[type]) {
            const deposit = transactions[type].find(d => d.data.id === depositId);
            if (deposit) {
                depositData = deposit;
                transactionType = type;
                break;
            }
        }
    }
    
    if (!depositData) {
        return;
    }
    
    if (depositData.status === 'cancelled' || depositData.status === 'canceled') {
        return;
    }
    
    if (depositData.status === 'success' || depositData.status === 'paid') {
        return;
    }
    
    const depositTime = new Date(depositData.timestamp).getTime();
    const currentTime = Date.now();
    const twentyMinutes = 20 * 60 * 1000;
    
    if (currentTime - depositTime > twentyMinutes) {
        if (depositData.status !== 'success' && depositData.status !== 'paid') {
            updateTransactionStatus(transactionType, depositData.id, 'expired');
            
            if (messageId) {
                try {
                    await bot.deleteMessage(chatId, messageId);
                } catch (error) {}
            }
            
            await sendNewMessage(chatId,
`<b>⏰ DEPOSIT KADALUARSA</b>

ID: ${depositId}
Status: Expired (lebih dari 20 menit)

<b>⚠️ INFORMASI</b>
Silakan buat deposit baru.`,
                { parse_mode: 'HTML' }
            );
            return;
        }
    }
    
    const paymentMethod = depositData.data?.payment_method || getPaymentMethod();
    let statusResult = null;
    
    try {
        if (paymentMethod === 'khafa') {
            statusResult = await khafaService.checkDepositStatus(depositId);
        } else {
            statusResult = await api.checkRumahOTPDepositStatus(depositId);
        }
        
        if (statusResult) {
            const depositStatus = statusResult.data?.status || statusResult.status;
            
            if (depositStatus === 'success' || depositStatus === 'paid' || depositStatus === 'Success' || depositStatus === 'Paid') {
                if (depositData.status !== 'success' && depositData.status !== 'paid') {
                    const amountToAdd = depositData.data?.saldo_didapat || 0;
                    
                    if (amountToAdd > 0) {
                        addUserBalance(userId, amountToAdd);
    
                        const pointsAdded = 1; 
                        royaltySystem.addPoints(userId, pointsAdded, 'deposit');
                    }
                    
                    updateTransactionStatus(transactionType, depositData.id, 'success');
                    
                    if (messageId) {
                        try {
                            await bot.deleteMessage(chatId, messageId);
                        } catch (error) {}
                    }
                    
                    const newBalance = getUserBalance(userId);
                    const userPoints = royaltySystem.getUserPoints(userId);
                    
                    await sendNewMessage(chatId,
`<b>✅ DEPOSIT BERHASIL</b>

ID: ${depositId}
Total Bayar: ${formatCurrency(depositData.data?.total_bayar || 0)}
Saldo Ditambahkan: ${formatCurrency(amountToAdd)}
Saldo baru: ${formatCurrency(newBalance)}
Points: +1

<b>🎉 SELAMAT!</b>
Saldo berhasil ditambahkan.`,
                        { parse_mode: 'HTML' }
                    );
                    
                    await notifyDepositSuccess(userId, amountToAdd, depositId, newBalance, paymentMethod);
                    return;
                }
            }
            else if (depositStatus === 'pending' || depositStatus === 'waiting' || depositStatus === 'Pending' || depositStatus === 'Waiting') {
                if (retryCount < maxRetries) {
                    setTimeout(() => {
                        checkDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
                    }, 10000);
                } else {
                    updateTransactionStatus(transactionType, depositData.id, 'expired');
                    
                    if (messageId) {
                        try {
                            await bot.deleteMessage(chatId, messageId);
                        } catch (error) {}
                    }
                    
                    await sendNewMessage(chatId,
`<b>⏰ DEPOSIT KADALUARSA</b>

ID: ${depositId}
Status: Tidak dibayar dalam 30 menit

<b>⚠️ INFORMASI</b>
Silakan buat deposit baru.`,
                        { parse_mode: 'HTML' }
                    );
                }
                return;
            }
            else if (depositStatus === 'cancelled' || depositStatus === 'expired' || depositStatus === 'failed' || depositStatus === 'cancel') {
                updateTransactionStatus(transactionType, depositData.id, depositStatus);
                
                if (messageId) {
                    try {
                        await bot.deleteMessage(chatId, messageId);
                    } catch (error) {}
                }
                
                await sendNewMessage(chatId,
`<b>❌ DEPOSIT ${depositStatus.toUpperCase()}</b>

ID: ${depositId}
Status: ${depositStatus}

<b>⚠️ INFORMASI</b>
Silakan buat deposit baru.`,
                    { parse_mode: 'HTML' }
                );
                return;
            }
        }
    } catch (error) {
        if (retryCount < maxRetries) {
            setTimeout(() => {
                checkDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
            }, 10000);
        }
        return;
    }
    
    if (retryCount < maxRetries) {
        setTimeout(() => {
            checkDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
        }, 10000);
    }
}

async function checkDepositStatusRetry(chatId, depositId, userId, messageId = null, retryCount = 0) {
    const transactions = loadTransactions();
    
    let depositData = null;
    let transactionType = null;
    
    const depositTypes = ['khafa_deposits', 'rumahotp_deposits'];
    for (const type of depositTypes) {
        if (transactions[type]) {
            const deposit = transactions[type].find(d => d.data.id === depositId);
            if (deposit) {
                depositData = deposit;
                transactionType = type;
                break;
            }
        }
    }
    
    if (!depositData) {
        await sendNewMessage(chatId,
`<b>⚠️ DEPOSIT TIDAK DITEMUKAN</b>

ID: ${depositId}
Status: Tidak ditemukan dalam sistem

<b>⚠️ TINDAKAN</b>
Silakan hubungi admin untuk bantuan.`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    const paymentMethod = depositData.data?.payment_method || getPaymentMethod();
    
    if (depositData.status === 'cancelled' || depositData.status === 'canceled') {
        if (messageId) {
            try {
                await bot.deleteMessage(chatId, messageId);
            } catch (error) {}
        }
        
        await sendNewMessage(chatId,
`<b>✅ DEPOSIT SUDAH DIBATALKAN</b>

ID: ${depositId}
Status: ❌ Dibatalkan

<b>⚠️ INFORMASI</b>
Deposit ini sudah dibatalkan sebelumnya.`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    if (depositData.status === 'success' || depositData.status === 'paid') {
        if (messageId) {
            try {
                await bot.deleteMessage(chatId, messageId);
            } catch (error) {}
        }
        
        await sendNewMessage(chatId,
`<b>✅ DEPOSIT SUDAH BERHASIL</b>

ID: ${depositId}
Status: ✅ Sudah dibayar

<b>⚠️ INFORMASI</b>
Deposit ini sudah berhasil dibayar.`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    checkDepositStatus(chatId, depositId, userId, messageId, retryCount);
}

async function cancelDeposit(chatId, userId, depositId, messageId, callbackQueryId) {
    try {
        const transactions = loadTransactions();
        
        let depositFound = null;
        let depositType = null;
        
        const depositTypes = ['khafa_deposits', 'rumahotp_deposits'];
        for (const type of depositTypes) {
            if (transactions[type]) {
                const deposit = transactions[type].find(d => d.data.id === depositId);
                if (deposit) {
                    depositFound = deposit;
                    depositType = type;
                    break;
                }
            }
        }
        
        if (!depositFound) {
            await sendNewMessage(chatId,
`<b>⚠️ DEPOSIT TIDAK DITEMUKAN</b>

ID: ${depositId}
Status: Data tidak ditemukan di database lokal.`,
                { parse_mode: 'HTML' }
            );
            return;
        }
        
        if (depositFound.status === 'success' || depositFound.status === 'paid') {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '❌ Deposit sudah dibayar, tidak bisa dibatalkan',
                show_alert: true
            });
            return;
        }
        
        if (depositFound.status === 'cancelled') {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '❌ Deposit sudah dibatalkan sebelumnya',
                show_alert: true
            });
            return;
        }
        
        await bot.answerCallbackQuery(callbackQueryId, {
            text: '⏳ Membatalkan deposit...',
            show_alert: false
        });
        
        try {
            await bot.deleteMessage(chatId, messageId);
        } catch (error) {}
        
        userDepositMessages.delete(`${userId}_${depositId}`);
        
        updateTransactionStatus(depositType, depositId, 'cancelled');
        
        await sendNewMessage(chatId,
`<b>✅ DEPOSIT DIBATALKAN</b>

<blockquote>ID Deposit: <code>${depositId}</code>
Status: ❌ Dibatalkan</blockquote>`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { 
                                text: '💰 Deposit Lagi', 
                                callback_data: 'deposit_main' 
                            },
                            { 
                                text: '🏠 Menu', 
                                callback_data: 'main_menu' 
                            }
                        ]
                    ]
                }
            }
        );
        
    } catch (error) {
        await bot.answerCallbackQuery(callbackQueryId, {
            text: '❌ Gagal membatalkan deposit',
            show_alert: true
        });
    }
}

async function checkDepositStatusSilent(chatId, depositId, userId, messageId, callbackQueryId) {
    const transactions = loadTransactions();
    const deposit = ['khafa_deposits', 'rumahotp_deposits']
        .flatMap(type => transactions[type] || [])
        .find(d => d.data.id === depositId);
    
    const paymentMethod = deposit?.data?.payment_method || getPaymentMethod();
    
    try {
        let statusResult;
        let statusText = '';
        
        await bot.answerCallbackQuery(callbackQueryId, {
            text: '⏳ Memuat status...',
            show_alert: false
        }).catch(() => {});
        
        if (paymentMethod === 'khafa') {
            statusResult = await khafaService.checkDepositStatus(depositId);
            
            if (statusResult && statusResult.success) {
                const status = String(statusResult.data.status || '').toLowerCase();
                statusText = getStatusText(status);
            }
        } else {
            statusResult = await api.checkRumahOTPDepositStatus(depositId);
            
            if (statusResult && statusResult.success) {
                const status = String(statusResult.data.status || '').toLowerCase();
                statusText = getStatusText(status);
            }
        }
        
        if (!statusText) {
            if (deposit) {
                const dbStatus = String(deposit.status || deposit.data?.status || '').toLowerCase();
                statusText = getStatusText(dbStatus);
            } else {
                statusText = '❌ Deposit tidak ditemukan';
            }
        }
        
        await bot.answerCallbackQuery(callbackQueryId, {
            text: statusText,
            show_alert: true
        });
        
    } catch (error) {
        await bot.answerCallbackQuery(callbackQueryId, {
            text: '❌ Error memeriksa status',
            show_alert: true
        });
    }
}

function getStatusText(status) {
    const statusLower = String(status || '').toLowerCase();
    
    if (statusLower.includes('success') || statusLower.includes('paid')) {
        return '✅ Sudah Dibayar';
    } else if (statusLower.includes('pending') || statusLower.includes('waiting')) {
        return '⏳ Belum Dibayar';
    } else if (statusLower.includes('expired')) {
        return '⏰ Pembayaran Expired';
    } else if (statusLower.includes('cancel') || statusLower.includes('cancelled')) {
        return '❌ Dibatalkan';
    } else if (statusLower.includes('failed')) {
        return '❌ Gagal';
    } else {
        return `❓ Status: ${status || 'Tidak diketahui'}`;
    }
}

async function showOrderHistory(chatId, userId, messageId, callbackQueryId) {
    try {
        const transactions = loadTransactions();
        const allOrders = transactions.nokos_orders || [];
        const completedOrders = allOrders.filter(order => 
            order.status === 'completed' || 
            order.status === 'cancelled' || 
            order.status === 'canceled' ||
            order.status === 'expired' ||
            order.data?.status === 'completed' ||
            order.data?.status === 'cancelled' ||
            order.data?.status === 'canceled' ||
            order.data?.status === 'expired'
        );
        
        const activeOrdersWithOTP = allOrders.filter(order => 
            (order.status === 'active' || !order.status) && 
            order.data?.otp_received === true
        );
        
        const ordersToShow = [...completedOrders, ...activeOrdersWithOTP];
        
        if (ordersToShow.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>📋 RIWAYAT ORDER</b>

Total Order: 0
Status: Belum Ada Riwayat

<b>⚠️ INFORMASI</b>
Belum ada riwayat order yang selesai.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { 
                                    text: '🛒 Buat Order', 
                                    callback_data: 'nokos_menu' 
                                }
                            ],
                            [
                                { 
                                    text: '🏠 Menu', 
                                    callback_data: 'main_menu' 
                                }
                            ]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }

        const recentOrders = ordersToShow
            .sort((a, b) => new Date(b.timestamp || b.data?.timestamp || 0) - new Date(a.timestamp || a.data?.timestamp || 0))
            .slice(0, 15);
        
        let message = `<b>📋 RIWAYAT ORDER</b>

Total Order: ${allOrders.length}
Selesai/Dengan OTP: ${ordersToShow.length}
Ditampilkan: ${recentOrders.length}

<b>📱 DAFTAR ORDER</b>
Urutan dari terbaru:
`;
        
        recentOrders.forEach((order, index) => {
            const orderData = order.data || order;
            const date = new Date(order.timestamp || orderData.timestamp || Date.now()).toLocaleString('id-ID');
            const maskedPhone = maskPhoneNumber(orderData.phoneNumber || orderData.phone_number);
            
            const status = order.status || orderData.status;
            const otpReceived = orderData.otp_received === true;
            const otpCode = orderData.otp_code || '-';
            
            let statusEmoji = '❓';
            let statusText = 'Unknown';
            
            if (status === 'completed' || otpReceived) {
                statusEmoji = '✅';
                statusText = 'Selesai';
            } else if (status === 'cancelled' || status === 'canceled') {
                statusEmoji = '❌';
                statusText = 'Dibatalkan';
            } else if (status === 'expired') {
                statusEmoji = '⏰';
                statusText = 'Expired';
            } else if (status === 'active') {
                statusEmoji = '⏳';
                statusText = 'Aktif';
            }
            
            message += `<b>${index + 1}. ${orderData.service || 'Nokos'}</b>\n`;
            message += `ID: ${orderData.orderId || order.id}\n`;
            message += `Nomor: ${maskedPhone}\n`;
            message += `Negara: ${orderData.country || '-'}\n`;
            message += `Harga: ${formatCurrency(orderData.price || 0)}\n`;
            message += `Status: ${statusEmoji} ${statusText}\n`;
            message += `OTP: ${otpCode}\n`;
            message += `Tanggal: ${date}\n\n`;
        });

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: {
                inline_keyboard: [
                    [
                        { 
                            text: '🛒 Order Baru', 
                            callback_data: 'nokos_menu' 
                        },
                        { 
                            text: '🔄 Refresh', 
                            callback_data: 'order_history' 
                        }
                    ],
                    [
                        { 
                            text: '🏠 Menu', 
                            callback_data: 'main_menu' 
                        }
                    ]
                ]
            }
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MEMUAT RIWAYAT</b>

Status: ❌ Error Sistem

<b>⚠️ TINDAKAN</b>
Silakan coba lagi atau hubungi CS.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { 
                                text: '🔄 Coba Lagi', 
                                callback_data: 'order_history' 
                            }
                        ]
                    ]
                },
                disable_web_page_preview: true
            }
        );
    }
}

async function showDepositHistory(chatId, userId, messageId, callbackQueryId) {
    try {
        const transactions = loadTransactions();
        const allDeposits = [];
        
        if (transactions.rumahotp_deposits) {
            allDeposits.push(...transactions.rumahotp_deposits);
        }
        if (transactions.khafa_deposits) { 
            allDeposits.push(...transactions.khafa_deposits);
        }
        
        const successfulDeposits = allDeposits.filter(deposit => 
            deposit.status === 'success' || deposit.status === 'paid'
        );
        
        successfulDeposits.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        
        if (successfulDeposits.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
`<b>💰 RIWAYAT DEPOSIT</b>

Total Deposit: 0
Status: Belum Ada Riwayat

<b>⚠️ INFORMASI</b>
Belum ada riwayat deposit yang sukses.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { 
                                    text: '💰 Deposit', 
                                    callback_data: 'deposit_main' 
                                }
                            ],
                            [
                                { 
                                    text: '🏠 Menu', 
                                    callback_data: 'main_menu' 
                                }
                            ]
                        ]
                    },
                    disable_web_page_preview: true
                }
            );
            return;
        }

        const recentDeposits = successfulDeposits.slice(0, 15);
        
        let message = `<b>💰 RIWAYAT DEPOSIT SUKSES</b>

Total Deposit: ${successfulDeposits.length}
Ditampilkan: ${recentDeposits.length}

<b>📋 DAFTAR DEPOSIT</b>
Urutan dari terbaru:
`;
        
        recentDeposits.forEach((deposit, index) => {
            const depositData = deposit.data;
            const date = new Date(deposit.timestamp).toLocaleString('id-ID');
            
            message += `<b>${index + 1}. Deposit ${formatCurrency(depositData.amount || depositData.total || 0)}</b>\n`;
            message += `ID: ${depositData.id}\n`;
            message += `Jumlah: ${formatCurrency(depositData.amount || depositData.total || 0)}\n`;
            message += `Diterima: ${formatCurrency(depositData.diterima || depositData.get_balance || depositData.amount || 0)}\n`;
            message += `Status: ✅ ${deposit.status || 'unknown'}\n`;
            message += `Tanggal: ${date}\n\n`;
        });

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: {
                inline_keyboard: [
                    [
                        { 
                            text: '💰 Deposit Lagi', 
                            callback_data: 'deposit_main' 
                        },
                        { 
                            text: '🔄 Refresh', 
                            callback_data: 'deposit_history' 
                        }
                    ],
                    [
                        { 
                            text: '🏠 Menu', 
                            callback_data: 'main_menu' 
                        }
                    ]
                ]
            }
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
`<b>❌ GAGAL MEMUAT RIWAYAT</b>

Status: ❌ Error Sistem

<b>⚠️ TINDAKAN</b>
Silakan coba lagi atau hubungi CS.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { 
                                text: '🔄 Coba Lagi', 
                                callback_data: 'deposit_history' 
                            }
                        ]
                    ]
                },
                disable_web_page_preview: true
            }
        );
    }
}

bot.on('callback_query', async (callbackQuery) => {
  const msg = callbackQuery.message;
  const user = callbackQuery.from;
  const data = callbackQuery.data;
  const userId = user.id.toString();
  const chatId = msg.chat.id;
  const messageId = msg.message_id;
  const callbackQueryId = callbackQuery.id;
  
  try {
    bot.answerCallbackQuery(callbackQueryId, { 
      text: '',
      show_alert: false 
    }).catch(() => {});
    
    if (data === 'main_menu') {
      await showMainMenu(chatId, user.id, user, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'nokos_menu') {
      await showNokosMenu(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'nokos_other_services') {
      await showOtherServices(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data.startsWith('nokos_service_')) {
      const serviceId = data.replace('nokos_service_', '');
      const servicesData = await getServicesCached(); 
      if (servicesData && servicesData.success) {
        const service = servicesData.data.find(s => s.service_code == serviceId);
        if (service) {
          await showCountryMenu(chatId, user.id, serviceId, service.service_name, messageId, callbackQueryId);
        }
      }
      return;
    }
    
    if (data === 'setpay_khafa') {
  if (!owner_ids.includes(user.id.toString())) {
    return bot.answerCallbackQuery(callbackQueryId, {
      text: '⛔ AKSES DITOLAK\nHanya owner yang dapat mengatur metode pembayaran',
      show_alert: true
    });
  }
  setPaymentMethod('khafa');
  await editMessage(chatId, messageId, callbackQueryId,
`<b>✅ METODE PEMBAYARAN DIUBAH</b>

Rumah OTP: ❌ Nonaktif
Khafa: ✅ Aktif`,
    { 
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: '🏦 RUMAH OTP', 
              callback_data: 'setpay_rumahotp' 
            },
            { 
              text: '💳 KHAFA', 
              callback_data: 'setpay_khafa' 
            }
          ]
        ]
      },
      disable_web_page_preview: true
    }
  );
  return;
}

    if (data === 'setpay_rumahotp') {
      if (!owner_ids.includes(user.id.toString())) {
        return bot.answerCallbackQuery(callbackQueryId, {
          text: '⛔ AKSES DITOLAK\nHanya owner yang dapat mengatur metode pembayaran',
          show_alert: true
        });
      }
      setPaymentMethod('rumahotp');
      await editMessage(chatId, messageId, callbackQueryId,
`<b>✅ METODE PEMBAYARAN DIUBAH</b>

Rumah OTP: ✅ Aktif
Khafa: ❌ Nonaktif`,
        { 
          parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: '🏦 RUMAH OTP', 
              callback_data: 'setpay_rumahotp' 
            },
            { 
              text: '💳 KHAFA', 
              callback_data: 'setpay_khafa' 
            }
          ]
        ]
      },
       disable_web_page_preview: true
        }
      );
      return;
    }

    if (data.startsWith('nokos_country_page_')) {
      const parts = data.replace('nokos_country_page_', '').split('_');
      const serviceId = parts[0];
      const page = parseInt(parts[1]);
      const servicesData = await getServicesCached();
      if (servicesData && servicesData.success) {
        const service = servicesData.data.find(s => s.service_code == serviceId);
        if (service) {
          await showCountryMenu(chatId, user.id, serviceId, service.service_name, messageId, callbackQueryId, page);
        }
      }
      return;
    }
    
    if (data.startsWith('nokos_server_list_')) {
      try {
        const parts = data.replace('nokos_server_list_', '').split('_');
        if (parts.length < 2) {
            throw new Error('Format data server tidak valid');
        }
        const numberId = parts[0];
        const countryName = decodeURIComponent(parts.slice(1).join('_'));
        await showServerList(chatId, user.id, numberId, countryName, messageId, callbackQueryId);
      } catch (error) {
        bot.answerCallbackQuery(callbackQueryId, {
            text: '❌ Error memproses pilihan server',
            show_alert: true
        }).catch(() => {});
      }
      return;
    }
    
    if (data.startsWith('nokos_server_')) {
      try {
        const parts = data.replace('nokos_server_', '').split('_');
        if (parts.length < 3) {
            throw new Error('Format data server tidak valid');
        }
        const providerId = parts[0];
        const price = parts[1];
        const rate = parts[2];
        const userSelection = userSelections.get(user.id) || {};
        userSelection.providerId = providerId;
        userSelection.price = price;
        userSelection.rate = rate;
        userSelections.set(user.id, userSelection);
        await showOperatorMenu(chatId, user.id, userSelection.numberId, price, userSelection.countryName, messageId, callbackQueryId);
      } catch (error) {
        bot.answerCallbackQuery(callbackQueryId, {
            text: '❌ Error memilih server',
            show_alert: true
        }).catch(() => {});
      }
      return;
    }
    
    if (data.startsWith('nokos_operator_')) {
      const parts = data.replace('nokos_operator_', '').split('_');
      const operatorId = parts[0];
      const providerId = parts[1];
      const price = parts[2];
      await showOrderConfirmation(chatId, user.id, operatorId, providerId, price, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'owner_menu') {
      await showOwnerMenu(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data.startsWith('nokos_confirm_')) {
      const parts = data.replace('nokos_confirm_', '').split('_');
      const numberId = parts[0];
      const providerId = parts[1];
      const operatorId = parts[2];
      const price = parts[3];
      await processNokosOrder(chatId, user.id, numberId, providerId, operatorId, price, messageId, callbackQueryId);
      return;
    }
    
    if (data.startsWith('server_prev_')) {
      const parts = data.replace('server_prev_', '').split('_');
      const numberId = parts[0];
      const countryName = decodeURIComponent(parts.slice(1, parts.length - 1).join('_'));
      const startIndex = parseInt(parts[parts.length - 1]);
      await showServerListEnhanced(chatId, user.id, numberId, countryName, messageId, callbackQueryId, startIndex);
      return;
    }
    
    if (data.startsWith('server_next_')) {
      const parts = data.replace('server_next_', '').split('_');
      const numberId = parts[0];
      const countryName = decodeURIComponent(parts.slice(1, parts.length - 1).join('_'));
      const startIndex = parseInt(parts[parts.length - 1]);
      await showServerListEnhanced(chatId, user.id, numberId, countryName, messageId, callbackQueryId, startIndex);
      return;
    }
    
    if (data.startsWith('nokos_check_')) {
      const orderId = data.replace('nokos_check_', '');
      await checkOTP(chatId, orderId, messageId, callbackQueryId);
      return;
    }
    
    if (data.startsWith('nokos_cancel_')) {
      const orderId = data.replace('nokos_cancel_', '');
      await cancelOrder(chatId, user.id, orderId, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'deposit_main') {
      await showDepositMenu(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'order_history') {
      await showOrderHistory(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'deposit_custom') {
      userSelections.set(user.id.toString(), {
        step: 'custom_deposit_waiting_amount',
        chatId: chatId,
        messageId: messageId
      });
      
      await editMessage(chatId, messageId, callbackQueryId,
`<b>🔢 DEPOSIT CUSTOM</b>

Masukkan jumlah deposit yang diinginkan
Format: Angka saja (contoh: 25000)

<b>📋 ATURAN</b>
Minimal: Rp 2.000
Maksimal: Rp 5.000.000

<b>❌ BATALKAN</b>
Ketik /start untuk membatalkan

<b>💡 CONTOH</b>
25000 (untuk Rp 25.000)`,
        {
          parse_mode: 'HTML',
          disable_web_page_preview: true,
          reply_markup: {
            inline_keyboard: [
              [
                { 
                  text: '🔙 Kembali ke Menu Deposit', 
                  callback_data: 'deposit_main' 
                }
              ]
            ]
          }
        }
      );
      return;
    }
    
    if (data.startsWith('confirm_withdraw_')) {
    const withdrawData = data.replace('confirm_withdraw_', '');
    const [targetNumber, nominal] = withdrawData.split('_');
    await processWithdraw(chatId, user.id, targetNumber, parseInt(nominal), messageId, callbackQueryId);
    return;
}
    if (data === 'menu_products') {
    await showProductsMenu(chatId, user.id, messageId, callbackQueryId);
    return;
}

if (data.startsWith('buy_')) {
    const productCode = data.replace('buy_', '');
    await showProductPaymentOptions(chatId, user.id, productCode, messageId, callbackQueryId);
    return;
}

if (data.startsWith('pay_product_')) {
    const parts = data.replace('pay_product_', '').split('_');
    const productCode = parts[0];
    const paymentMethod = parts[1];
    await processProductPayment(chatId, user.id, productCode, paymentMethod, messageId, callbackQueryId);
    return;
}

if (data.startsWith('cancel_product_')) {
    const paymentId = data.replace('cancel_product_', '');
    await handleCancelProductPayment(chatId, paymentId, user.id, messageId, callbackQueryId);
    return;
}

if (data.startsWith('check_product_status_')) {
    const paymentId = data.replace('check_product_status_', '');
    await checkProductPaymentStatus(chatId, paymentId, null, userId);
    await bot.answerCallbackQuery(callbackQueryId, {
        text: '⏳ Memeriksa status pembayaran...',
        show_alert: false
    });
    return;
}

if (data.startsWith('confirm_product_')) {
    const parts = data.replace('confirm_product_', '').split('_');
    const productCode = parts[0];
    const paymentMethod = parts[1];
    await processProductPayment(chatId, user.id, productCode, paymentMethod, messageId, callbackQueryId);
    return;
}

if (data.startsWith('confirm_saldo_')) {
    const productCode = data.replace('confirm_saldo_', '');
    const productDB = loadDataProduct();
    let productFound = null;
    
    for (const product of Object.values(productDB.products)) {
        if (product.buyCode.toLowerCase() === productCode.toLowerCase()) {
            productFound = product;
            break;
        }
    }
    
    if (!productFound) {
        await bot.answerCallbackQuery(callbackQueryId, {
            text: '❌ Produk tidak ditemukan',
            show_alert: true
        });
        return;
    }
    
    const userId = user.id;
    const userBalance = getUserBalance(userId);
    
    if (userBalance < productFound.price) {
        await bot.answerCallbackQuery(callbackQueryId, {
            text: '❌ Saldo tidak cukup',
            show_alert: true
        });
        return;
    }

    const deductionSuccess = deductUserBalance(userId, productFound.price);
    
    if (!deductionSuccess) {
        await bot.answerCallbackQuery(callbackQueryId, {
            text: '❌ Gagal memotong saldo',
            show_alert: true
        });
        return;
    }
    
    productFound.stock -= 1;
    productFound.status = productFound.stock > 0 ? 'active' : 'out_of_stock';
    
    const productDB2 = loadDataProduct();
    for (const [id, prod] of Object.entries(productDB2.products)) {
        if (prod.buyCode === productFound.buyCode) {
            productDB2.products[id] = productFound;
            break;
        }
    }
    saveDataProduct(productDB2);

    await editMessage(chatId, messageId, callbackQueryId,
        `<b>✅ PEMBAYARAN BERHASIL</b>

━━━━━━━━━━━━━━━━━━━

<b>Produk:</b> ${productFound.name}
<b>Harga:</b> ${formatCurrency(productFound.price)}
<b>Kode:</b> <code>${productFound.buyCode}</code>

━━━━━━━━━━━━━━━━━━━

<b>💰 SALDO SEKARANG</b>
${formatCurrency(getUserBalance(userId))}

━━━━━━━━━━━━━━━━━━━

<b>🔄 Mengirim file...</b>`,
        { parse_mode: "HTML" }
    );
    
    const fileData = productFound.fileData;
    
    if (fileData.fileType === 'document') {
        await bot.sendDocument(chatId, fileData.fileId, {
            caption: `<b>✅ PEMBAYARAN BERHASIL!</b>

━━━━━━━━━━━━━━━━━━━

<b>Produk:</b> ${productFound.name}
<b>Harga:</b> ${formatCurrency(productFound.price)}
<b>Kode:</b> <code>${productFound.buyCode}</code>

━━━━━━━━━━━━━━━━━━━

<b>🎉 Selamat menikmati produk Anda!</b>`,
            parse_mode: 'HTML'
        });
    } else if (fileData.fileType === 'photo') {
        await bot.sendPhoto(chatId, fileData.fileId, {
            caption: `<b>✅ PEMBAYARAN BERHASIL!</b>

━━━━━━━━━━━━━━━━━━━

<b>Produk:</b> ${productFound.name}
<b>Harga:</b> ${formatCurrency(productFound.price)}
<b>Kode:</b> <code>${productFound.buyCode}</code>

━━━━━━━━━━━━━━━━━━━

<b>🎉 Selamat menikmati produk Anda!</b>`,
            parse_mode: 'HTML'
        });
    } else if (fileData.fileType === 'text') {
        await sendNewMessage(chatId,
            `<b>✅ PEMBAYARAN BERHASIL!</b>

━━━━━━━━━━━━━━━━━━━

<b>Produk:</b> ${productFound.name}
<b>Harga:</b> ${formatCurrency(productFound.price)}
<b>Kode:</b> <code>${productFound.buyCode}</code>

━━━━━━━━━━━━━━━━━━━

<b>📝 Konten:</b>
<code>${fileData.textContent}</code>`,
            { parse_mode: 'HTML' }
        );
    }

    await sendNewMessage(chatId,
        `<b>🙏 Terima kasih telah berbelanja!</b>

━━━━━━━━━━━━━━━━━━━

Gunakan tombol di bawah untuk belanja lagi.`,
        {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "🛒 Belanja Lagi", callback_data: "menu_products" },
                        { text: "🏠 Menu Utama", callback_data: "main_menu" }
                    ]
                ]
            }
        }
    );
    
    return;
}

    if (data === 'points_menu') {
      await showPointsMenu(chatId, userId, messageId, callbackQueryId);
      return;
    }

    if (data === 'redeem_points') {
      await redeemUserPoints(chatId, userId, messageId, callbackQueryId);
      return;
    }

    if (data === 'deposit_history') {
      await showDepositHistory(chatId, user.id, messageId, callbackQueryId);
      return;
    }

    if (data.startsWith('deposit_status_')) {
      const depositId = data.replace('deposit_status_', '');
      await checkDepositStatusSilent(chatId, depositId, user.id, messageId, callbackQueryId);
      return;
    }   
    
    if (data.startsWith('deposit_cancel_')) {
    const depositId = data.replace('deposit_cancel_', '');
    const transactions = loadTransactions();
    
    let depositFound = null;
    for (const type of ['khafa_deposits', 'rumahotp_deposits']) {
        if (transactions[type]) {
            const deposit = transactions[type].find(d => d.data.id === depositId);
            if (deposit) {
                depositFound = deposit;
                break;
            }
        }
    }
    
    if (depositFound && (depositFound.status === 'success' || depositFound.status === 'paid')) {
        await bot.answerCallbackQuery(callbackQueryId, {
            text: '❌ Deposit sudah dibayar, tidak bisa dibatalkan',
            show_alert: true
        });
        return;
    }
    
    if (depositFound && depositFound.status === 'cancelled') {
        await bot.answerCallbackQuery(callbackQueryId, {
            text: '❌ Deposit sudah dibatalkan sebelumnya',
            show_alert: true
        });
        return;
    }
    
    await bot.answerCallbackQuery(callbackQueryId, {
        text: '⏳ Membatalkan deposit...',
        show_alert: false
    });
    
    await cancelDeposit(chatId, user.id, depositId, messageId, callbackQueryId);
    return;
}
    
    if (data === 'refresh_maintenance') {
        const userId = user.id.toString();
        const maintenance = getMaintenanceInfo();
        if (maintenance.active && !owner_ids.includes(userId)) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '🛠️ Bot masih dalam maintenance',
                show_alert: true
            });
            return;
        }
        
        balanceCache.delete(userId);
        await bot.deleteMessage(chatId, messageId).catch(() => {});
        saveUser(userId);
        await showMainMenu(chatId, userId, user, null, callbackQueryId);
        return;
    }
    
    if (data.startsWith('deposit_amount_')) {
        const amount = data.replace('deposit_amount_', '');
        userSelections.delete(user.id);
        await bot.deleteMessage(chatId, messageId).catch(() => {});
        await handleDeposit(chatId, user.id, parseInt(amount));
        return;
    }
    
    bot.answerCallbackQuery(callbackQueryId, { 
        text: '❌ Tombol tidak dikenali', 
        show_alert: false 
    }).catch(() => {});
    
} catch (error) {
    try {
        await sendNewMessage(chatId,
`<b>❌ TERJADI KESALAHAN</b>

${error.message || 'Unknown error'}`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { 
                                text: '🔄 Coba Lagi', 
                                callback_data: 'main_menu' 
                            }
                        ]
                    ]
                },
                disable_web_page_preview: true
            }
        );
    } catch (e) {}
  }
});

const servicesCache = {
  data: null,
  timestamp: 0,
  ttl: 2 * 60 * 1000,
  loading: false
};

async function getServicesCached() {
  const now = Date.now();
  
  if (servicesCache.data && (now - servicesCache.timestamp < servicesCache.ttl)) {
    return servicesCache.data;
  }
  
  if (servicesCache.loading) {
    return servicesCache.data || { success: false, data: [] };
  }
  
  servicesCache.loading = true;
  
  try {
    const servicesData = await api.getServices();
    if (servicesData && servicesData.success) {
      servicesCache.data = servicesData;
      servicesCache.timestamp = now;
    }
    return servicesData;
  } catch (error) {
    return servicesCache.data || { success: false, data: [] };
  } finally {
    servicesCache.loading = false;
  }
}

async function preloadAllData() {
  try {
    await getServicesCached();
    
    const balances = loadBalances();
    Object.entries(balances).forEach(([userId, balance]) => {
      balanceCache.set(userId, parseInt(balance) || 0);
    });
    
    loadTransactions();
  } catch (error) {}
}

preloadAllData();

async function notifyOrderSuccess(user, orderData, price, hasOTP = false) {
    try {
        const orderId = orderData.order_id || orderData.id;
        const userId = user.id || user.userId;
        const firstName = user.first_name || user.firstName || 'User';
        const username = user.username ? `@${user.username}` : 'Tidak ada username';
        const phoneNumber = orderData.phone_number || orderData.phoneNumber || orderData.number || '-';
        const maskedPhone = maskPhoneNumber(phoneNumber);     
        const formattedPrice = formatCurrency(price);
        const serviceName = orderData.service || orderData.service_name || 'Layanan';
        const country = orderData.country || 'Unknown';
        const operator = orderData.operator || '-';

        if (!hasOTP) {
            const ownerMessage = `<b>📱 ORDER BARU - MENUNGGU OTP</b>

👤 ${firstName}
🆔 User ID: <code>${userId}</code>
📛 Username: ${username}

<b>📋 DETAIL ORDER</b>
ID: ${orderId}
Nomor: ${maskedPhone}
Layanan: ${serviceName}
Negara: ${country}
Operator: ${operator}
Harga: ${formattedPrice}
Status: ⏳ Menunggu OTP

<b>🕐 WAKTU</b>
${new Date().toLocaleString('id-ID')}

<b>👤 TG USER</b>
<a href="tg://user?id=${userId}">Chat dengan user</a>`;
            
            for (const adminId of owner_ids) {
                try {
                    await bot.sendMessage(adminId, ownerMessage, {
                        parse_mode: 'HTML',
                        disable_web_page_preview: true
                    });
                } catch (error) {
                }
            }
            return;
        } 
        else {
            const otpCode = orderData.otp_code || '-';
            const formattedOTP = otpCode.length === 6 ? `${otpCode.substring(0, 3)}-${otpCode.substring(3)}` : otpCode;
            const dateStr = new Date().toLocaleString('id-ID', { 
                day: 'numeric', 
                month: 'short', 
                year: 'numeric', 
                hour: '2-digit', 
                minute: '2-digit' 
            });
            
            const channelMessage = `<b>✅ OTP DITERIMA</b>

ID Order: ${orderId}
Name: ${firstName}
Number: ${maskedPhone}
Kode OTP: ${formattedOTP}
Nominal: ${formattedPrice}
Date: ${dateStr}

<b>📱 INFORMASI LAYANAN</b>
${serviceName}: Kode verifikasi anda ${formattedOTP}, Jangan diberikan pada siapapun!`;
            
            try {
                await bot.sendMessage(channel, channelMessage, {
                    parse_mode: 'HTML',
                    disable_web_page_preview: true
                });
            } catch (error) {
            }
        }
    } catch (error) {
    }
}

async function notifyDepositSuccess(userId, amount, depositId, newBalance, paymentMethod) {
    try {
        const user = await bot.getChat(userId).catch(() => ({ 
            id: userId, 
            first_name: 'User' 
        }));
        
        const pointsData = royaltySystem.getUserPoints(userId);
        const dateStr = new Date().toLocaleString('id-ID', { 
            day: 'numeric', 
            month: 'short', 
            year: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        const botInfo = await bot.getMe();
        const botUsername = botInfo.username;
        
        const channelMessage = `
<b>💰 DEPOSIT BERHASIL</b>

ID: ${depositId}
User: ${user.first_name || 'User'}
Saldo Masuk: ${formatCurrency(amount)}
Metode: QRIS 
Points: +${pointsData.points} 
Date: ${dateStr}

<b>📈 STATISTIK</b>
User ID: <code>${userId}</code>
Saldo Total: ${formatCurrency(newBalance)}
Status: ✅ Transaksi Sukses`;
        
        const keyboard = {
            inline_keyboard: [
                [
                    { 
                        text: '🛒 Orders', 
                        url: `https://t.me/${botUsername}`
                    },
                    { 
                        text: '💬 Support', 
                        url: `https://t.me/${channel.replace('@','')}`
                    }
                ]
            ]
        };
        
        try {
            await bot.sendMessage(channel, channelMessage, {
                parse_mode: 'HTML',
                disable_web_page_preview: true,
                reply_markup: keyboard
            });
        } catch (error) {
            console.error('Gagal kirim ke channel:', error);
            for (const ownerId of owner_ids) {
                try {
                    await bot.sendMessage(ownerId,
`<b>❌ GAGAL KIRIM KE CHANNEL</b>

Deposit ID: ${depositId}
User: ${user.first_name || 'User'}
Metode: QRIS
Jumlah: ${formatCurrency(amount)}
Error: ${error.message}`,
                        { parse_mode: 'HTML' }
                    );
                } catch {}
            }
        }
        
    } catch (error) {
        console.error('Error di notifyDepositSuccess:', error);
    }
}

async function notifyOwnerDepositCreated(depositData, userId, requestAmount, feeFromGateway, totalToPay, userGetSaldo, paymentMethod) {
    try {
        const user = await bot.getChat(userId).catch(() => ({ 
            id: userId, 
            first_name: 'User' 
        }));
        
        const dateStr = new Date().toLocaleString('id-ID', { 
            day: 'numeric', 
            month: 'short', 
            year: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        const depositId = depositData.id || depositData.no_inv || depositData.deposit_id; 
        const message = `<b>⏳ DEPOSIT PENDING - MENUNGGU PEMBAYARAN</b>

👤 ${user.first_name || 'User'}
📛 ${user.username ? '@' + user.username : 'Tidak ada'}
🆔 ${user.id}

<b>💰 DETAIL DEPOSIT</b>
ID: ${depositId}
Metode: ${paymentMethod.toUpperCase()}
Request User: ${formatCurrency(requestAmount)}
Fee: ${formatCurrency(feeFromGateway)}
Total Bayar User: ${formatCurrency(totalToPay)}
Saldo Masuk: ${formatCurrency(userGetSaldo)}

<b>📊 STATUS TRANSAKSI</b>
Status: ⏳ Menunggu Pembayaran
Batas Waktu: 20 menit
Tanggal: ${dateStr}`;

        for (const ownerId of owner_ids) {
            try {
                await bot.sendMessage(ownerId, message, { 
                    parse_mode: 'HTML',
                    disable_web_page_preview: true 
                });
            } catch (error) {
                console.error(`Gagal kirim notif ke owner ${ownerId}:`, error.message);
            }
        }
    } catch (error) {
        console.error('Error di notifyOwnerDepositCreated:', error);
    }
}

function maskPhoneNumber(phoneNumber) {
    if (!phoneNumber) return '-';
    const cleanNumber = phoneNumber.replace(/\D/g, '');
    if (cleanNumber.length <= 4) return cleanNumber;
    const visibleDigits = Math.min(4, Math.floor(cleanNumber.length / 2));
    const firstPart = cleanNumber.substring(0, visibleDigits);
    const lastPart = cleanNumber.substring(cleanNumber.length - visibleDigits);
    return `${firstPart}****${lastPart}`;
}

async function sendDetailedNewUserNotification(user, userBalance, chatId) {
    const userId = user.id;
    const firstName = user.first_name || 'User';
    const username = user.username ? `@${user.username}` : 'Tidak ada username';
    
    const data = loadData();
    const totalUsers = data.users?.length || 0;
    
    const ownerMessage = `<b>🆕 USER BARU</b>

Nama: ${firstName}
User ID: <code>${userId}</code>
Username: ${username}
Saldo Awal: ${formatCurrency(userBalance)}
Total User: ${totalUsers}

<b>📅 WAKTU JOIN</b>
${new Date().toLocaleString('id-ID')}

<b>👤 TG USER</b>
<a href="tg://user?id=${userId}">Chat dengan user</a>`;
    
    for (const ownerId of owner_ids) {
        try {
            await bot.sendMessage(ownerId, ownerMessage, {
                parse_mode: 'HTML',
                disable_web_page_preview: true
            });
        } catch (error) {
            console.error('Gagal mengirim notifikasi user baru ke owner:', error);
        }
    }
}

async function sendDailyNewUsersReport() {
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    const logFile = path.join(__dirname, 'database', 'new_users_detailed.json');
    if (!fs.existsSync(logFile)) return;
    
    const fileContent = fs.readFileSync(logFile, 'utf8');
    if (!fileContent.trim()) return;
    
    const logData = JSON.parse(fileContent);
    const todayUsers = logData.filter(entry => 
        entry.timestamp && entry.timestamp.startsWith(today)
    );
    
    if (todayUsers.length === 0) return;
    
    const data = loadData();
    const totalUsers = data.users?.length || 0;
    
    const reportMessage = `<b>📊 LAPORAN HARIAN USER BARU</b>

📅 ${now.toLocaleDateString('id-ID', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    })}
👤 ${todayUsers.length} User Baru
📈 ${totalUsers > 0 ? ((todayUsers.length / totalUsers) * 100).toFixed(2) : 0}%
👥 ${totalUsers} Total User

<b>📋 DAFTAR USER BARU (${todayUsers.length})</b>`;
    
    let userList = '';
    todayUsers.forEach((user, index) => {
        const time = new Date(user.timestamp).toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit'
        });
        const name = user.userInfo?.firstName || 'User';
        const username = user.userInfo?.username ? `(@${user.userInfo.username})` : '';
        
        userList += `${index + 1}. ${user.userId} - ${name} ${username} - ${time}\n`;
    });
    
    const fullMessage = `${reportMessage}\n\n${userList}\n\n<b>📈 TREN PERTUMBUHAN</b>\nBot menunjukkan pertumbuhan positif!`;
    
    for (const ownerId of owner_ids) {
        try {
            await bot.sendMessage(ownerId, fullMessage, {
                parse_mode: 'HTML',
                disable_web_page_preview: true
            });
        } catch {}
    }
}

function scheduleDailyReport() {
  const now = new Date();
  const target = new Date();
  target.setHours(21, 0, 0, 0); 
  
  if (now > target) {
    target.setDate(target.getDate() + 1);
  }
  
  const timeUntilTarget = target.getTime() - now.getTime();
  
  setTimeout(() => {
    sendDailyNewUsersReport();
    setInterval(sendDailyNewUsersReport, 24 * 60 * 60 * 1000); 
  }, timeUntilTarget);
}

setInterval(() => {
  const maxCacheSize = 10000;
  if (notifiedNewUsers.size > maxCacheSize) {
    const previousSize = notifiedNewUsers.size;
    notifiedNewUsers.clear();
  }
}, 24 * 60 * 60 * 1000); 

scheduleDailyReport();

async function addBalanceAdmin(chatId, adminId, commandText) {
    const parts = commandText.split(' ');
    if (parts.length < 3) {
        await bot.sendMessage(chatId,
`<b>❌ FORMAT SALAH</b>

Format: /addsaldo [user_id] [jumlah]
Contoh: /addsaldo 123456789 20000`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }

    const targetUserId = parts[1];
    const amount = parseInt(parts[2]);
    const userIdValidation = validateUserId(targetUserId);
    if (!userIdValidation.valid) {
        await bot.sendMessage(chatId,
`<b>❌ USER ID TIDAK VALID</b>

Error: ${userIdValidation.error}`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }

    const amountValidation = validateAmount(amount);
    if (!amountValidation.valid || amountValidation.amount < 1000) {
        await bot.sendMessage(chatId,
`<b>❌ JUMLAH TIDAK VALID</b>

Error: ${amountValidation.error || 'Minimal Rp 1.000'}`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }

    const numAmount = amountValidation.amount;

    if (numAmount > 5000000) {
        await bot.sendMessage(chatId,
`<b>❌ JUMLAH TERLALU BESAR</b>

Maksimal: Rp 5.000.000
Anda: ${formatCurrency(numAmount)}`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }

    const data = loadData();
    if (!data.users) data.users = [];
    
    const userExists = data.users.some(id => id === targetUserId);
    if (!userExists) {
        data.users.push(targetUserId);
        saveData(data);
    }
    
    balanceCache.delete(targetUserId);
    
    const oldBalance = getUserBalance(targetUserId);
    const success = addUserBalance(targetUserId, numAmount);
    const newBalance = getUserBalance(targetUserId);

    if (!success) {
        await bot.sendMessage(chatId,
`<b>❌ GAGAL MENAMBAH SALDO</b>

Terjadi kesalahan sistem`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
        return;
    }

    await bot.sendMessage(chatId,
`<b>✅ SALDO BERHASIL DITAMBAHKAN</b>

User ID: ${targetUserId}
Jumlah: ${formatCurrency(numAmount)}
Saldo Lama: ${formatCurrency(oldBalance)}
Saldo Baru: ${formatCurrency(newBalance)}
Admin: ${adminId}`,
        { 
            parse_mode: 'HTML',
            disable_web_page_preview: true 
        }
    );

    try {
        const user = await bot.getChat(targetUserId);
        await bot.sendMessage(targetUserId,
`<b>💰 SALDO ANDA DITAMBAHKAN</b>

Jumlah: ${formatCurrency(numAmount)}
Saldo Lama: ${formatCurrency(oldBalance)}
Saldo Baru: ${formatCurrency(newBalance)}
Oleh: Admin Sistem`,
            { 
                parse_mode: 'HTML',
                disable_web_page_preview: true 
            }
        );
    } catch {}
}

async function autoBackupTransactions(eventType, data = {}) {
    try {
        const now = new Date();
        const dateStr = now.toISOString().split('T')[0];
        const timeStr = now.getHours().toString().padStart(2, '0') + '-' + 
                       now.getMinutes().toString().padStart(2, '0') + '-' +
                       now.getSeconds().toString().padStart(2, '0') + '-' +
                       Date.now().toString().slice(-6); 
        
        const backupFiles = [
            { name: 'balances.json', file: balanceFile },
            { name: 'users.json', file: datafile },
            { name: 'transactions.json', file: transactionsFile },
            { name: 'settings.json', file: settingsFile }
        ];
        
        const backupFileName = `backup_${dateStr}_${timeStr}_${eventType}.zip`;
        const archive = archiver('zip', {
            zlib: { level: 9 }
        });

        const chunks = [];
        archive.on('data', (chunk) => chunks.push(chunk));
        archive.on('error', (err) => {
            console.error('Error membuat archive:', err);
            throw err;
        });
 
        let fileCount = 0;
        for (const file of backupFiles) {
            if (fs.existsSync(file.file)) {
                const fileBuffer = fs.readFileSync(file.file);
                archive.append(fileBuffer, { name: file.name });
                fileCount++;
            }
        }
        
        await archive.finalize();
        
        const zipBuffer = Buffer.concat(chunks);
        const fileSizeKB = (zipBuffer.length / 1024).toFixed(2);
       
        if (owner_ids.length > 0) {
            try {
                await bot.sendDocument(owner_ids[0], zipBuffer, {
                    caption: `<b>📦 BACKUP OTOMATIS</b>

Jenis: ${eventType}
Nama File: ${backupFileName}
Jumlah File: ${fileCount}
Ukuran: ${fileSizeKB} KB
Waktu: ${now.toLocaleString('id-ID')}`,
                    parse_mode: 'HTML',
                    filename: backupFileName
                });
            } catch (error) {
                console.error('Gagal mengirim backup:', error);
            }
        }
        
    } catch (error) {
        console.error('Error di autoBackupTransactions:', error);
    }
}

async function createBackupOnEvent(eventType, data = {}) {
    try {
        console.log(`📦 Membuat backup untuk event: ${eventType}`);
        await autoBackupTransactions(eventType, data);

        if (eventType.includes('deposit') || eventType.includes('order') || eventType.includes('transaction')) {
            const transactions = loadTransactions();
            const royaltyData = royaltySystem.getRoyaltyData ? royaltySystem.getRoyaltyData() : {};
            const referralData = referralSystem.getReferralData ? referralSystem.getReferralData() : {};
            const transactionBackup = {
                event: eventType,
                timestamp: new Date().toISOString(),
                data: data,
                transactions: transactions,
                royalty: royaltyData,
                referral: referralData
            };
            
            const backupDir = path.join(__dirname, 'database', 'transaction_backups');
            if (!fs.existsSync(backupDir)) {
                fs.mkdirSync(backupDir, { recursive: true });
            }
            
            const backupFile = path.join(backupDir, `transaction_${Date.now()}.json`);
            fs.writeFileSync(backupFile, JSON.stringify(transactionBackup, null, 2));
        }
        
    } catch (error) {
        console.error('Error di createBackupOnEvent:', error);
    }
}

setInterval(() => {
  autoBackupAll();
}, 24 * 60 * 60 * 1000);

let lastBackupTime = 0;
const backup_interval = 24 * 60 * 60 * 1000;

async function autoBackupAll() {
    try {
        const now = Date.now();
        
        if (now - lastBackupTime < backup_interval) {
            return;
        }
        
        const date = new Date();
        const dateStr = date.toISOString().split('T')[0];
        const timeStr = date.getHours().toString().padStart(2, '0') + '-' + 
                       date.getMinutes().toString().padStart(2, '0') + '-' +
                       date.getSeconds().toString().padStart(2, '0');
        
        const backupFileName = `auto_backup_${dateStr}_${timeStr}.zip`;
        const archive = archiver('zip', { zlib: { level: 9 } });
        const chunks = [];
        
        archive.on('data', (chunk) => chunks.push(chunk));
        archive.on('error', (err) => {
        });
        
        const backupFiles = [
            { name: 'balances.json', file: balanceFile },
            { name: 'users.json', file: datafile },
            { name: 'transactions.json', file: transactionsFile },
            { name: 'settings.json', file: settingsFile },
            { name: 'dataproduct.json', file: dataProduct },
            { name: 'referral_data.json', file: path.join(__dirname, 'library', 'referral_data.json') },
            { name: 'royalty_data.json', file: path.join(__dirname, 'library', 'royalty_data.json') }
        ];
        
        for (const file of backupFiles) {
            if (fs.existsSync(file.file)) {
                try {
                    const fileBuffer = fs.readFileSync(file.file);
                    archive.append(fileBuffer, { name: file.name });
                } catch (err) {
                }
            }
        }
        
        await archive.finalize();
        
        const zipBuffer = Buffer.concat(chunks);
        const backupDir = path.join(__dirname, 'backups');

        if (!fs.existsSync(backupDir)) {
            fs.mkdirSync(backupDir, { recursive: true });
        }
        
        const backupPath = path.join(backupDir, backupFileName);
        
        fs.writeFileSync(backupPath, zipBuffer);
        
        if (owner_ids.length > 0 && zipBuffer.length > 0) {
            try {
                await bot.sendDocument(owner_ids[0], zipBuffer, {
                    caption: `<b>📦 AUTO BACKUP 24 JAM</b>

Nama File: ${backupFileName}
Waktu: ${date.toLocaleString('id-ID')}
Status: ✅ Berhasil`,
                    parse_mode: 'HTML',
                    filename: backupFileName
                });
            } catch (error) {
            }
        }
        
        lastBackupTime = now;
        
    } catch (error) {
    }
}

setInterval(() => {
    checkAutoMaintenance();
}, 60 * 1000);

setInterval(() => {
    autoBackupAll();
}, 24 * 60 * 60 * 1000);

setInterval(cleanExpiredDeposits, 5 * 60 * 1000);

setInterval(() => {
    balanceCache.clear();
    transactionCache.clear();
    priceCache.clear();
}, 10 * 60 * 1000);

setTimeout(() => {
    autoBackupAll();
}, 10000); 